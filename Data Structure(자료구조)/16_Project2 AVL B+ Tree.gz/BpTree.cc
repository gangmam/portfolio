#include "BpTree.h"

BpTree::BpTree(ofstream* fout, int order)// BpTree initializer
{
	root = NULL;// root initialize NULL
	this->order = order;//pointing order
	this->fout = fout;// pointing fout
}

BpTree::~BpTree()
{

}

void BpTree::Insert(StudentData* pStu)//BpTree Insert
{
	double key = pStu->getAvgGrade();	// key is student avgGrade value
	map<int, StudentData*> value;			// value is map< id, student data* >
	value.insert( make_pair(pStu->getStudentID(), pStu) ); // insert value (Student ID, StudentData*) pair type	

	if(root == NULL)// when Bptree has nothing
	{ 
		BpTreeNode* pDataNode = new BpTreeDataNode;	// make new data node using dynamic allocation		
		pDataNode->insertDataMap(key, value);	// insertDataMap(key, value) to pDataNode
		root = pDataNode;// pDataNode is set as root 
		return;// return 
	}
	BpTreeNode* pDataNode = searchDataNode(key);	// search data node with key, return value is BpTreeNode
	map<double, map<int, StudentData*> > *m = pDataNode->getDataMap();// m type is map<double, map<int, StudentData*>>* and has a DataMap of pDataNode
	
	if(m->find(key) == m->end())// if does not have the same key value
	{ 
		pDataNode->getDataMap()->insert(make_pair(key, value));// insert into DataMap
	}
	else // if it has the same key value
	{
		pDataNode->getDataMap()->find(key)->second.insert(make_pair(pStu->getStudentID(), pStu));// insert in the second with the same key value
	}
	if(exceedDataNode(pDataNode) == 1)// when data split should occur
	{
		splitDataNode(pDataNode);// DataNode split
	}
	while(pDataNode->getParent() != NULL)// if there is a parent indexNode
	{
		if(exceedIndexNode(pDataNode->getParent()) == 1)// when index split should occur
		{
			splitIndexNode(pDataNode->getParent());// IndexNode split
		}
		pDataNode = pDataNode->getParent();// up to the parent node
	}
	
}

BpTreeNode* BpTree::searchDataNode(double n)// SearchDataNode for searching DataNode
{
	BpTreeNode* pCur = root;// pCur = root
	map<double, BpTreeNode*>::iterator itIndex;// declaration of iterator for iterative search

	while(pCur->getMostLeftChild() != NULL)// when pCur has MostLeftChild
	{ 
		itIndex = pCur->getIndexMap()->begin();// declares the first navigation position of itindex

		if(n < itIndex->first)// when n is low value to itindex key
		{ 
			pCur = pCur->getMostLeftChild();// pCur goes down to MostLeftChild
		}
		else// when n is not low value to itindex key
		{
			while(true)// repeatly
			{
				itIndex++;// Itindex moves forward
				if(itIndex == pCur->getIndexMap()->end() || n < itIndex->first)// If the Itindex has reached the end or the value of forwarded Itindex is greater than n
				{
					itIndex--;// Itindex moves back
					pCur = itIndex->second;// give itindex's second value as pCur
					break;// escape from the loop
				}
			}
		}
	}
	
	return pCur;// return value is BpTreeNode pCur
}

void BpTree::splitDataNode(BpTreeNode* pDataNode)// splitDataNode for spliting DataNode 
{
	int splitPosition_data = ceil((order-1)/2.0) + 1; // splitPosition_data vaue is midpoint of DataNode 
	if(exceedDataNode(pDataNode) == 1)// when split should occur
	{

		map<double, map<int, StudentData*> >::iterator it;// declaration of iterator for spliting
		BpTreeNode* newDataNode = new BpTreeDataNode;// make new data node using dynamic allocation
		it = pDataNode->getDataMap()->begin();// define the location of it
		int a = 0;// a = 0;
		while(a < splitPosition_data - 1)// move the position of it to the split point
		{
			a++;
			it++;// it moves forword
		}
		for(; splitPosition_data <= order ; splitPosition_data++)// copying and moving data to newDataNode
		{
			newDataNode->insertDataMap(it->first, it->second);// insert newDataNode from pDataNode
			pDataNode->getDataMap()->erase(it++->first);//erase it->first
		}
		it = newDataNode->getDataMap()->begin();//move the position of it to the split point
		if(pDataNode->getParent() == NULL)// when pDataNode has not Parent Node
		{
			BpTreeNode* newIndexNode = new BpTreeIndexNode;// make new index node using dynamic allocation
			newIndexNode->getIndexMap()->insert(make_pair(it->first,newDataNode));// newIndexNode to insert the key of it and point it to newDataNode
			newIndexNode->setMostLeftChild(pDataNode);// Set as MostLeftChild node
			pDataNode->setParent(newIndexNode);// setting newIndexNode as Parent Node 
			newDataNode->setParent(newIndexNode);// setting newIndexNode as Parent Node
			if(pDataNode->getNext() != NULL)// if there was an original next, prev connection
			{
				newDataNode->setNext(pDataNode->getNext());// newDataNode next is set to pDataNode next
				pDataNode->getNext()->setPrev(newDataNode);// newDataNode is (pDataNode next Node) prev Node 
			}
			pDataNode->setNext(newDataNode);// pDataNode next is newDataNode
			newDataNode->setPrev(pDataNode);// pDatanode is pDataNode prev Node
			root = newIndexNode;// root node is new IndexNode
		}
		else// when pDataNode has Parent Node
		{	
			pDataNode->getParent()->getIndexMap()->insert(make_pair(it->first, newDataNode));// put the key value of it in the parent indexNode and let the second point to newDataNode
			newDataNode->setParent(pDataNode->getParent());// sets the parent node of newDataNode
			if(pDataNode->getNext() != NULL)// if there was an original next, prev connection
			{
				newDataNode->setNext(pDataNode->getNext());// newDataNode next is set to pDataNode next
				pDataNode->getNext()->setPrev(newDataNode);// newDataNode is (pDataNode next Node) prev Node 
			}
			pDataNode->setNext(newDataNode);// pDataNode next is newDataNode
			newDataNode->setPrev(pDataNode);// pDatanode is pDataNode prev Node
		}
	}
	
}

void BpTree::splitIndexNode(BpTreeNode* pIndexNode)// splitIndexNode for spliting IndexNode
{	
	int splitPosition_index = ceil(order/2.0);// splitPosition_data vaue is midpoint of DataNode 
	if(exceedIndexNode(pIndexNode) == 1)// when split shoult occur 
	{
		map<double, BpTreeNode*>::iterator it;// declaration of iterator for spliting
		BpTreeNode* newIndexNode = new BpTreeIndexNode;// make new index node using dynamic allocation
		it = pIndexNode->getIndexMap()->begin();// define the location of it
		int a = 0;// a = 0
		while(a < splitPosition_index - 1)// move the position of it to the split point
		{
			a++;
			it++;// it moves forward
		}
		for(; splitPosition_index <= order ; splitPosition_index++)// copying and moving data to newIndexNode
		{
			newIndexNode->insertIndexMap(it->first, it->second);// insert newIndexNode from pIndexNode
			pIndexNode->getIndexMap()->erase(it++->first); //erase it->first
		}
		it = newIndexNode->getIndexMap()->begin();//move the position of it to the split point
		if(pIndexNode->getParent() == NULL)// when pIndexNode has not Parent Node
		{
			BpTreeNode* newIndexNode2 = new BpTreeIndexNode;// make new index node using dynamic allocation
			newIndexNode2->insertIndexMap(it->first, newIndexNode);// put newIndexNode2 with key value of it and point to newIndexNode
			newIndexNode->setMostLeftChild(it->second);// sets the MostLeftChild of newIndexNode
			it->second->setParent(newIndexNode); // set the parent of it
			newIndexNode->getIndexMap()->erase(it->first);// erase it->first, becasue of IndexSPlit
			newIndexNode2->setMostLeftChild(pIndexNode);// sets the MostLeftChild of newIndexNode2.
			newIndexNode->setParent(newIndexNode2);// sets the parent node of newIndexNode
			pIndexNode->setParent(newIndexNode2);// sets the parent node of pIndexNode
			root = newIndexNode2;// root is newIndexNode2
		}
		else
		{
			pIndexNode->getParent()->insertIndexMap(it->first, newIndexNode);// put the key value of it in an already existing parent indexNode so that it can point to newIndexNode.
			newIndexNode->setMostLeftChild(it->second);// sets the MostLeftChild of newIndexNode
			it->second->setParent(newIndexNode);// set the parent node of it-> second
			newIndexNode->getIndexMap()->erase(it->first);// erase it->first, because of IndexSplit
			pIndexNode->getParent()->setMostLeftChild(pIndexNode);// sets the MostLeftChild of the ParentNode of pIndexNode
			newIndexNode->setParent(pIndexNode->getParent());// sets the parent node of newIndexNode
		}
	}
}

bool BpTree::exceedDataNode(BpTreeNode* pDataNode)// function to determine if pDataNode should be split
{
	map <double, map<int, StudentData*> > *m = pDataNode->getDataMap();// m is the DataMap of pDataNode

	if(m->size() > order-1)		return true;// when split should occur
	else						return false;// when split should not occur
}

bool BpTree::exceedIndexNode(BpTreeNode* pIndexNode)// fuction to determine if pIndexNode should be split
{
	map <double, BpTreeNode*>* m = pIndexNode->getIndexMap();// m is the IndexMap of pIndexNode
	
	if(m->size() > order-1)		return true;// when split should occur
	else				return false;// when split should not occur
}



bool BpTree::Print()// Print for BpTreeNode printing
{
	BpTreeNode* pCur = root;// pCur is root Node
	map <double, map <int, StudentData*> >::iterator it;// declaration of iterator for printing pCur->getDataMap
	map <int, StudentData*>::iterator it2;// declaration of iterator for printing it->second
	if(root == NULL)// BpTreeNode has no data
	{
		return false;
	}
	cout<<"======== PRINT ========"<<endl;
	*fout<<"======== PRINT ========"<<endl;
	while(pCur->getMostLeftChild() != NULL)// pCur moves to the bottom leftmost node
	{
		pCur = pCur->getMostLeftChild();
	}
	while(pCur->getNext() != NULL)// pCur moves to the far rightmost DataNode
	{
		pCur = pCur->getNext();
	}
	while(1)
	{
		if(pCur == NULL)// if pCur rotates all Datanodes, escape the loop
		{
			break;
		}
		for(it = --(pCur->getDataMap()->end());it != pCur->getDataMap()->begin(); it--)// loops that loop through DataMaps in pCur
		{
			for(it2 = it->second.begin() ; it2 != it->second.end() ; it2++)// loops that loop it-> second
			{
				printStudentInfo(it2->second);// printing StudentData
			}
		}
		for(it2 = it->second.begin() ; it2 != it->second.end() ; it2++)// In the last 'it' loops that loop it-> second
		{
			printStudentInfo(it2->second);// printing StudentData
		}
		pCur = pCur->getPrev();// pCur moves to prev Node of pCur
	}
	cout<<"======================="<<endl;
	*fout<<"======================="<<endl;
	return true;
}

bool BpTree::Search(double a, double b, int year)// Search for BpTreenode Searching
{
	BpTreeNode* pCur = root;// pCur is root Node
	int q = 0;// q = 0;
	map <double, map <int, StudentData*> >::iterator it;// declaration of iterator for printing pCur->getDataMap
	map <int, StudentData*>::iterator it2;// declaration of iterator for printing it->second
	if(root == NULL)// when Bptree has nothing data
	{
		return false;
	}
	cout<<"============SEARCH=========="<<endl;
	cout<<"SEARCH_BP "<<a<<" "<<b<<" "<<year<<" "<<endl;
	*fout<<"============SEARCH=========="<<endl;
	*fout<<"SEARCH_BP "<<a<<" "<<b<<" "<<year<<" "<<endl;
	while(pCur->getMostLeftChild() != NULL)// pCur moves to the bottom leftmost node
	{
		pCur = pCur->getMostLeftChild();
	}
	while(pCur->getNext() != NULL)// pCur moves to the far rightmost DataNode
	{
		pCur = pCur->getNext();
	}
	
	while(1)
	{
		if(pCur == NULL)// if pCur rotates all DataNodes, escape the loop
		{
			break;
		}
		for(it = --(pCur->getDataMap()->end());it != pCur->getDataMap()->begin(); it--)// loops that loop through DataMaps in pCur
		{
			it2 = it->second.begin();// set the start position of it2
			if(it->first >= a && it->first <= b)// if the key value of it is a value between a and b
			{
				for(it2 = it->second.begin() ; it2 != it->second.end() && it2->second->getYear() == year ; it2++)//loops that loop it-> second and if it2->second->getYear() == year, printing
				{
					cout<<it2->second->getStudentID()<<" "<<it2->second->getName()<<" ";
					cout<<it2->second->getYear()<<" "<<it2->second->getAvgGrade()<<" "<<endl; 
					*fout<<it2->second->getStudentID()<<" "<<it2->second->getName()<<" ";
					*fout<<it2->second->getYear()<<" "<<it2->second->getAvgGrade()<<" "<<endl;
					q = q + 1;// searching count
				}
			}
		}
		it2 = it->second.begin();// set the start position of it2
		if(it->first >= a && it->first <= b)// if the key value of it is a value between a and b
		{
			for(it2 = it->second.begin() ; it2 != it->second.end() && it2->second->getYear() == year ; it2++)// In the last 'it' loops that loop it-> second
			{
				cout<<it2->second->getStudentID()<<" "<<it2->second->getName()<<" ";
				cout<<it2->second->getYear()<<" "<<it2->second->getAvgGrade()<<" "<<endl; 
				*fout<<it2->second->getStudentID()<<" "<<it2->second->getName()<<" ";
				*fout<<it2->second->getYear()<<" "<<it2->second->getAvgGrade()<<" "<<endl; 
				q = q + 1;// searching count
			}
		}
		pCur = pCur->getPrev();// pCur moves to prev Node of pCur
	}
	if(q == 0)//If did not find anything
	{
		return false;
	}
	else
	{
		cout<<"============================"<<endl;
		*fout<<"============================"<<endl;
		return true;
	}
}

void BpTree::printStudentInfo(StudentData* pStudentData)// printStudenInfo for printing student Information 
{
	cout<<pStudentData->getStudentID()<<" "<<pStudentData->getName()<<" ";// student information printing
	cout<<pStudentData->getYear()<<" "<<pStudentData->getAvgGrade()<<endl;
	*fout<<pStudentData->getStudentID()<<" "<<pStudentData->getName()<<" ";
	*fout<<pStudentData->getYear()<<" "<<pStudentData->getAvgGrade()<<endl;
	pStudentData->printGrade();// printing the subject information and grades of the corresponding grade
	cout<<endl;
	*fout<<endl;
}