#ifndef _AVLTREE_H_
#define _AVLTREE_H_

#include "AVLNode.h"

class AVLTree
{
private:
	AVLNode*	root;
	vector < pair< pair<double, int>, StudentData* > > vHeap;// using STL vectors < pair< pair<double, int>, StudentData* > > type
	ofstream*	fout;

public:
	AVLTree(ofstream* fout);//initializer
	~AVLTree();
	
	bool		Insert(StudentData* pStu);// insert function
	bool		Print();// Print function
	bool		Search(char* name);// SEARACH fucntion
	bool		Rank();// RANK function

	void		printStudentInfo(StudentData* pStudentData);// printStudentInfo function
};

#endif