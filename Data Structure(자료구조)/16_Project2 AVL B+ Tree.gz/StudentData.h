#ifndef _STUDENTDATA_H_
#define _STUDENTDATA_H_

#include <iostream>
#include <cstring>
#include <fstream>
#include <map>
#include <math.h>
#include <vector>
#include <algorithm>
#include <deque>
#include <queue>
#include <stack>

using namespace std;


class StudentData
{
private:
	int			StudentID;// StudentData
	char		Name[10];		
	int			Year;			
	double	AvgGrade;		

public:
	StudentData()// initializer
	{
		StudentID = 0;
		memset(Name, 0, 10);
		Year = 0;
		AvgGrade = 0;
	};
	~StudentData(){};

	void	setStudentID(int id)			{ StudentID = id; }// define setStudentID
	void	setName(char* name)		{ strcpy(Name, name); }// define seName
	void	setYear(int year)				{ Year = year; }// define setYear	
	void	setAvgGrade(char *a, char *b, char *c)// define setAvgGrade
	{
		AvgGrade = getGrade(a) + getGrade(b) + getGrade(c);// AvgGrade = total number of subject points
		AvgGrade /= 3;// medium value
		int tmp = AvgGrade * 1000;
		int tmp2 = tmp / 10;
		if(tmp % 10 > 4)// set the value of AvgGrade
		{
			AvgGrade = (tmp2 + 1) / 100.0 ;
		}
		else
		{
			AvgGrade = tmp2 / 100.0;
		}
	}

	int			getYear()				{ return Year; }// define getYear
	int			getStudentID()		{ return StudentID; }// define getStudendID
	char*		getName()				{ return Name; }// define getName
	double	getAvgGrade()			{ return AvgGrade; }// define getAvgGrade

	double	getGrade(char *ch)// define getGrade
	{
		if(strcmp(ch, "A+") == 0)// returns score according to subject value
		{
			return 4.5;
		}
		else if(strcmp(ch, "A0") == 0)// returns score according to subject value
		{
			return 4.0;
		}
		else if(strcmp(ch, "B+") == 0)// returns score according to subject value
		{
			return 3.5;
		}
		else if(strcmp(ch, "B0") == 0)// returns score according to subject value
		{
			return 3.0;
		}
		else if(strcmp(ch, "C+") == 0)// returns score according to subject value
		{
			return 2.5;
		}
		else if(strcmp(ch, "C0") == 0)// returns score according to subject value
		{
			return 2;
		}
		else if(strcmp(ch, "D+") == 0)// returns score according to subject value
		{
			return 1.5;
		}
		else if(strcmp(ch, "D0") == 0)// returns score according to subject value
		{
			return 1.0;
		}
		else
		{
			return 0;
		}
		return 0;
	}

	virtual void printGrade()// declaration of a virtual function for use StudendData, printGrade function
	{
	}
	virtual void setGrade(char* a,char* b, char* c)// declaration of a virtual function for use StudendData, setGrade function
	{
	}
};

bool compare( pair< pair< double, int>, StudentData* > a, pair< pair< double, int>, StudentData* > b );// function that compares values and sets the up and down position

#endif