#include "Manager.h"

int main(void)
{
	cout.setf(ios::fixed);// only digits after the decimal point are treated.
	cout.precision(2);// represents the number of two decimal places

	int bpOrder = 3;// set the value of order

	Manager ds(bpOrder);// using the Manager class
	ds.run("command.txt");// execution of the run function in Manager class

	return 0;
}

bool compare( pair< pair< double, int>, StudentData* > a, pair< pair< double, int>, StudentData* > b )// function that compares values and sets the up and down position
{

	if( a.first.first == b.first.first)// comparing average grade
	{
		return a.first.second > b.first.second;// return value
	}
	else
	{
		return a.first.first < b.first.first;
	}
}