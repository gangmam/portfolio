#ifndef _BpTreeNode_H_
#define _BpTreeNode_H_

#include "Year.h"

class BpTreeNode
{
private:
	BpTreeNode* pParent;
	BpTreeNode* pMostLeftChild;

public:
	BpTreeNode()// initializer
	{
		pParent = NULL;
		pMostLeftChild = NULL;
	}
	void setMostLeftChild(BpTreeNode* pN)// define setMostLeftChild
	{ 
		pMostLeftChild = pN;
	}
	void setParent(BpTreeNode* pN)// define setParent
	{ 
		pParent = pN;
	}
	
	BpTreeNode* getParent()// define getParent
	{ 
		return pParent;
	}
	BpTreeNode* getMostLeftChild()// getMostLeftChild
	{ 
		return pMostLeftChild;
	}

	virtual map <double, BpTreeNode*>* getIndexMap()// declaration of a virtual function for use in BpTreeNode, getIndexMap fuction
	{
		return NULL;
	}
	virtual void insertDataMap(double avgGrade, map<int, StudentData*> m)// declaration of a virtual function for use in BpTreeNode, insertDataMap fuction
	{
	}
	virtual map< double, map<int, StudentData*> > *getDataMap()// declaration of a virtual function for use in BpTreeNode, getDataMap fuction	 
	{
		return NULL;
	}
	virtual void insertIndexMap(double n, BpTreeNode* pN)// declaration of a virtual function for use in BpTreeNode, insertIndexMap fuction
	{
	}
	virtual void setNext(BpTreeNode* pN)// declaration of a virtual function for use in BpTreeNode, setNext fuction
	{
	}
	virtual BpTreeNode* getNext()// declaration of a virtual function for use in BpTreeNode, getNext fuction
	{
		return NULL;
	}
	virtual void setPrev(BpTreeNode* pN)// declaration of a virtual function for use in BpTreeNode, setPrev fuction
	{
	}
	virtual BpTreeNode* getPrev()// declaration of a virtual function for use in BpTreeNode, getPrev fuction
	{
		return NULL;
	}
};

#endif