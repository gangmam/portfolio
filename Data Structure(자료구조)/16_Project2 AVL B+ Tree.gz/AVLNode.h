#ifndef _AVLNODE_H_
#define _AVLNODE_H_

#include "Year.h"

class AVLNode
{
private:
	AVLNode*			pRight;
	AVLNode*			pLeft;
	StudentData*		pStudentData;
	int						mBF;

public:
	AVLNode()// initializer
	{
		pRight = NULL;
		pLeft = NULL;
		pStudentData = NULL;
		mBF = 0;
	}
	~AVLNode(){};

	void	setRight(AVLNode* SN)			{ pRight = SN; }// define setRight function
	void	setLeft(AVLNode* SN)			{ pLeft = SN; }// define setLeft function
	void	setSD(StudentData* pStu)	{ pStudentData = pStu; }// define setSD function
	void	setBF(int a)							{ mBF = a; }// define setBF function

	AVLNode*		getRight()	{ return pRight; }// define getRight function
	AVLNode*		getLeft()	{ return pLeft; }// define getLeft function
	StudentData*	getSD()		{ return pStudentData; }// define getSD function
	int					getBF()		{ return mBF; }// define getBF function
};

#endif