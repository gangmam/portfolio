#ifndef _MANAGER_H_
#define _MANAGER_H_

#include "AVLTree.h"
#include "BpTree.h"

class Manager
{
private:
	AVLTree		*avl;// AVL Tree
	BpTree		*bp;// Bp Tree
	ofstream		fout;// log.txt file

public:
	Manager(int bpOrder);// initializer
	~Manager();

	void	run(const char * command_txt);// run function
	
	bool	LOAD();// LOAD function
	bool	SEARCH_AVL(char* name);// SEARCH_AVL function
	bool	SEARCH_BP(double a, double b, int year);// SEARCH_BP function
	bool	RANK();// RANK function	
	bool	PRINT_AVL();// PRINT_AVL function
	bool	PRINT_BP();// PRINT_BP function

	void	printErrorCode(int n);	// printErrorCode function
};

#endif