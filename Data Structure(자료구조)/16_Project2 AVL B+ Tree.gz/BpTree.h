#ifndef _BPTREE_H_
#define _BPTREE_H_

#include "BpTreeIndexNode.h"
#include "BpTreeDataNode.h"

class BpTree
{
private:
	BpTreeNode*	root;
	int					order;	
	ofstream*		fout;

public:
	BpTree(ofstream* fout, int order = 3);// initializer
	~BpTree();

	void	Insert(StudentData* pStudentData);// Insert
	bool	exceedDataNode(BpTreeNode* pDataNode);// exceedDataNode
	bool	exceedIndexNode(BpTreeNode* pIndexNode);// exceedIndexNode
	void	splitDataNode(BpTreeNode* pDataNode);//splitDataNode
	void	splitIndexNode(BpTreeNode* pIndexNode);//splitIndexNode
	BpTreeNode*	searchDataNode(double n);// searchDataNode

	bool	Print(); // PRINT_BP
	bool	Search(double a, double b, int year); // SEARCH_BP	

	void	printStudentInfo(StudentData* pStudentData);// printing StudentData
};

#endif