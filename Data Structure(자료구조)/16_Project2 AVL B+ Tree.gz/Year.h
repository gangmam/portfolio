#ifndef _YEAR_H_
#define _YEAR_H_

#include "StudentData.h"

class Freshman : public StudentData
{
private:
	char CProgramming[3]; 
	char Calculus[3]; 
	char IntroToComputer[3];

public:
	Freshman(){};
	virtual ~Freshman(){};

	void setGrade(char* a, char* b, char *c)// set the grade for the course
	{
		strcpy(CProgramming, a);
		strcpy(Calculus, b);
		strcpy(IntroToComputer, c);
	}

	void printGrade()// grade 1 subjects and scores
	{
		ofstream fout;
		fout.open("log.txt",ios::app);
		cout<<"C Programming : "<<CProgramming<<endl;
		fout<<"C Programming : "<<CProgramming<<endl;
		cout<<"Calculus : "<<Calculus<<endl;
		cout<<"Intro To Computer : "<<IntroToComputer<<endl;
		fout<<"Calculus : "<<Calculus<<endl;
		fout<<"Intro To Computer : "<<IntroToComputer<<endl;
		fout.close();
	}
};

class Sophomore : public StudentData
{
private:
	char AdvancedProgramming[3];
	char DigitalLogicCircuits[3];
	char DataStructure[3];

public:
	Sophomore(){};
	virtual  ~Sophomore(){};

	void setGrade(char* a, char* b, char *c)// set the grade for the course
	{
		strcpy(AdvancedProgramming, a);
		strcpy(DigitalLogicCircuits, b);
		strcpy(DataStructure, c);
	}

	void printGrade()// grade 2 subjects and scores
	{
		ofstream fout;
		fout.open("log.txt",ios::app);
		cout<<"Advanced Programming : "<<AdvancedProgramming<<endl;
		cout<<"Digital Logic Circuits : "<<DigitalLogicCircuits<<endl;
		cout<<"DataStructure : "<<DataStructure<<endl;
		fout<<"Advanced Programming : "<<AdvancedProgramming<<endl;
		fout<<"Digital Logic Circuits : "<<DigitalLogicCircuits<<endl;
		fout<<"DataStructure : "<<DataStructure<<endl;
		fout.close();
	}
};


class Junior : public StudentData
{
private:
	char ComputerArchitecture[3];
	char SystemProgramming[3];
	char OperatingSystem[3]; 

public:
	Junior(){};
	virtual  ~Junior(){};

	void setGrade(char* a, char* b, char *c)// set the grade for the course
	{
		strcpy(ComputerArchitecture, a);
		strcpy(SystemProgramming, b);
		strcpy(OperatingSystem, c);
	}

	void printGrade()// grade 3 subjects and scores
	{
		ofstream fout;
		fout.open("log.txt",ios::app);
		cout<<"Computer Architecture : "<<ComputerArchitecture<<endl;
		cout<<"System Programming : "<<SystemProgramming<<endl;
		cout<<"Operating System : "<<OperatingSystem<<endl;
		fout<<"Computer Architecture : "<<ComputerArchitecture<<endl;
		fout<<"System Programming : "<<SystemProgramming<<endl;
		fout<<"Operating System : "<<OperatingSystem<<endl;
		fout.close();
	}
};

class Senior :public StudentData
{
private:
	char CapstoneDesign[3];
	char Database[3]; 
	char ImageProcessing[3]; 

public:
	Senior(){};
	virtual  ~Senior(){};
	
	void setGrade(char* a, char* b, char *c)// set the grade for the course
	{
		strcpy(CapstoneDesign, a);
		strcpy(Database, b);
		strcpy(ImageProcessing, c);
	}

	void printGrade()// grade 4 subjects and scores
	{
		ofstream fout;
		fout.open("log.txt",ios::app);
		cout<<"Capstone Design : "<<CapstoneDesign<<endl;
		cout<<"Database : "<<Database<<endl;
		cout<<"Image Processing : "<<ImageProcessing<<endl;
		fout<<"Capstone Design : "<<CapstoneDesign<<endl;
		fout<<"Database : "<<Database<<endl;
		fout<<"Image Processing : "<<ImageProcessing<<endl;
		fout.close();
	}
};

#endif