#include "Manager.h"

Manager::Manager(int bpOrder)// initializer
{
	fout.open("log.txt", ios::app);
	avl = new AVLTree(&fout);
	bp = new BpTree(&fout, bpOrder);	
}

Manager::~Manager()// destructor
{
	delete avl;
	delete bp;
	fout.close();
}

void Manager::run(const char* command_txt)// run function for executing practical operation
{
	ifstream fin;		
	fin.open(command_txt);
	int	load = -1;
		
	if(!fin)//if no open file
	{
		cout<<"[ERROR] command file open error!"<<endl;
		fout<<"[ERROR] command file open error!"<<endl;
		return;
	}
	char*	str=NULL;
	char*	str2=NULL;
	char*	str3=NULL;
	char	buf[128]={0};
	char	buf2[128]={0};
	while(fin.getline(buf, 64))// execute command while reading a line one line at a time
	{
		strcpy(buf2, buf);
		str=strtok(buf, " \n");	
		
		if(strcmp(str, "LOAD") == 0)// for LOAD execution
		{
			if(load == 1)// LOAD already running

			{
				printErrorCode(100);
			}
			else if((str=strtok(NULL, " \n")) != NULL || !LOAD())// exception case
			{
				printErrorCode(100);
			}
			if(load == -1)// if LOAD is successfu
			{
				cout<<"======== LOAD ========"<<endl;
				cout<<"Success"<<endl;
				cout<<"======================="<<endl;
				fout<<"======== LOAD ========"<<endl;
				fout<<"Success"<<endl;
				fout<<"======================="<<endl;
			}
			load = 1;// if LOAD is successfu 
		}
		else if(strcmp(str, "SEARCH_AVL") == 0)// for SEARCH_AVL execution
		{
			str = strtok(0, " \n");// name to search
			if(!SEARCH_AVL(str))
			{
				printErrorCode(300);// for exception case
			}
		}
		else if(strcmp(str, "SEARCH_BP") == 0)// for SEARCH_BP case
		{
			str = strtok(0, " \n");// minimum score
			str2 = strtok(0, " \n");// maximum score
			str3 = strtok(0, " \n");// year
			if(str3 == NULL)
			{
				printErrorCode(200);//for exception case
			}
			else if(!SEARCH_BP(atof(str),atof(str2),atoi(str3)))
			{
				printErrorCode(200);// for exception case			
			}
		}
		else if(strcmp(str, "RANK") == 0)// for RANK case
		{
			if(!RANK())
			{
				printErrorCode(400);// for exception case
			}
		}
		else if(strcmp(str, "PRINT_AVL") == 0)// for PRINT_AVL case
		{
			if(!PRINT_AVL())
			{
				printErrorCode(600);// exception case
			}
		}
		else if(strcmp(str, "PRINT_BP") == 0)// for PRINT_BP case
		{
			if(!PRINT_BP())
			{
				printErrorCode(500);// exception case
			}
		}
		else if(strcmp(str, "EXIT") == 0)
		{
			fin.close();
			return;
		}
		fout<<endl;
	}	
	fin.close();// file close
}

bool Manager::LOAD()//LOAD function for inserting grade list 
{
	char*	str=NULL;
	char	buf[128]={0};
	char	buf2[128]={0};
	
	ifstream fin;
	fin.open("grade_list.txt");
	
	if(!fin)// if the file does not exist
	{
		return false;
	}	
	while(fin.getline(buf, 64))// LOAD by reading one line at one line
	{
		StudentData* pStu;
		strcpy(buf2, buf);

		str=strtok(buf, " ");// Student ID
		str=strtok(NULL, " ");// Student name
		str=strtok(NULL, " ");// Student year
			
		if(strcmp(str, "1") == 0)// if year = 1, inherited Freshman
		{
			pStu = new Freshman();	
		}
		else if(strcmp(str, "2") == 0)// if year = 2, inherited Sophomore
		{
			pStu = new Sophomore();
		}
		else if(strcmp(str, "3") == 0)// if year = 3, inherited Junior
		{
			pStu = new Junior();
		}
		else if(strcmp(str, "4") == 0)// if year 4, inherited Senior
		{
			pStu = new Senior();
		}

		str=strtok(buf2, " ");// Student ID
		pStu->setStudentID(atoi(str));
		str=strtok(NULL, " ");// Student Name
		pStu->setName(str);
		str=strtok(NULL, " ");// Student Year
		pStu->setYear(atoi(str));
		char* a = strtok(NULL," ");// subject Score
		char* b = strtok(NULL," ");
		char* c = strtok(NULL," ");
		pStu->setAvgGrade(a, b, c);
		pStu->setGrade(a, b, c);
		avl->Insert(pStu);//StudentData Insert to AVL Tree
		bp->Insert(pStu);// StudentData Insert to Bp Tree
	}
	return true;
}

bool Manager::SEARCH_AVL(char* name)// SEARCH_AVL for searching to AVL Tree
{
	if(!avl->Search(name))	return false;// if do not have a name to look for
	else							return true;
}

bool Manager::SEARCH_BP(double a, double b, int year)// SEARCH_BP for searching to Bp Tree
{
	if(!bp->Search(a, b, year))		return false;// if do not have a name to look for
	
	else											return true;
}

bool Manager::RANK()// RANK fuction for collecting the information that found
{
	if(!avl->Rank())		return false;// if no information is found
	else					return true;
}

bool Manager::PRINT_AVL()// PRINT_AVL for printing AVL Tree
{
	if(!avl->Print())	return false;// if the AVL Tree does not contain information
	else					return true;
}

bool Manager::PRINT_BP()// PRINT_BP for printing Bp Tree
{
	if(!bp->Print())		return false;// if the Bp Tree does not contain information
	
	else					return true;
}

void Manager::printErrorCode(int n)//printErrorCode fuction for printing errorCode
{
	fout<<"======== ERROR ========"<<endl;
	fout<<n<<endl;
	fout<<"======================="<<endl;
}