#ifndef _BPTREEINDEXNODE_H_
#define _BPTREEINDEXNODE_H_

#include "BpTreeNode.h"

class BpTreeIndexNode : public BpTreeNode
{
private:
	map <double, BpTreeNode*> mapIndex;// define <double, BpTreeNode*> type map container
	
public:
	BpTreeIndexNode(){}
	~BpTreeIndexNode(){}
	
	void insertIndexMap(double n, BpTreeNode* pN)// declare functions for inserting values into a IndexMap
	{
		mapIndex.insert(make_pair<double, BpTreeNode*>(n,pN));// insert in mapIndex
	}

	void deleteMap(double n)// decalre functions for deleting map with n
	{
		mapIndex.erase(n);// erase n
	}

	map <double, BpTreeNode*>* getIndexMap()// declare functions for getting IndexMap
	{ 
		return &mapIndex;// returns the address value of mapIndex
	}
};

#endif