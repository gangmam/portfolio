#ifndef _BPTREEDATANODE_H_
#define _BPTREEDATANODE_H_

#include "BpTreeNode.h"

class BpTreeDataNode : public BpTreeNode
{
private:
	map <double, map<int, StudentData*> > mapData;//define <double, map<int, StudentData*> > type map container
	BpTreeNode* pNext;
	BpTreeNode* pPrev;

public:
	BpTreeDataNode()// initializer
	{
		pNext = NULL;
		pPrev = NULL;
	}

	void setNext(BpTreeNode* pN)// define setNext
	{ 
		pNext = pN;
	}
	void setPrev(BpTreeNode* pN)// define setPrev
	{ 
		pPrev = pN;
	}
	BpTreeNode* getNext()// define getNext			
	{ 
		return pNext;
	}
	BpTreeNode* getPrev()// define getPrev
	{ 
		return pPrev;
	}	

	void insertDataMap(double avgGrade, map<int, StudentData*> m)// declare functions for inserting values into a DataMap
	{
		mapData.insert(make_pair<double, map<int, StudentData*> >(avgGrade,m));// insert in mapData
	}

	void deleteMap(double n)// decalre functions for deleting map with n
	{
		mapData.erase(n);// erase n
	}	

	map< double, map<int, StudentData*> > *getDataMap()	// declare functions for getting DataMap
	{ 
		return &mapData;// returns the address value of mapData
	}
};

#endif