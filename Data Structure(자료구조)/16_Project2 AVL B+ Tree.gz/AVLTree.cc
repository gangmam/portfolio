#include "AVLTree.h"

AVLTree::AVLTree(ofstream* fout)// initializer
{
	root=NULL;
	make_heap(vHeap.begin(), vHeap.end(), compare);// make heap has vector
	this->fout = fout;
}

AVLTree::~AVLTree()
{
}

bool AVLTree::Insert(StudentData* pStu)// Insert for AVL Tree inserting
{
	AVLNode* pNew = new AVLNode;// make new AVLNode to dynamic allocation
	pNew->setSD(pStu); // pNew has StudentData of pStu 
	char	*pName = pStu->getName();// pName is the name of pStu

	if(root == NULL)// AVL Tree has no data
	{
		root = pNew;// root is pNew
		return true;
	}
	AVLNode* a=root,*pa=NULL,*p=root,*pp= NULL,*rootSub = NULL;// declare and initialize variables of each AVLNode * type
	while(p!=NULL)// navigate to the new Node location
	{
		if(p->getBF()!=0)// if the balancefactor of p is not zero
		{
			a=p;
			pa=pp;
		}
		if(strcmp(pName , p->getSD()->getName()) < 0)// if the value of pName is less than the name of StudentData in p Node
		{
			pp=p;
			p= p->getLeft();// p to the moves left
		}
		else if(strcmp(pName , p->getSD()->getName()) > 0)// if the value of pName is greater than the name of StudentData in the p Node
		{
			pp=p;
			p = p->getRight();// p to the moves right
		}
	}
	if(strcmp(pName , pp->getSD()->getName()) < 0)// if pName is less than the name of StudentData in pp
	{
		pp->setLeft(pNew);// set pNew to pp leftNode
	}
	else
	{
		pp->setRight(pNew);// set pNew to pp rightNode
	}
	int d;// declaring a variable to determine L, R
	AVLNode *b, *c;
	if(strcmp(pName,a->getSD()->getName()) > 0)// if the value of pName is greater than the value of name in StudentData in a Node
	{
		b = p = a->getRight();// b, p is the rightNode of a
		d = -1;// case R
	}
	else
	{
		b = p = a->getLeft();// b,p is the leftNode of a
		d = 1;// case L
	}
	while(p!=pNew)// if p is not a newly dynamic allocation pNew Node
	{
		if(strcmp(pName , p->getSD()->getName()) > 0)// if the value of pName is greater than the name of StudentData in p Node
		{
			p->setBF(-1);// reset p balancefactor
			p = p->getRight();// move p to the right one space
		}
		else
		{
			p->setBF(1);// reset p balancefactor
			p = p->getLeft();// move p to the left one space
		}
	}
	if(a->getBF() == 0 || a->getBF()+d == 0)// if balancefactor adjustment is not required
	{
		a->setBF(a->getBF()+d);
		return true;
	}
	if(d==1)//L
	{
		if(b->getBF()==1)//L L case
		{
			a->setLeft(b->getRight());// change the pointing of the Node in the LL case
			b->setRight(a);
			a->setBF(0);// balancefactor readjustment
			b->setBF(0);// balancefactor readjustment
			rootSub = b;// rootSub = b;
		}
		else//L R case
		{
			c = b->getRight();// change the pointing of the Node in the L R case
			b->setRight(c->getLeft());
			a->setLeft(c->getRight());
			c->setLeft(b);
			c->setRight(a);
			switch(c->getBF())// according to case statement, change the pointing of the Node in the L R case
			{
			case 0:
				b->setBF(0);
				a->setBF(0);
				break;
			case 1:
				a->setBF(-1);
				b->setBF(0);
				break;
			case -1:
				b->setBF(1);
				a->setBF(0);
				break;
			}
			c->setBF(0);// balacefactor readjustment of c
			rootSub = c;// rootSub = c;
		}
	}
	else//R
	{
		if(b->getBF()==-1)//R R case
		{
			a->setRight(b->getLeft());// change the pointing of the Node in the R R case
			b->setLeft(a);
			a->setBF(0);// balancefactor readjustment
			b->setBF(0);
			rootSub = b;// rootSub = b;
		}
		else//R L case
		{
			c = b->getLeft();// c setting the location of the Node
			b->setLeft(c->getRight());// change the pointing of the Node in the R L case
			a->setRight(c->getLeft());
			c->setRight(b);
			c->setLeft(a);
			switch(c->getBF())/// according to case statement, change the pointing of the Node in the R L case
			{
			case 0:
				b->setBF(0);
				a->setBF(0);
				break;
			case 1:
				b->setBF(-1);
				a->setBF(0);
				break;
			case -1:
				a->setBF(1);
				b->setBF(0);
				break;
			}
			c->setBF(0);// balacefactor readjustment of c
			rootSub = c;// rootSub = c
		}
	}
	// the part that resets root
	if(pa==NULL)// if pa has no Node
	{
		root = rootSub;// root = rootSub
	}
	else if(a==pa->getLeft())// if pa leftNode is a
	{
		pa->setLeft(rootSub);// pa leftNode is rootSub
	}
	else
	{
		pa->setRight(rootSub);// pa rightNode is rootSub
	}
	return true;

}

bool AVLTree::Print()// Print for printing inorder type AVL Tree
{
	cout<<"==============PRINT_AVL================"<<endl;
	*fout<<"==============PRINT_AVL================"<<endl;
	stack<AVLNode*> s;// declaring stack s	 
	AVLNode* temp = root;//temp = root
	if(root == NULL)// AVL Tree has no data
	{
		return false;
	}
	while(1)// inorder printing method for ascending order
	{
		while(temp)
		{
			s.push(temp);// push a temp Node on the stack
			temp = temp->getLeft();// temp moves to leftNode
		}
		if(s.empty())// if Stack is empty
		{
			*fout<<"======================="<<endl;
			cout<<"======================="<<endl;
			return true;// complete all Node printing
		}
		temp = s.top();// moves temp to the Node location where it will be popped
		s.pop();// stack pop
		printStudentInfo(temp->getSD());// print StudentData of temp Node
		temp = temp->getRight();// temp moves to rightNode 
	}
	return true;
}


bool AVLTree::Search(char* name)// Search for searching Node AVL Tree
{
	AVLNode *pCur = root; // pCur is root Node
	if(root == NULL)// AVL Tree has nothing Node
	{
		return false;
	}
	if(name == NULL)// if name is not entered
	{
		return false;
	}
	while(pCur)// when pCur is not NULL, start searching with name
	{
		if(strcmp(pCur->getSD()->getName() , name) > 0)// if the name of studentData in pCur Node is larger than the value of name input
		{
			pCur = pCur ->getLeft();
		}
		else if(strcmp(pCur->getSD()->getName() , name) < 0)// if the name of studentData in pCur Node is lower than the value of name input
		{
			pCur = pCur ->getRight();
		}
		else// when name == pCur->getSD()->getName()
		{
			break;
		}
	}
	if(pCur == NULL)// if there was no pCur with the value of looking for name
	{
		return false;
	}
	cout<<"==============SEARCH_AVL================"<<endl;
	cout<<"SEARCH_AVL "<<name<<endl;
	*fout<<"==============SEARCH_AVL================"<<endl;
	*fout<<"SEARCH_AVL "<<name<<endl;
	StudentData* pSD = pCur->getSD();
	cout<<pSD->getStudentID()<<" "<<pSD->getName()<<" ";// printing student information
	cout<<pSD->getYear()<<" "<<pSD->getAvgGrade()<<" "<<endl;// printing student information
	*fout<<pSD->getStudentID()<<" "<<pSD->getName()<<" ";
	*fout<<pSD->getYear()<<" "<<pSD->getAvgGrade()<<" "<<endl;
	vHeap.push_back( make_pair( make_pair(pSD->getAvgGrade(), pSD->getStudentID()), pSD));// push the student information to vector
	push_heap(vHeap.begin(), vHeap.end(), compare);// push the student information in the heap
	cout<<"============================"<<endl;
	*fout<<"============================"<<endl;
	return true;
}

bool AVLTree::Rank()
{
	if(vHeap.empty())// if the heap is empty
	{
		return false;
	}
	cout<<"==============RANK================"<<endl;
	*fout<<"==============RANK================"<<endl;
	StudentData* pStu;
	while(!vHeap.empty())// if the heap is not empty
	{
		pStu = vHeap.front().second;
		pop_heap(vHeap.begin(), vHeap.end(), compare);// pop the student information in the heap
		vHeap.pop_back();// pop the student information in the vector
		printStudentInfo(pStu);// print the information of the student
	}
	cout<<"============================"<<endl;
	*fout<<"============================"<<endl;
	return true;
}

void AVLTree::printStudentInfo(StudentData* pStudentData)// printStudenInfo for printing student Information 
{
	cout<<pStudentData->getStudentID()<<" "<<pStudentData->getName()<<" ";// student information printing
	*fout<<pStudentData->getStudentID()<<" "<<pStudentData->getName()<<" ";
	cout<<pStudentData->getYear()<<" "<<pStudentData->getAvgGrade()<<endl;
	*fout<<pStudentData->getYear()<<" "<<pStudentData->getAvgGrade()<<endl;
	pStudentData->printGrade();// printing the subject information and grades of the corresponding grade
	cout<<endl;
	*fout<<endl;
}