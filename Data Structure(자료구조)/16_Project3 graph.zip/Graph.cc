#include "Graph.h" 

Graph::Graph(bool type, bool directed, bool weighted, int size)// graph class constructor
{
	m_Type = type;// get type
	m_Directed = directed;// get directed
	m_Weighted = weighted;// get weighted
	m_Size = size; // get size
}

Graph::~Graph()
{
}

bool Graph::getDirected()// function getDirected
{
	return m_Directed;// return directed
}

bool Graph::getWeighted()// function getWeighted
{
	return m_Weighted;// return weighted
}

int Graph::getSize()// function getSize
{
	return m_Size;//return size
}