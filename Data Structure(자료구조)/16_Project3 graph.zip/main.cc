#define _CRT_SECURE_NO_WARNINGS
#include "Manager.h"

int main(void)

{
	Manager ds;//using Manager class name ds
	ds.run("command.txt");//program start

	return 0;
}