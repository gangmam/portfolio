#include "GraphMethod.h"
#include <queue>
#include <vector>
bool BFS(Graph* graph, int baseV, ofstream* fout)// BFS function
{
	cout<<"===========BFS==========="<<endl;
	*fout<<"===========BFS==========="<<endl;
	int* visit = new int[graph->getSize()];// dynamic allocation for arrays
	memset(visit,0,4*(graph->getSize()));// visit initializer
	map<int,int>::iterator it;//declare iterator for m2
	queue<int> q;// declaration of q
	map<int,int> m2;
	visit[baseV] = 1;// expression visited
	q.push(baseV);
	while(!q.empty())// when q is not empty
	{
		graph->getIncidentEdges(baseV, &m2);// load the vertex associated with baseV and the corresponding weight
		it = m2.begin();// iterator initializer
		cout<<baseV<<" ";// print
		*fout<<baseV<<" ";
		while(it != m2.end())// push it to q while moving to it end
		{
			if(visit[it->first] == 0)// not visit vertex
			{
				visit[it->first] = 1;// visit now
				q.push(it->first);// push
			}
			it++;//iterator move forward
		}
		q.pop();
		if(!q.empty())
		{
			baseV = q.front();// baseV is front of queue
		}
	}
	cout<<endl;
	*fout<<endl;
	cout<<"========================="<<endl;
	*fout<<"========================="<<endl;
	delete []visit;// dynamic deallocation 
	return true;
}

bool DFS(Graph* graph, int baseV, ofstream* fout)// DFS function
{
	cout<<"===========DFS==========="<<endl;
	*fout<<"===========DFS==========="<<endl;
	int* visit = new int[graph->getSize()];// dynamic allocation for arrays
	memset(visit, 0, 4*(graph->getSize()));// visit initializer
	stack<int> s;// use stack
	map<int,int> m2;
	s.push(baseV);// push to stack baseV
	map<int,int>::iterator it;
	while(!s.empty())// if stack is not empty
	{
		graph->getIncidentEdges(baseV, &m2);// load the vertex associated with baseV and the corresponding weight
		if(visit[baseV] != 1)// if not visit vertex
		{
			cout<<baseV<<" ";//print
			*fout<<baseV<<" ";
			visit[baseV] = 1;// visit now
		}
		for(it = m2.begin() ; it != m2.end() ; it++)
		{
			if(visit[it->first] == 0)// if not visit vertex
			{
				s.push(it->first);//push to stack
				break;
			}
		}
		if(it == m2.end())
		{
			s.pop();//pop
		}
		if(!s.empty())
		{
			baseV = s.top();// if stack is not empty, baseV = top 
		}
	}
	cout<<endl;
	*fout<<endl;
	cout<<"========================"<<endl;
	*fout<<"========================"<<endl;
	delete []visit;// dynamic deallocation
	return true;
}

bool DFS_R(Graph* graph, vector<bool>* visit, int baseV, ofstream* fout)//DFS_R function
{
	map<int,int> m2;
	graph->getIncidentEdges(baseV, &m2);// load the vertex associated with baseV and the corresponding weight
	cout<<baseV<<" ";//print baseV
	*fout<<baseV<<" ";
	visit->at(baseV) = 1;// using vector for visit expression
	map<int,int>::iterator it;
	for(it = m2.begin(); it != m2.end() ; it++)//using iterator for repeatly 
	{
		for(int a = 0; a<graph->getSize(); a++)//finding connected vertex
		{
			if(it->first == a)//find connect vertex 
			{			
				if(visit->at(a) == 0)// not visit vertex
				{
					baseV = a;// changes baseV = a
					DFS_R(graph, visit, baseV, fout);// recursive fuction call to DFS_R
				}
			}
		}
	}
	return true;
}

bool Kruskal(Graph* graph, ofstream* fout)//vertexset �����Ҵ� �����ؾ���
{
	cout<<"=========Kruskal=========="<<endl;
	*fout<<"=========Kruskal=========="<<endl;
	vertexSet set(graph->getSize()) ;// for using vertexSet class
	map<int, int> m2;
	int temp = 0;
	int adder = 0;
	multimap<int, pair<int,int> > weight;// because graph has the same weight, using multipmap
	map<int, int>::iterator it;//define iterator
	multimap<int, pair<int,int> >::iterator it2;//define iterator
	for(int a = 0 ; a<graph->getSize() ; a++)
	{
		graph->getIncidentEdges(a, &m2);// load the vertex associated with baseV and the corresponding weight
		for(it = m2.begin() ; it != m2.end() ; it++)
		{
			weight.insert(make_pair(it->second, make_pair(a, it->first)));// insert to weight <= (weight,(from, to))
		}
	}
	it2 = weight.begin();// it2 location initializer
	while(it2 != weight.end())
	{
		if(set.Find(it2->second.first) != set.Find(it2->second.second))// compare vertices with different parents
		{
			set.Union(it2->second.first,it2->second.second);// connecting first and second
			cout<<it2->first<<" ";//print
			*fout<<it2->first<<" ";
			adder = adder + it2->first;//sum of weight
		}	
		it2++;
	}
	//handling exceptions when there are independent objects
	for(int a = 0 ; a<graph->getSize() ; a++)
	{
		if(temp == 0)
		{
			temp = set.Find(a);
		}
		else
		{
			if(temp != set.Find(a))//returns false if all parents are not equal
			{
				return false;
			}
		}
	}
	cout<<endl;
	*fout<<endl;
	cout<<adder<<endl;
	*fout<<adder<<endl;
	cout<<"========================="<<endl;
	*fout<<"========================="<<endl;
	return true;
}


bool Dijkstra(Graph* graph, int baseV, ofstream* fout)//Dijkstra function
{
	cout<<"=========Dijkstra========="<<endl;
	*fout<<"=========Dijkstra========="<<endl;
	int* visit = new int[graph->getSize()];// dynamic allocation for visit array
	memset(visit, 0, 4*(graph->getSize()));//visit initializer
	int* dest = new int[graph->getSize()];// dynamic allocation for dest array
	memset(dest,-1,4*(graph->getSize()));//dest initializer
	int tempa;
	int** course = NULL;// declaration of a two-dimensional array
	//dynamic allocation of two-dimensional arrays
	course = new int*[graph->getSize()];
	for(int i = 0; i<graph->getSize() ; i++)
	{
		course[i] = new int[graph->getSize()];
	}
	for(int a = 0; a<graph->getSize() ; a++)
	{
		for(int b = 0 ; b<graph->getSize() ; b++)
		{
			course[a][b] = 0;// initialize the value
		}
	}
	visit[baseV] = 1;// visit expresion baseV vertex
	int origin = baseV; // variables that have the value of baseV first
	map<int,int> m2;
	map<int, int>::iterator it;
	int temp = 0;
	int vertex = 0;
	int independent = 0;
	while(1)
	{
		int count = 0;
		for(int a = 0; a<graph->getSize(); a++)
		{
			if(visit[a] == 1)
			{
				count++;// how many vertex you visited
			}
		}
		if(count == graph->getSize())// 
		{
			dest[origin] = dest[origin] + 1;//because dest[origin] = -1
			for(int a = 0; a<graph->getSize() ; a++)// if visited all vertex
			{
				cout<<"["<<a<<"]"<<" ";//
				*fout<<"["<<a<<"]"<<" ";
				int temp2 = a;
				independent = 0;
				while(temp2 != origin)
				{
					tempa = 0;
					for(int temp1 = 0 ;course[temp1][temp2] == 0 && temp1 != graph->getSize() ; temp1++)
					{
						tempa++;
					}
					if(tempa == graph->getSize())// if no vertex is assoiated
					{
						independent = tempa;
						cout<<" x"<<" ";// indication of a road that can not go
						*fout<<" x"<<" ";
						temp2 = origin;//Exit while
					}
					else// otherwise, print
					{
						cout<<temp2<<" ";
						*fout<<temp2<<" ";
						temp2 = tempa;
					}
				}
				if(independent != graph->getSize())//if origin can go vertex
				{
					cout<<temp2<<" ";//print
					*fout<<temp2<<" ";
					cout<<"("<<dest[a]<<")"<<endl;
					*fout<<"("<<dest[a]<<")"<<endl;
				}
				else
				{
					cout<<endl;
					*fout<<endl;
				}
			}
			break;
		}
		temp = 0;
		vertex = 0;
		graph->getIncidentEdges(baseV, &m2);// load the vertex associated with baseV and the corresponding weight
		for(it = m2.begin(); it != m2.end() ; it++)// start of the algorithm to find the shortest path from the starting vertex
		{
			if(visit[it->first] ==0)// if not visit vertex
			{
				if(dest[it->first] == -1)// path without weight value
				{
					if(dest[baseV] == -1)// when baseV is the vertex of the first start
					{
						dest[it->first] = dest[baseV]+it->second+1;
						course[baseV][it->first] = 1;//store the shortest connection point in the course
					}
					else// when baseV is changed more than once
					{
						dest[it->first] = dest[baseV]+it->second;// update the shortest path of the vertex
						course[baseV][it->first] = 1;//store the shortest connection point in the course
					}
					
				}
				else if(dest[it->first] > dest[baseV]+it->second)// when we found a shorter route
				{ 
					dest[it->first] = dest[baseV]+it->second;// update the shortest path of the vertex
					course[baseV][it->first] = 1;
					for(int a = 0 ; a<graph->getSize() ; a++)//when you find the shortest route, update what you wrote in the course
					{
						if(a != baseV)
						{
							course[a][it->first] = 0;
						}
					}
				}
			}

		}
		for(int a = 0; a<graph->getSize() ; a++)
		{
			if(dest[a] != -1 && visit[a] == 0)//find a vertex whose path has the least weight among the updated nodes without visiting
			{
				if(temp == 0)// start browsing for the first time
				{
					temp = dest[a];
					vertex = a;
				}
				else// continue searching for a vertex that has the least wieght among that meet the condition
				{
					if(temp > dest[a])
					{
						temp = dest[a];
						vertex = a;
					}
				}
			}

		}
		//exception handling when there is an independent vertex
		if(temp == 0)
		{
			for(int c = 0; c<graph->getSize() ; c++)
			{
				if(c != origin && dest[c] == -1)
				//if there is a node that is not connected to origin and dest is not up-to-date
				{
					vertex = c;
					independent++;
					break;
				}
			}
		}

		baseV = vertex;//update baseV
		visit[baseV] = 1;// visit now
	}
	cout<<"========================="<<endl;//print
	*fout<<"========================="<<endl;
	delete []visit;//dynamic deallocation
	delete []dest;
	delete []course;
	return true;
}
