#ifndef _MANAGER_H_
#define _MANAGER_H_

#include "GraphMethod.h"

class Manager//Manager class
{
private:
	Graph* graph;
	ofstream fout;
	int load;

public:
	Manager();
	~Manager();

	void	run(const char * command_txt);//run fucntion declare
	
	bool	LOAD(char* filename);//LOAD fucntion declare
	bool	PRINT();//PRINT fucntion declare
	
	bool	mDijkstra(int from);//mDijkstra fucntion declare
	bool	mKruskal();//mKruskal fucntion declare
	bool	mBFS(int ver);//mBFS fucntion declare
	bool	mDFS_R(int ver);//mDFS_R fucntion declare
	bool	mDFS(int ver);// mDFS fucntion declare

	void	printErrorCode(int n);	//printErrorCode fucntion declare
};

#endif