#ifndef _GRAPHMETHOD_H_
#define _GRAPHMETHOD_H_

#include "ListGraph.h"
#include "MatrixGraph.h"
#include "vertexSet.h"

bool BFS(Graph* graph, int vertex, ofstream* fout);//BFS function delcare
bool DFS(Graph* graph, int vertex, ofstream* fout);//DFS function delcare
bool DFS_R(Graph* graph, vector<bool>* visit, int vertex, ofstream* fout);//DFS_R function delcare
bool Kruskal(Graph* graph, ofstream* fout);//Kruskal function delcare
bool Dijkstra(Graph* graph, int vertex, ofstream* fout);// Dijkstra function delcare
#endif