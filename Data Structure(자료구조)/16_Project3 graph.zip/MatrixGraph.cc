#include "MatrixGraph.h"

MatrixGraph::MatrixGraph(bool type, bool directed, bool weighted, int size) : Graph(type, directed, weighted, size)
// MatrixGrap constructor 
{
	// dynamic allocation of two-dimensional arrays
	m_Mat = (int**)malloc(sizeof(int*)*(size));
	for(int i=0;i<size;i++)
	{
		m_Mat[i] = (int*)malloc(sizeof(int)*(size));
		for(int j=0;j<size;j++)
        m_Mat[i][j] =0;//initialize the value
	}
}

MatrixGraph::~MatrixGraph()//MatrixGraph destructor
{
	delete []m_Mat;//dynamic deallocation
}

void MatrixGraph::getIncidentEdges(int vertex, map<int, int>* m)
//getIncidentEdges function
{	
	m->clear();//map clear
	for(int a = 0; a<getSize() ; a++)
	{
		if(m_Mat[vertex][a] != 0)//if vertext are connected
		{
			m->insert(make_pair(a, m_Mat[vertex][a]));
		}
	}
}

void MatrixGraph::insertEdge(int from, int to, int weight)
//insertEdge fucntion 
{
	m_Mat[from][to] = weight;//store the value of weight from the linked from, to
}

bool	MatrixGraph::printGraph(ofstream* fout)//printGraph function
{
	cout<<"==========PRINT=========="<<endl;
	*fout<<"==========PRINT=========="<<endl;
	if(getSize() == 0)//if graph is not implemented
	{
		return false;
	}
	for(int a = 0; a<getSize() ; a++)
	{
		for(int b = 0; b<getSize() ; b++)
		{
			cout<<m_Mat[a][b]<<" ";//print the value of a two-dimensional array
			*fout<<m_Mat[a][b]<<" ";
		}
		cout<<endl;
		*fout<<endl;
	}
	cout<<"========================="<<endl;//print
	*fout<<"========================="<<endl;
	return true;
}
