#include "Manager.h"

Manager::Manager()//Manager  constructor
{
	fout.open("log.txt", ios::app);//log file open
	load = 0;// judge duplication of LOAD
}

Manager::~Manager()// Mager destructor
{
	fout.close();// log file close
}

void Manager::run(const char* command_txt)// run function
{
	ifstream fin;		fin.open(command_txt);//file open => command.txt
	int check = 0;//if Loaded fail, other commands are fail
	if(!fin)//if the file does not exist
	{
		cout<<"[ERROR] command file open error!"<<endl;
		fout<<"[ERROR] command file open error!"<<endl;
		return;
	}
	char* rest = NULL;
	char*	str=NULL;
	char*	str2=NULL;
	char	buf[128]={0};

	while(fin.getline(buf, 64))
	{
		str=strtok_r(buf, " ", &rest);	
		
		if(strcmp(str, "LOAD") == 0)//when the LOAD command is used
		{
			if((str=strtok_r(NULL, " ",&rest)) == NULL )// when graph.txt is not used
			{
				printErrorCode(100);
				check = 1;
			}
			if(load == 1)//case of redundant loads
			{
				printErrorCode(100);
				check = 1;
			}
			else if((str2=strtok_r(NULL, " ",&rest)) != NULL || !LOAD(str))
			// if any command is used after graph.txt, or the return type of the LOAD function is false
			{
				printErrorCode(100);
				check = 1;
			}
			load = 1;
		}
		else if(strcmp(str, "PRINT") == 0)//when the PRINT command is used
		{
			if(check == 1)//if LOAD is failed
			{
				printErrorCode(200);
			}
			else
			{
				PRINT();
			}
		}
		else if(strcmp(str, "BFS")== 0)// when the BFS command is used
		{
			if(check == 1)// if LOAD is failed
			{
				printErrorCode(300);
			}
			else
			{
				str=strtok_r(0, " ",&rest);
				if(str == NULL)// if the reference vertex is not defined
				{
					printErrorCode(300);
				}
				else if(atoi(str) >= graph->getSize())//if the size of a nonexistent vertex is reached
				{
					printErrorCode(300);
				}
				else
				{
					if(graph->getDirected() ==0 && graph->getWeighted() == 0)
					// run BFS only when directed and weighted are 0
					{
						mBFS(atoi(str));
					}
					else
					{
						printErrorCode(300);
					}
				}
			}
		}	
		else if(strcmp(str, "DFS")== 0)// when the DFS command is used
		{
			if(check == 1)// if LOAD is failed
			{
				printErrorCode(400);
			}
			else
			{
				str=strtok_r(0, " ",&rest);
				if(str == NULL)// if the reference vertex is not defined
				{
					printErrorCode(400);
				}
				else if(atoi(str) >= graph->getSize())//if the size of a nonexistent vertex is reached
				{
					printErrorCode(400);
				}
				else
				{
					if(graph->getDirected() == 0 && graph->getWeighted() == 0)
					// run DFS only when directed and weighted are 0
					{
						mDFS(atoi(str));
					}
					else
					{
						printErrorCode(400);
					}
				}
			}
		}
		else if(strcmp(str, "DFS_R")== 0)// when the DFS_R command is used
		{
			if(check == 1)// if LOAD is failed
			{
				printErrorCode(500);
			}
			else
			{
				str=strtok_r(0, " ",&rest);
				if(str == NULL)// if the reference vertex is not defined
				{
					printErrorCode(500);
				}
				else if(atoi(str) >= graph->getSize())//if the size of a nonexistent vertex is reached
				{
					printErrorCode(500);
				}
				else
				{
					if(graph->getDirected() == 0 && graph->getWeighted() == 0)
					// run DFS_R only when directed and weighted are 0
					{
						mDFS_R(atoi(str));
					}
					else
					{
						printErrorCode(500);
					}
				}
			}
		}
		else if(strcmp(str, "Kruskal")== 0)//when Kruskal command is used
		{
			if(check == 1)//if LOAD is failed
			{
				printErrorCode(600);
			}
			else
			{
				if(mKruskal() == false)//if mKruskal return type is false
				{
					cout<<endl;
					printErrorCode(600);
				}
			}
		}
		else if(strcmp(str, "Dijkstra")== 0)//when Dijkstra command is used
		{
			if(check == 1)// if LOAD is failed
			{
				printErrorCode(700);
			}
			else
			{
				str=strtok_r(0, " ",&rest);
				if(str == NULL)// if the reference vertex is not defined
				{
					printErrorCode(700);
				}
				else if(atoi(str) >= graph->getSize())//if the size of a nonexistent vertex is reached
				{
					printErrorCode(700);
				}
				else
				{
					if(graph->getDirected() == 1 && graph->getWeighted() == 1)
					// run Dijkstra only when directed are 1 and weighted are 1
					{
						mDijkstra(atoi(str));
					}
					else
					{
						printErrorCode(700);
					}
				}
			}
		}
		else if(strcmp(str, "EXIT")== 0)//if EXIT commmand is used
		{
			return;// program exit
		}
		fout<<endl;
	}	
	delete graph;// dynamin deallocation
	fin.close();//file close
}
bool Manager::mKruskal()
{
	int a = 0;
	if(graph->getDirected() == 0 && graph->getWeighted() == 1)
	// run mKruskal only when directed are 0 and weighted are 1
	{
		a = Kruskal(graph, &fout);
	}
	else
	{
		return false;
	}
	if(a == 0)//if Kruskal return type is false
	{
		return false;
	}
	else
	{
		return true;
	}
}
bool Manager::mDijkstra(int from)// mDijkstra function
{
	Dijkstra(graph, from, &fout);//use Dijkstra function
	return true;
}
bool Manager::mDFS_R(int ver)//m_DFS_R function
{
	cout<<"==========DFS_R==========="<<endl;
	fout<<"==========DFS_R==========="<<endl;
	vector<bool> temp(100,0);//define for using vector
	DFS_R(graph, &temp, ver, &fout);// use DFS_R function
	cout<<endl;//print
	fout<<endl;
	cout<<"========================="<<endl;
	fout<<"========================="<<endl;
	return true;
}
bool Manager::mDFS(int ver)//mDFS function
{
	DFS(graph, ver, &fout);//use DFS function
	return true;
}
bool Manager::mBFS(int ver)//mBFS function
{
	BFS(graph, ver, &fout);//us BFS function
	return true;
}
bool Manager::PRINT()// PRINT function
{
	int a = 0;
	a = graph->printGraph(&fout);
	if(a == 0)//if the return type of graph-> printGraph is false
	{
		printErrorCode(200);
	}
	return true;
}
bool Manager::LOAD(char* filename)//LOAD fucntion
{
	char*	str=NULL;
	char*	str2=NULL;
	char* rest = NULL;
	char	buf[128]={0};
	char	buf2[128]={0};
	char	buf3[128]={0};
	char* type = 0;
	int directed = 0;
	int weighted = 0;
	int size = 0;
	int vertex_to = 0;
	int vertex_from = 0;
	int graph_size = 0;
	int graph_weight = 0;
	int count1 = 0;//
	int count2 = 0;//
	int count3 = 0;//
	int count4 = 0;//
	ifstream fin;
	fin.open("graph.txt");// graph.txt file open
	if(!fin)//if file not exist
	{
		return false;
	}
	fin.getline(buf,64);
	str = strtok_r(buf," ",&rest);// str is graph type
	type = str;
	str = strtok_r(0," ",&rest);//str is graph directed
	directed = atoi(str);
	str = strtok_r(0," ",&rest);//str is graph weighted
	weighted = atoi(str);
	fin.getline(buf2,64);
	str = strtok_r(buf2, " ",&rest);// str is graph size
	size = atoi(str);
	if(strcmp(type,"L") == 0)//if graph type is L
	{
		graph = new ListGraph(type, directed, weighted, size);
		// receive dynamic allocation of ListGraph
		while(fin.getline(buf3,64))
		{
			str = strtok_r(buf3, " ",&rest);
			str2 = strtok_r(0, " ",&rest);
			if(str2 == NULL)// determine  <from vertex> to <to vertex>
			{
				vertex_from = atoi(str);//from vertex
				count1++;
				if(count1 > graph->getSize())//exception handling
				{
					return false;
				}
			}
			else
			{
				vertex_to = atoi(str);//to vertex
				count2++;
				if(count2 > graph->getSize()*graph->getSize())//exception handling
				{
					return false;
				}
				graph_weight = atoi(str2);//weight 
				graph->insertEdge(vertex_from, vertex_to, graph_weight);
				//ListGraph insertEdge function call
				count3++;
			}
		}
		if(count3 < graph->getSize())//exception handling
		{
			return false;
		}
		if(count3 > graph->getSize()*(graph->getSize()-1))//exception handling
		{
			return false;
		}
		cout<<"==========LOAD=========="<<endl;
		fout<<"==========LOAD=========="<<endl;
		cout<<"Success"<<endl;
		fout<<"Success"<<endl;
		cout<<"========================"<<endl;
		fout<<"========================"<<endl;
		return true;
	}
	else if(strcmp(type,"M") == 0)// if graph type is M
	{
		int a = 0;
		
		graph = new MatrixGraph(type, directed, weighted, size);
		// receive dynamic allocation of MatrixGraph
		while(fin.getline(buf3,64))
		{
			int b = 0;
			str2 = strtok_r(buf3, " ", &rest);
			count4++;
			if(count4 > graph->getSize()*graph->getSize())//exception handling
			{
				return false;
			}
			if(atoi(str2) != 0)// if have a connection
			{
				graph->insertEdge(a,b, atoi(str2));
				//MatrixGraph insertEdge fucntion call
			}
			b++;
			for(; b<size ; b++)
			{
				str2 = strtok_r(0, " ", &rest);
				count4++;
				if(atoi(str2) != 0)
				{
					graph->insertEdge(a,b, atoi(str2));
					//MatrixGraph insertEdge fucntion call
				}
			}
			if((str2 = strtok_r(0, " ", &rest)) != NULL)//exception handling
			{
				return false;
			}
			
			a++;
		}
		if(count4 < graph->getSize()*graph->getSize())//exception handling
		{
			return false;
		}
		cout<<"==========LOAD=========="<<endl;
		fout<<"==========LOAD=========="<<endl;
		cout<<"Success"<<endl;
		fout<<"Success"<<endl;
		cout<<"========================"<<endl;
		fout<<"========================"<<endl;
		return true;
	}
			

}
	


void Manager::printErrorCode(int n)//print ErrorCode function
{
	cout<<"======== ERROR ========"<<endl;//print
	fout<<"======== ERROR ========"<<endl;
	cout<<n<<endl;
	fout<<n<<endl;
	cout<<"======================="<<endl;
	fout<<"======================="<<endl;
}