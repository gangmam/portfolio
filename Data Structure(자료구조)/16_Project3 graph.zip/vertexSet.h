#ifndef _VERTEXSET_H_
#define _VERTEXSET_H_

#include <iostream>

class vertexSet//vertexSet class
{
private:
	int* m_Parent;
	int m_Size;

public:
	vertexSet(int size)//vertexSet class construction
	{
		m_Parent = new int[size];//dynamic allocation of arrays
		for(int a= 0; a<size ; a++)
		{
			m_Parent[a] = -1;// value initialize
		}
	}
	~vertexSet()// vertexSet destructor
	{
		delete []m_Parent;//dynamic deallocation
	}

	int Find(int ver)//Find fuction
	{
		while(m_Parent[ver] >= 0)//find and navigate parent vertices
		{
			ver = m_Parent[ver];
		}
		return ver;// returns the connected parent vertex
	}

	void Union(int v1, int v2)//Union is functions that connect to each other
	{
		while(m_Parent[v1] >= 0)//explore Parents
		{
			v1 = m_Parent[v1];
		}
		while(m_Parent[v2] >= 0)//explore Parents
		{
			v2 = m_Parent[v2];
		}
		m_Parent[v1] = v2;//connect each other
	}
};


#endif
