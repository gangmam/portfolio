#ifndef _GRAPH_H_
#define _GRAPH_H_

#include <iostream>
#include <cstring>
#include <string.h>
#include <fstream>
#include <map>
#include <set>
#include <math.h>
#include <vector>
#include <algorithm>
#include <deque>
#include <queue>
#include <stack>

using namespace std;

#define MAX 999999

class Graph{
protected:
	bool	m_Type;//0:List 1:Matrix
	bool	m_Directed;//0:undirected 1:directed
	bool	m_Weighted;//0:unweighted 1:weighted;
	int	m_Size;//graph size

public:
	Graph(bool type, bool directed, bool weighted, int size);//Graph constructor
	virtual ~Graph();//Graph destuctor

	bool getDirected();//getDirected function delcare
	bool getWeighted();//getWeighted function delcare
	int	getSize();//getSize function delcare
	
	virtual void getIncidentEdges(int vertex, map<int, int>* m) = 0;//virtual function delcare
	virtual void	insertEdge(int from, int to, int weight) = 0;//virtual function delcare
	virtual	bool	printGraph(ofstream* fout) = 0;// virtual function delcare
};

#endif