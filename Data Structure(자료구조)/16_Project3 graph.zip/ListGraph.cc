#include "ListGraph.h"

ListGraph::ListGraph(bool type, bool directed, bool weighted, int size) : Graph(type, directed, weighted, size)
// ListGraph constructor
{
	m_List = new map<int,int>[size];//m_List dynamic allocation
}

ListGraph::~ListGraph()//ListGraph destructor
{
	delete []m_List;//dynamic deallocation
}

void ListGraph::getIncidentEdges(int vertex, map<int, int>* m)// getIncidentEdges function
//receives the weight of the vertex associated with the vertex associated with the vertex
{
	*m = m_List[vertex];
}

void ListGraph::insertEdge(int from, int to, int weight)//InsertEdge function
{
	m_List[from].insert(make_pair(to, weight));// from, to, and weight information stored in m_List
}

bool	ListGraph::printGraph(ofstream* fout)//printGraph function
{
	cout<<"==========PRINT=========="<<endl;
	*fout<<"==========PRINT=========="<<endl;
	map<int, int>::iterator it;
	if(getSize() == 0)//if graph is not implemented
	{
		return false;
	}
	for(int a = 0 ; a < getSize(); a++)// move from vertext
	{
		cout<<a<<" ";
		*fout<<a<<" ";
		for(it = m_List[a].begin(); it != m_List[a].end() ; it++)
		//prints the weight information of to and to associated with from
		{
			cout<<it->first<<","<<it->second<<" ";
			*fout<<it->first<<","<<it->second<<" ";
		}
		cout<<endl;
		*fout<<endl;
	}
	cout<<"========================="<<endl;
	*fout<<"========================="<<endl;
	return true;
}

