#include "Manager.h"


int main(void)//main
{
	Manager manager;
	manager.run("command.txt");// execution command1
	
	return 0;

}
