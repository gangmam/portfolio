///////////////////////////////////////////////////////////////////////
// File Name : Assignment#3(srv.c)//
// Date : 2017/06/07 //
// Os : Ubuntu 12.04 LTS 64bits //
// Author : kim tae seok//
// Student ID : 2013722082 //
// ----------------------------------------------------------------- //
// Title : System Programming Assignment #3 ( ftp server_client ) //
///////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <pwd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/wait.h>
#include <signal.h>
#include <fcntl.h>
#define FLAGS (O_RDWR | O_CREAT | O_TRUNC)
#define ASCII_MODE (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)
#define BIN_MODE (S_IXUSR | S_IXGRP | S_IXOTH)

#define BUF_SIZE 256
#define MAX_BUF 256
void print_log(char* path, struct sockaddr_in* client, char* buf, int mode);
void complete_transmission();
void failed_transmission();
void print();// print child process information
void sh_chld(int); // signal handler function for SIGCHLD
//void sh_alrm(int); // signal handler fucntion for SIGALRM
void sh_int(int);
//int client_info(struct sockaddr_in* client);
//int client_info2(struct sockaddr_in* client);
int f_index = 0;
char MODE[100] = "BINARY";
int num = 0;// number of child process 
char store_path[100] = {0};// store logfile
char u_name[100] = {0};
int client_fd;
int sockfd;
time_t oldtime;
struct sockaddr_in client_addr;
int log_auth(int connfd, char* username_temp, struct sockaddr_in* cli);
int user_match(char *user);
int user_match2(char *user, char *passwd);
/////structure of child process information//////
typedef struct Info
{	
	//char user[100];
	int port;
	int pid;
	int time;
	long oldtime;
}Info;
///////////structure name is Info///////////////////////
Info information[100];// using of structure array
int main(int argc, char ** argv)
{
	getcwd(store_path,100);
	//////////////////////////////////
	int fd[2];
	int state = pipe(fd);
	if(state == -1)
	{
		exit(1);
	}
	////////////////////////////////////
	char srv_print[100] = {0};
	int program_control = 0;
	char cl_IP[100] = {0};
	char CliIP[100] = {0};
	char copy[100] = {0};
	int result_index = 0;
	char result_buff[10000]= {0};
	char temp2[100] = {0};
	char temp[100] = {0};
	char temp_arr[100] = {0};
	char sort[150][150] = {0};
	char* arr = NULL;
	char* arr2 = NULL;
	char command[100] = {0};
	char buf[BUF_SIZE];
	int n;
	struct sockaddr_in server_addr, client_addr;
	int server_fd;
	int len;
	int port;
	FILE *fp_checkIP;
	if(argv[1] == NULL)//error portnumber exception case
	{
		write(1,"error_portnumber",17);
		write(1,"\n",2);
		exit(1);
	}
	else if(argv[2] != NULL)//error parameter exception case
	{
		write(1,"invalid_portnumber",19);
		write(1,"\n",2);
		exit(1);
	}
	//for using signal handler function 
	//signal(SIGALRM, sh_alrm);
	signal(SIGCHLD, sh_chld);
	signal(SIGINT, sh_int);
	//signal(SIGKILL, sh_kill);
	////////////////////////////////////////////////////////////
	char log_temp[100] = {0};
	memset(log_temp, 0, strlen(log_temp));
	strcpy(log_temp, "Server is started\n");
	print_log(store_path, &client_addr, log_temp, 0);
	////////////////////////////////////////////////////////////
	////////////////socket communication/////////////////////
	if((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	// error socket exception case
	{
		write(1, "error_socket", 13);
		write(1,"\n",2);
		exit(1);
	}
	//store information about the server
	memset(&server_addr, 0 , sizeof(server_addr));

	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	server_addr.sin_port = htons(atoi(argv[1]));

	if(bind(server_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)))
	// error bind exception case
	{
		write(1,"error_bind",11);
		write(1,"\n",2);
		exit(1);
	}
	if(listen(server_fd, 5))//error listen exception case
	{	
		write(1,"error_listen",13);
		write(1,"\n",2);
		exit(1);
	}
	//////////////////////////////////////////////////////
	//omitting comments for duplicate algorithms,
	//////////////////////////////////////////////////////
	while(1)
	{
		///////////////////////////////////////////////////
		// accept() -> fork()
		// fork()  > 0  => parent process 
		// fork()  == 0 => child process
		// fork()  < 0 => fork_eror
		//////////////////////////////////////////////////
		program_control = 0;
		fp_checkIP = fopen("access.txt", "r");// file open "access.txt" read only permission
		pid_t pid;//for using getpid()
		len = sizeof(client_addr);
		if((client_fd = accept(server_fd, (struct sockaddr*)&client_addr, &len)) == -1)
		// error accept exception case
		{
			memset(buf, 0 , strlen(buf));
			strcpy(buf,"accept_error!\n");
			strcpy(result_buff, buf);
			write(client_fd, result_buff, strlen(result_buff));
			write(1, result_buff, strlen(result_buff));
			exit(1);
		}
		
		/////////////////////////////////////////////////////////////////////////////////////////////
		//client_info2(&client_addr);// print client information
		memset(temp, 0, strlen(temp));
		strcpy(CliIP, inet_ntoa(client_addr.sin_addr));// client -> IP address
		//CliIP is client IP dotted decimal//
	
		strcpy(copy, CliIP);
		int a = 0;
		//dotted decimal client IP is stored cl_IP(array)//
		arr = strtok(copy, ".");
		cl_IP[a++] = atoi(arr);

		arr = strtok(NULL , ".");
		cl_IP[a++] = atoi(arr);

		arr = strtok(NULL , ".");
		cl_IP[a++] = atoi(arr);

		arr = strtok(NULL, ".");
		cl_IP[a++] = atoi(arr); 

		int q = 0;
		int equal_count  = 0;

		memset(temp, 0 ,strlen(temp));
		//checkIP is variable to check if fscanf has been executed properly//
		//checkIP = 1 => OK, checkIP != 1 => error 
		int checkIP = fscanf(fp_checkIP, "%s", temp);
		// fscanf is read one line and store in temp
		while(checkIP == 1)//loop of perform all sentences until read
		{
			arr = strtok(temp, ".");
			equal_count = 0; // determined whether the IP are the same.
			// equal_count = 4 is same IP(client IP = access.txt -> IP)
			for(q = 0 ; q < a ; q++)// algorithm of confirm IP
			{
				if(arr != NULL)
				{
					if(strcmp(arr, "*") == 0)// '*' is wildcard
					{
						equal_count++;
					}
					else if(atoi(arr) == cl_IP[q])
					{
						equal_count++;
					}
					if(equal_count == 4)// case of different IP 
					{
						break;
					}
				}
				else
				{
					break;
				}
				arr = strtok(NULL, ".");
			}
			if(equal_count == 4)
			{
				break;
			}
			memset(temp, 0 , strlen(temp));
			checkIP = fscanf(fp_checkIP, "%s", temp);//read to temp next sentence
		}
		//////////////////////////////////////////////////
		if(equal_count == 4)// if client ip is allowed IP
		{
			FILE* welcom_file;
			char welcom_time[100] = {0};
			char welcom_message[300] = {0};
			memset(welcom_message, 0, 300);
			strcpy(welcom_message, "220 ");

			memset(temp, 0, strlen(temp));
			time_t tit;
			struct tm* l_tit;
			time(&tit);
			l_tit = localtime(&tit);
			strftime(welcom_time, 100, "%c", l_tit);
			welcom_file = fopen("motd", "r");
			fgets(temp, 200, welcom_file);
			arr = strtok(temp, "%");
			strcpy(temp, arr);
			strcat(temp, welcom_time);
			strcat(temp, ") ready.");
			strcat(welcom_message, temp);
			write(client_fd, welcom_message, strlen(welcom_message));// make welcom message and welcome message send to client
			////////////////////////////////////////////////////////////////
			strcat(welcom_message, "\n");
			print_log(store_path, &client_addr, welcom_message, 1);
			memset(srv_print, 0, strlen(srv_print));
			strcpy(srv_print, welcom_message);
			write(1, srv_print, strlen(srv_print));
			////////////////////////////////////////////////////////////////
			//Welcom message

		}
		else// if client if is not allowed IP
		{
			program_control++;
			memset(temp, 0, strlen(temp));
			strcpy(temp, "** It is NOT authentical client **\n");
			write(1, temp, strlen(temp));
			memset(temp, 0, strlen(temp));
			strcpy(temp, "431 This client can't access. Close the session.");// contorl message sen to client
			write(client_fd, temp, strlen(temp));
			//////////////////////////////////////////////////////////////////
			strcat(temp, "\n");
			print_log(store_path, &client_addr, temp, 1);
			memset(srv_print, 0, strlen(srv_print));
			strcpy(srv_print, temp);
			write(1, srv_print, strlen(srv_print));
			//////////////////////////////////////////////////////////////////
			close(client_fd);
		}
		//char u_name[100] = {0};
		

		///////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		if(program_control == 0)
		{
			num++;// num is number of child process
			///////////////////////////////////////////////
			pid = fork();// generate  child process
			///////////////////////////////////////////////
			if(pid < 0)// fork exception case
			{
				memset(buf, 0 , strlen(buf));
				strcpy(buf,"fork_error!\n");
				strcpy(result_buff, buf);
				write(client_fd, result_buff, strlen(result_buff));
				write(1, result_buff, strlen(result_buff));
			}
			else if(pid == 0)// behavior of the child process
			{
				getcwd(store_path,100);	
				time_t cli_oldtime;
				time(&cli_oldtime);
				//puts(inet_ntoa(client_addr.sin_addr));
				//////////////allowed user log_in///////////////////////
				if(log_auth(client_fd, u_name, &client_addr) == 0) // start log_in for allowed user
				{ 
					
					memset(temp, 0 ,strlen(temp));
					strcpy(temp,"** Fail to log-in **\n");// fail to log_in
					write(1, temp, strlen(temp));
					program_control++;

					//write(fd[1], u_name, strlen(u_name));
					memset(temp, 0 , strlen(temp));
					sprintf(temp, "LOG_FAIL\n");
					print_log(store_path, &client_addr, temp, 1);
					//connection over
				}
				else
				{
					memset(temp, 0 ,strlen(temp));
					strcpy(temp,"** Success to log-in **\n");// success to log_in
					write(1, temp, strlen(temp));

					//write(fd[1], u_name, strlen(u_name));
					memset(temp, 0 , strlen(temp));
					sprintf(temp, "LOG_IN\n");
					print_log(store_path, &client_addr, temp, 1);
					//success log_in
				}
				
				if(program_control == 0)// allowed IP and allowed user
				{
					memset(temp, 0, strlen(temp));
					while(1)
					{	//repeatedly communicates with client
						//print_log(NULL, &client_addr, NULL, 0);
						memset(buf, 0, sizeof(buf));
						memset(temp2, 0 ,strlen(temp2));

						read(client_fd, buf, 256);//receive from client
						//puts(buf);
						//command
						///////////////////////////////////////////

						char log_copy[100] = {0};
						memset(log_copy, 0, strlen(log_copy));
						strcpy(log_copy, buf);
						memset(temp, 0 , strlen(temp));
						sprintf(temp, "%s\n", buf);
						print_log(store_path, &client_addr, temp, 1);
						///////////////////////////////////////////
						char buf_temp[100] = {0};
						strcpy(buf_temp, buf);
						strcpy(temp2, buf);

						arr = strtok(buf, " \n");//extract command only

						memset(result_buff, 0 , strlen(result_buff));
						memset(temp, 0 , strlen(temp));

						sprintf(temp,"%s [%d]\n", temp2, getpid());
						//print command and pid of client

						memset(temp2, 0 ,strlen(temp2));
						write(1,temp, strlen(temp));
						memset(temp_arr, 0 , strlen(temp_arr));
						//receives a message from the client
						//////////////////////////////////////////
						//stop command
						strcpy(temp2, buf);
						int q,a;
						int row_count = 0;
						int temp_count = 0;
						// initializing a two dimensional array
						for(a = 0 ; a < 150 ; a++)
						{
							memset(sort[a], 0, strlen(sort[a]));

						}
						int count = 0;
						///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
						// server system call function
						// ================================================================= //////////////////////////////////////////////////////////////////////////
						// /////////////////////////////command///////////////////////////////////////////////////////////////////////////////////////////////////////
						// NLST -> print a list of files and directories in the current path (excluding hidden files)
						// NLST -a -> print a list of files and directories in the current path(including hidden files)
						// NLST -l -> list of file and directory of current path and output line by line (excluding hidden file) 
						// NLST -al -> list of file and directory of current path and output line by line (including hidden file)
						// NLST [file_name] -> option to output the information of name passed from client
						// NLST [directory_name] -> print the coreresponding list and information of the dirtory to be passed from client
						// (has option)
						// LIST -> behavior is same as NLST -al
						// PWD -> print working directory(getcwd)
						// CWD -> change directory(chdir)
						// CDUP -> change directory to ..(chdir)
						// MKD -> make directory(mkdir)
						// DELE -> remove file(remove)
						// RMD -> remove directory(rmdir)
						// RNFR&RNTO -> rename from to(rename)
						// QUIT -> terminate child processor and  pulling algorithm for structure
						// PORT -> make new port for data connection
						// TYPE -> change type mode for put, get command
						// RETR -> get command get file from server
						// STOR -> put command put file to server
						// ================================================================= //////////////////////////////////////////////////////////////////////////
						///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
						if(strcmp(arr, "NLST") == 0)// if FTP command is NLST
						{
							memset(temp, 0 , 100);
							memset(result_buff, 0, 10000);
							strcpy(temp, "150 Openning data connection for directory list.\n");
							write(client_fd, temp, strlen(temp));
							sleep(1);
							////////////////////////////////////////////////////////////
							memset(srv_print, 0, strlen(srv_print));
							strcpy(srv_print, temp);
							write(1, srv_print, strlen(srv_print));
							///////////////////////////////////////////////////////////
							memset(temp2, 0, strlen(temp2));
							sprintf(temp2, "%s", temp);
							print_log(store_path, &client_addr, temp2, 1);
							//sleep(1);
							DIR* dp;//
							struct dirent* dirp;
							//variable for directory open, a variable for reading each file and directory
							arr = strtok(NULL, " ");
							if(arr == NULL)// if option is not existence
							{
								struct stat stt;//declaration of stat structure variable for storing information of file
					
								dp = opendir(".");//current path directory open
					
								while((dirp = readdir(dp)) != 0)// repeat until there is no entry to read
								{				
									if(dirp->d_name[0] == '.')// becase not existence option a, exception case
									{
										continue;
									}
									else// if it is not a hidden file
									{
										memset(temp2, 0, strlen(temp2));
										getcwd(temp2, 100);
										strcat(temp2, "/");
										strcat(temp2, dirp->d_name);
										//process of importing the current path to create an absolute path
										lstat(temp2, &stt);
										/////////////////////////
										if(S_ISDIR(stt.st_mode))// if dirp->d_name is directory 
										{
											//memset(buf, 0 ,strlen(buf));
											strcpy(buf, dirp->d_name);
											strcat(buf, "/");//because directory
											strcpy(sort[row_count++], buf);//for sort
											memset(buf, 0 ,sizeof(buf));
										}
										else
										{
											//memset(buf, 0 ,strlen(buf));
											strcpy(buf, dirp->d_name);
											strcpy(sort[row_count++], buf);//for sort
											memset(buf, 0 ,sizeof(buf));
										}
									}
								}
								//printf("%d\n", row_count);
								////////////////////process of selection sorting///////////////////
								for(q = 0 ; q <row_count ; q++)
								{
									memset(temp_arr, 0, sizeof(temp_arr));
									temp_count = 0;
									//temp_count is index of smallest value
									for(a = q ; a <row_count ; a++)
									{
										if(a == q)
										{

											strcpy(temp_arr, sort[a]);
											temp_count = a;
										}
										else
										{
											if(strcmp(temp_arr, sort[a]) >  0)
											{
												temp_count = a;//value of smallest value
												memset(temp_arr, 0, sizeof(temp_arr));
												strcpy(temp_arr, sort[a]);
											}
										}
									}

								
									if(q == temp_count)
									{
											continue;
									}
									//////////////////////Swap value/////////////////////////
									else
									{
										memset(temp_arr, 0, sizeof(temp_arr));
										strcpy(temp_arr, sort[q]);			

										memset(sort[q], 0, sizeof(sort[q]));
										strcpy(sort[q], sort[temp_count]);

										memset(sort[temp_count], 0, sizeof(sort[temp_count]));
										strcpy(sort[temp_count], temp_arr);
									}
								}
								////////////////////////////////////////////////////////////////////////////
								count = 0;
								//write in order of 5 in a row
								for(a = 0 ; a<row_count ; a++)
								{
									if(count < 5)
									{
										//write(1,sort[a],100);
										//write(1,"\t",2);
										strcat(result_buff, sort[a]);
										strcat(result_buff, "\t");
										count++;
									}
									if(count == 5)
									{
										//write(1,"\n",2);
										strcat(result_buff, "\n");
										count = 0;
									}
								}
								//write(1,"\n",2);
								strcat(result_buff, "\n");
								write(sockfd, result_buff, strlen(result_buff));
								complete_transmission();
								////////////////////////
								memset(temp, 0 , strlen(temp));
								sprintf(temp, "226 %s Complete transmission. | %ld bytes\n", log_copy, strlen(result_buff) * sizeof(char));
								print_log(store_path, &client_addr, temp, 1);
								////////////////////////
								closedir(dp);//directory close
							}
							else if(arr[0] == '-')
							{
								if(strcmp(arr, "-a") == 0)// if option is a
								{
									struct stat stt;
									dp = opendir(".");
									while((dirp = readdir(dp)) != 0)
									{		
										//need to print all the hidden files.
										getcwd(temp2, 100);
										strcat(temp2, "/");
										strcat(temp2, dirp->d_name);
										lstat(temp2, &stt);
										/////////////////////////
										if(S_ISDIR(stt.st_mode))
										{
											strcpy(buf, dirp->d_name);
											strcat(buf, "/");
											strcpy(sort[row_count++], buf);//for sort
											count++;
											memset(buf, 0 ,sizeof(buf));
										}		
										else
										{
											strcpy(buf, dirp->d_name);
											strcpy(sort[row_count++], buf);//for sort
											count++;
											memset(buf, 0 ,sizeof(buf));
										}	
									}
									for(q = 0 ; q <row_count ; q++)
									{
										memset(temp_arr, 0, sizeof(temp_arr));		
										temp_count = 0;
										for(a = q ; a <row_count ; a++)
										{
											if(a == q)
											{		

												strcpy(temp_arr, sort[a]);
												temp_count = a;
											}
											else
											{
												if(strcmp(temp_arr, sort[a]) >  0)
												{
													temp_count = a;
													memset(temp_arr, 0, sizeof(temp_arr));
													strcpy(temp_arr, sort[a]);
												}
											}		

										}
										if(q == temp_count)
										{
											continue;
										}
										else
										{
											memset(temp_arr, 0, sizeof(temp_arr));
											strcpy(temp_arr, sort[q]);

											memset(sort[q], 0, sizeof(sort[q]));
											strcpy(sort[q], sort[temp_count]);

											memset(sort[temp_count], 0, sizeof(sort[temp_count]));
											strcpy(sort[temp_count], temp_arr);
										}
									}
									/////////////////////////////////////////
									count = 0;
									for(a = 0 ; a<row_count ; a++)
									{
										if(count < 5)
										{
											//write(1,sort[a],100);
											//write(1,"\t",2);
											strcat(result_buff, sort[a]);
											strcat(result_buff, "\t");
											count++;
										}
										if(count == 5)
										{
											//write(1,"\n",2);
											strcat(result_buff, "\n");
											count = 0;
										}
									}
									//write(1,"\n",2);
									strcat(result_buff, "\n");
									write(sockfd, result_buff, strlen(result_buff));

									complete_transmission();
									memset(temp, 0, strlen(temp));
									sprintf(temp, "226 %s Complete transmission. | %ld bytes\n", log_copy, strlen(result_buff) * sizeof(char));
									print_log(store_path, &client_addr, temp, 1);
									closedir(dp);
								}
								else if(strcmp(arr, "-l") == 0)// if option is l
								{
									struct stat stt;
									dp = opendir(".");
									while((dirp = readdir(dp)) != 0)
									{
										if(dirp->d_name[0] == '.')//because 'a' option is not included
										{
											continue;
										}
										else
										{
											getcwd(temp2, 100);
											strcat(temp2, "/");
											strcat(temp2, dirp->d_name);
											lstat(temp2, &stt);
											if(S_ISDIR(stt.st_mode))
											{
												strcpy(buf, dirp->d_name);
												//strcat(buf, "/");
												strcpy(sort[row_count++], buf);//for sort
												count++;
												memset(buf, 0 ,sizeof(buf));
											}
											else
											{
												strcpy(buf, dirp->d_name);
												//strcat(buf, "\t");
												strcpy(sort[row_count++], buf);//for sort
												count++;
												memset(buf, 0 ,sizeof(buf));	
											}
										}
									}
									for(q = 0 ; q <row_count ; q++)
									{
										memset(temp_arr, 0, sizeof(temp_arr));
										temp_count = 0;
										for(a = q ; a <row_count ; a++)
										{
											if(a == q)
											{		

												strcpy(temp_arr, sort[a]);
												temp_count = a;
											}
											else
											{
												if(strcmp(temp_arr, sort[a]) >  0)
												{
													temp_count = a;
													memset(temp_arr, 0, sizeof(temp_arr));
													strcpy(temp_arr, sort[a]);
												}
											}		

										}
										if(q == temp_count)
										{
											continue;
										}
										else
										{
											memset(temp_arr, 0, sizeof(temp_arr));
											strcpy(temp_arr, sort[q]);

											memset(sort[q], 0, sizeof(sort[q]));
											strcpy(sort[q], sort[temp_count]);

											memset(sort[temp_count], 0, sizeof(sort[temp_count]));
											strcpy(sort[temp_count], temp_arr);
										}
									}
									/////////////////////////////////////////
									//the process of outputting each information of file which is characteristic of l option
									count = 0;
									char permission[10] = {0};//array that stores the permissions of file as a string.
									for(a = 0 ; a<row_count ; a++)
									{
										getcwd(temp2, 100);
										strcat(temp2, "/");
										strcat(temp2, sort[a]);
										//the process of creating an absolute path
										lstat(temp2, &stt);

										if(S_ISDIR(stt.st_mode))//whether directory or file
											permission[0] = 'd';			
										else
											permission[0] = '-';
										

										if(S_IRUSR & stt.st_mode)//whether existence user read permission or not
											permission[1] = 'r';
										
										else
											permission[1] = '-';
										if(S_IWUSR & stt.st_mode)//whether existence user write permission or not)
											permission[2] = 'w';
										else
											permission[2] = '-';
										if(S_IXUSR & stt.st_mode)//whether existence user execute permission or not
											permission[3] = 'x';
										else
											permission[3] = '-';

										if(S_IRGRP & stt.st_mode)//whether existence group read permission or not
											permission[4] = 'r';
										
										else
											permission[4] = '-';
										if(S_IWGRP & stt.st_mode)//whether existence group write permission or not
											permission[5] = 'w';
										else
											permission[5] = '-';
										if(S_IXGRP & stt.st_mode)//whether existence group execute permission or not
											permission[6] = 'x';
										else
											permission[6] = '-';

										if(S_IROTH & stt.st_mode)//whether existence other read permission or not
											permission[7] = 'r';
										else
											permission[7] = '-';
										if(S_IWOTH & stt.st_mode)//whether existence other write permission or not
											permission[8] = 'w';
										else
											permission[8] = '-';
										if(S_IXOTH & stt.st_mode)//whether existence other execute permission or not
											permission[9] = 'x';
										else
											permission[9] = '-';
												//write(1,permission,sizeof(permission));
										
										strcat(result_buff, permission);
										strcat(result_buff, " ");
										///////////////////////////////////////////
										memset(buf, 0 , sizeof(buf));
										sprintf(buf, "%d", (int)stt.st_nlink);
										//////////////////////////////////////
									
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										/////////////////////////////////////
										struct passwd* pw;
										struct passwd* group;

										pw = getpwuid(stt.st_uid);
										group = getpwuid(stt.st_gid);
										memset(buf, 0 , sizeof(buf));
										sprintf(buf, "%s %s", pw->pw_name, group->pw_name);
										/////////////////////////////////////////////////////////////
									
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										////////////////////////////////////////////////////
										memset(buf, 0 , sizeof(buf));
										sprintf(buf, "%d", (int)stt.st_size);
										////////////////////////////////////
								
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										////////////////////////////////////
										
										memset(buf, 0 , sizeof(buf));
										struct tm *lt;
									
										lt=localtime(&stt.st_mtime);
									
										memset(buf, 0 , sizeof(buf));
										strftime(buf,100,"%m",lt);
										strcat(buf, "월");
										///////////////////////////
										
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										///////////////////////////
										memset(buf, 0 , sizeof(buf));
										strftime(buf,100,"%d",lt);
										strcat(buf, "일");
										///////////////////////////////
									
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										///////////////////////////////
										memset(buf, 0 , sizeof(buf));
										strftime(buf,100,"%H",lt);
										/////////////////////////////////
									
										strcat(result_buff, buf);
										strcat(result_buff, ":");
										////////////////////////////////
										memset(buf, 0 , sizeof(buf));
										strftime(buf,100,"%M",lt);
										/////////////////////////////
										
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										//////////////////////////
										memset(buf, 0 , sizeof(buf));
										if(permission[0] == '-')
										{
											strcpy(buf, sort[a]);
											////////////////////////////
											
											strcat(result_buff, buf);
											
											//////////////////////////
										}
										else
										{
											strcpy(buf, sort[a]);
											strcat(buf, "/");
											//////////////////////
											strcat(result_buff, buf);
											//////////////////////
										}
										strcat(result_buff, "\n");
							
										memset(permission, 0, strlen(permission));
									}
									write(sockfd, result_buff, strlen(result_buff));
									complete_transmission();
									memset(temp, 0, strlen(temp));
									sprintf(temp, "226 %s Complete transmission. | %ld bytes\n", log_copy, strlen(result_buff) * sizeof(char));
									print_log(store_path, &client_addr, temp, 1);
									closedir(dp);			
								}
								else if(strcmp(arr, "-al") == 0 || strcmp(arr, "-la") == 0)
								// if option is -al or -la
								// action is the same as the action of option 'a' and the action of option 'l'.
								{
									struct stat stt;
									dp = opendir(".");
									while((dirp = readdir(dp)) != 0)
									{
										getcwd(temp2, 100);
										strcat(temp2, "/");
										strcat(temp2, dirp->d_name);
										lstat(temp2, &stt);
										if(S_ISDIR(stt.st_mode))
										{
											strcpy(buf, dirp->d_name);
											//strcat(buf, "/");
											strcpy(sort[row_count++], buf);//for sort
											count++;
											memset(buf, 0 ,sizeof(buf));
										}
										else
										{
											strcpy(buf, dirp->d_name);
											//strcat(buf, "\t");
											strcpy(sort[row_count++], buf);//for sort
											count++;
											memset(buf, 0 ,sizeof(buf));	
										}
									}
									for(q = 0 ; q <row_count ; q++)
									{
										memset(temp_arr, 0, sizeof(temp_arr));
										temp_count = 0;
										for(a = q ; a <row_count ; a++)
										{						
											if(a == q)
											{		

												strcpy(temp_arr, sort[a]);
												temp_count = a;
											}
											else
											{
												if(strcmp(temp_arr, sort[a]) >  0)
												{
													temp_count = a;
													memset(temp_arr, 0, sizeof(temp_arr));
													strcpy(temp_arr, sort[a]);
												}
											}		

										}
										if(q == temp_count)
										{
											continue;
										}
										else
										{
											memset(temp_arr, 0, sizeof(temp_arr));
											strcpy(temp_arr, sort[q]);

											memset(sort[q], 0, sizeof(sort[q]));
											strcpy(sort[q], sort[temp_count]);

											memset(sort[temp_count], 0, sizeof(sort[temp_count]));
											strcpy(sort[temp_count], temp_arr);
										}
									}
									////////////////finist inser and sorting////////////////
									count = 0;
									char permission[10] = {0};
									for(a = 0 ; a<row_count ; a++)
									{
										getcwd(temp2, 100);
										strcat(temp2, "/");
										strcat(temp2, sort[a]);
										lstat(temp2, &stt);
										if(S_ISDIR(stt.st_mode))
											permission[0] = 'd';			
										else
											permission[0] = '-';
										

										if(S_IRUSR & stt.st_mode)
											permission[1] = 'r';
										
										else
											permission[1] = '-';
										if(S_IWUSR & stt.st_mode)
											permission[2] = 'w';
										else
											permission[2] = '-';
										if(S_IXUSR & stt.st_mode)
											permission[3] = 'x';
										else
											permission[3] = '-';

										if(S_IRGRP & stt.st_mode)
											permission[4] = 'r';
										
										else
											permission[4] = '-';
										if(S_IWGRP & stt.st_mode)
											permission[5] = 'w';
										else
											permission[5] = '-';
										if(S_IXGRP & stt.st_mode)
											permission[6] = 'x';
										else
											permission[6] = '-';

										if(S_IROTH & stt.st_mode)
											permission[7] = 'r';
										else
											permission[7] = '-';
										if(S_IWOTH & stt.st_mode)
											permission[8] = 'w';
										else
											permission[8] = '-';
										if(S_IXOTH & stt.st_mode)
											permission[9] = 'x';
										else
											permission[9] = '-';
								
										strcat(result_buff, permission);
										strcat(result_buff, " ");
										///////////////////////////////////////////
										memset(buf, 0 , sizeof(buf));
										sprintf(buf, "%d", (int)stt.st_nlink);
										//////////////////////////////////////
								
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										/////////////////////////////////////
										struct passwd* pw;
										struct passwd* group;

										pw = getpwuid(stt.st_uid);
										group = getpwuid(stt.st_gid);
										memset(buf, 0 , sizeof(buf));
										sprintf(buf, "%s %s", pw->pw_name, group->pw_name);
										/////////////////////////////////////////////////////////////
									
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										////////////////////////////////////////////////////
										memset(buf, 0 , sizeof(buf));
										sprintf(buf, "%d", (int)stt.st_size);
										////////////////////////////////////
									
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										////////////////////////////////////
										
										memset(buf, 0 , sizeof(buf));
										struct tm *lt;
									
										lt=localtime(&stt.st_mtime);
									
										memset(buf, 0 , sizeof(buf));
										strftime(buf,100,"%m",lt);
										strcat(buf, "월");
										///////////////////////////
										
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										///////////////////////////
										memset(buf, 0 , sizeof(buf));
										strftime(buf,100,"%d",lt);
										strcat(buf, "일");
										///////////////////////////////
									
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										///////////////////////////////
										memset(buf, 0 , sizeof(buf));
										strftime(buf,100,"%H",lt);
										/////////////////////////////////
								
										strcat(result_buff, buf);
										strcat(result_buff, ":");
										////////////////////////////////
										memset(buf, 0 , sizeof(buf));
										strftime(buf,100,"%M",lt);
										/////////////////////////////
								
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										//////////////////////////
										memset(buf, 0 , sizeof(buf));
										if(permission[0] == '-')
										{
											strcpy(buf, sort[a]);
											////////////////////////////
											strcat(result_buff, buf);
											
											//////////////////////////
										}
										else
										{
											strcpy(buf, sort[a]);
											strcat(buf, "/");
											//////////////////////
											strcat(result_buff, buf);
											//////////////////////
										}
										strcat(result_buff, "\n");

										memset(permission, 0, strlen(permission));
									}
									write(sockfd, result_buff, strlen(result_buff));
									complete_transmission();
									memset(temp, 0, strlen(temp));
									sprintf(temp, "226 %s Complete transmission. | %ld bytes\n", log_copy, strlen(result_buff) * sizeof(char));
									print_log(store_path, &client_addr, temp, 1);
									closedir(dp);
									
								}	
								else
								{
									/////////plus write(sockfd(new socket, ,))////////////
									write(sockfd, " \n", 2);
									failed_transmission();
									memset(temp, 0, strlen(temp));
									sprintf(temp, "550 %s Failed transmission.\n", log_copy);
									print_log(store_path, &client_addr, temp, 1);
								}
							}
							else if(arr[0] != '-')
							{
								//arr => path
								memset(temp, 0 , strlen(temp));
								strcpy(temp, arr);
								// making absolute path for using lstat
								struct stat stt;
								int value = 0;
								value = lstat(temp, &stt);
								if(value == -1)// not exist path
								{
									/*
									memset(buf, 0 , strlen(buf));
									strcpy(buf,"Directory path or File name Error!\n");
									strcpy(result_buff, buf);
									write(client_fd, result_buff, strlen(result_buff));memset(buf, 0 , strlen(buf));
									strcpy(buf,"Directory path or File name Error!\n");
									strcpy(result_buff, buf);
									write(client_fd, result_buff, strlen(result_buff));
									*/
									memset(temp, 0, strlen(temp));
									sprintf(temp, "550 %s Failed transmission.\n", log_copy);
									print_log(store_path, &client_addr, temp, 1);
									failed_transmission();
								}
								else// exist path
								{
									arr2 = strtok(NULL, " ");//arr2 = option
									char copy[100] = {0};
									strcpy(copy, arr);
									if(S_ISDIR(stt.st_mode))// passing directory
									{
										if(arr2 == NULL)
										{
											DIR* dp;
											struct dirent* dirp;
											struct stat stt;//declaration of stat structure variable for storing information of file
											
											dp = opendir(temp);//current path directory open
								
											while((dirp = readdir(dp)) != 0)// repeat until there is no entry to read
											{				
												if(dirp->d_name[0] == '.')// becase not existence option a, exception case
												{
													continue;
												}
												else// if it is not a hidden file
												{
													memset(temp2, 0, strlen(temp2));
													memset(buf, 0, strlen(buf));
													//getcwd(temp2, 100);
													strcpy(temp2, temp);
													strcat(temp2, "/");
													strcat(temp2, dirp->d_name);
													lstat(temp2, &stt);
													/////////////////////////
													if(S_ISDIR(stt.st_mode))// if dirp->d_name is directory 
													{
														//memset(buf, 0 ,strlen(buf));
														strcpy(buf, dirp->d_name);
														strcat(buf, "/");//because directory
														strcpy(sort[row_count++], buf);//for sort
														memset(buf, 0 ,sizeof(buf));
													}
													else
													{
														//memset(buf, 0 ,strlen(buf));
														strcpy(buf, dirp->d_name);
														strcpy(sort[row_count++], buf);//for sort
														memset(buf, 0 ,sizeof(buf));
													}
												}
											}
											//printf("%d\n", row_count);
											////////////////////process of selection sorting///////////////////
											for(q = 0 ; q <row_count ; q++)
											{
												memset(temp_arr, 0, sizeof(temp_arr));
												temp_count = 0;
												//temp_count is index of smallest value
												for(a = q ; a <row_count ; a++)
												{
													if(a == q)
													{

														strcpy(temp_arr, sort[a]);
														temp_count = a;
													}
													else
													{
														if(strcmp(temp_arr, sort[a]) >  0)
														{
															temp_count = a;//value of smallest value
															memset(temp_arr, 0, sizeof(temp_arr));
															strcpy(temp_arr, sort[a]);
														}
													}
												}

											
												if(q == temp_count)
												{
														continue;
												}
												//////////////////////Swap value/////////////////////////
												else
												{
													memset(temp_arr, 0, sizeof(temp_arr));
													strcpy(temp_arr, sort[q]);			

													memset(sort[q], 0, sizeof(sort[q]));
													strcpy(sort[q], sort[temp_count]);

													memset(sort[temp_count], 0, sizeof(sort[temp_count]));
													strcpy(sort[temp_count], temp_arr);
												}
											}
											////////////////////////////////////////////////////////////////////////////
											count = 0;
											//write in order of 5 in a row
											for(a = 0 ; a<row_count ; a++)
											{
												if(count < 5)
												{
													//write(1,sort[a],100);
													//write(1,"\t",2);
													strcat(result_buff, sort[a]);
													strcat(result_buff, "\t");
													count++;
												}
												if(count == 5)
												{
													//write(1,"\n",2);
													strcat(result_buff, "\n");
													count = 0;
												}
											}
											//write(1,"\n",2);
											strcat(result_buff, "\n");
											
											write(sockfd, result_buff, strlen(result_buff));
											complete_transmission();
											memset(temp, 0, strlen(temp));
											sprintf(temp, "226 %s Complete transmission. | %ld bytes\n", log_copy, strlen(result_buff) * sizeof(char));
											print_log(store_path, &client_addr, temp, 1);
											closedir(dp);//directory close

										}
										else if(strcmp(arr2, "-a") == 0)
										{
											struct stat stt;
											dp = opendir(temp);
											while((dirp = readdir(dp)) != 0)
											{		
												//need to print all the hidden files.
												memset(temp2, 0, strlen(temp2));
												memset(buf, 0, strlen(buf));
												//getcwd(temp2, 100);
												strcpy(temp2, temp);
												strcat(temp2, "/");
												strcat(temp2, dirp->d_name);
												lstat(temp2, &stt);
												/////////////////////////
												if(S_ISDIR(stt.st_mode))
												{
													strcpy(buf, dirp->d_name);
													strcat(buf, "/");
													strcpy(sort[row_count++], buf);//for sort
													count++;
													memset(buf, 0 ,sizeof(buf));
												}		
												else
												{
													strcpy(buf, dirp->d_name);
													strcpy(sort[row_count++], buf);//for sort
													count++;
													memset(buf, 0 ,sizeof(buf));
												}	
											}
											for(q = 0 ; q <row_count ; q++)
											{
												memset(temp_arr, 0, sizeof(temp_arr));		
												temp_count = 0;
												for(a = q ; a <row_count ; a++)
												{
													if(a == q)
													{		

														strcpy(temp_arr, sort[a]);
														temp_count = a;
													}
													else
													{
														if(strcmp(temp_arr, sort[a]) >  0)
														{
															temp_count = a;
															memset(temp_arr, 0, sizeof(temp_arr));
															strcpy(temp_arr, sort[a]);
														}
													}		

												}
												if(q == temp_count)
												{
													continue;
												}
												else
												{
													memset(temp_arr, 0, sizeof(temp_arr));
													strcpy(temp_arr, sort[q]);

													memset(sort[q], 0, sizeof(sort[q]));
													strcpy(sort[q], sort[temp_count]);

													memset(sort[temp_count], 0, sizeof(sort[temp_count]));
													strcpy(sort[temp_count], temp_arr);
												}
											}
											/////////////////////////////////////////
											count = 0;
											for(a = 0 ; a<row_count ; a++)
											{
												if(count < 5)
												{
													//write(1,sort[a],100);
													//write(1,"\t",2);
													strcat(result_buff, sort[a]);
													strcat(result_buff, "\t");
													count++;
												}
												if(count == 5)
												{
													//write(1,"\n",2);
													strcat(result_buff, "\n");
													count = 0;
												}
											}
											//write(1,"\n",2);
											strcat(result_buff, "\n");
											write(sockfd, result_buff , strlen(result_buff));
											complete_transmission();
											memset(temp, 0, strlen(temp));
											sprintf(temp, "226 %s Comple transmission. | %ld bytes\n", log_copy, strlen(result_buff) * sizeof(char));
											print_log(store_path, &client_addr, temp, 1);
											closedir(dp);
										}
										else if(strcmp(arr2, "-l") == 0)
										{
											struct stat stt;
											dp = opendir(temp);
											while((dirp = readdir(dp)) != 0)
											{
												if(dirp->d_name[0] == '.')//because 'a' option is not included
												{
													continue;
												}
												else
												{
													getcwd(temp2, 100);
													strcat(temp2, "/");
													strcat(temp2, dirp->d_name);
													lstat(temp2, &stt);
													if(S_ISDIR(stt.st_mode))
													{
														strcpy(buf, dirp->d_name);
														//strcat(buf, "/");
														strcpy(sort[row_count++], buf);//for sort
														count++;
														memset(buf, 0 ,sizeof(buf));
													}
													else
													{
														strcpy(buf, dirp->d_name);
														//strcat(buf, "\t");
														strcpy(sort[row_count++], buf);//for sort
														count++;
														memset(buf, 0 ,sizeof(buf));	
													}
												}
											}
											for(q = 0 ; q <row_count ; q++)
											{
												memset(temp_arr, 0, sizeof(temp_arr));
												temp_count = 0;
												for(a = q ; a <row_count ; a++)
												{
													if(a == q)
													{		

														strcpy(temp_arr, sort[a]);
														temp_count = a;
													}
													else
													{
														if(strcmp(temp_arr, sort[a]) >  0)
														{
															temp_count = a;
															memset(temp_arr, 0, sizeof(temp_arr));
															strcpy(temp_arr, sort[a]);
														}
													}		

												}
												if(q == temp_count)
												{
													continue;
												}
												else
												{
													memset(temp_arr, 0, sizeof(temp_arr));
													strcpy(temp_arr, sort[q]);

													memset(sort[q], 0, sizeof(sort[q]));
													strcpy(sort[q], sort[temp_count]);

													memset(sort[temp_count], 0, sizeof(sort[temp_count]));
													strcpy(sort[temp_count], temp_arr);
												}
											}
											/////////////////////////////////////////
											//the process of outputting each information of file which is characteristic of l option
											count = 0;
											char permission[10] = {0};//array that stores the permissions of file as a string.
											for(a = 0 ; a<row_count ; a++)
											{
												memset(temp2, 0 , strlen(temp2));
												//getcwd(temp2, 100);
												strcpy(temp2, copy);
												strcat(temp2, "/");
												strcat(temp2, sort[a]);
												//the process of creating an absolute path
												lstat(temp2, &stt);

												if(S_ISDIR(stt.st_mode))//whether directory or file
													permission[0] = 'd';			
												else
													permission[0] = '-';
												

												if(S_IRUSR & stt.st_mode)//whether existence user read permission or not
													permission[1] = 'r';
												
												else
													permission[1] = '-';
												if(S_IWUSR & stt.st_mode)//whether existence user write permission or not)
													permission[2] = 'w';
												else
													permission[2] = '-';
												if(S_IXUSR & stt.st_mode)//whether existence user execute permission or not
													permission[3] = 'x';
												else
													permission[3] = '-';

												if(S_IRGRP & stt.st_mode)//whether existence group read permission or not
													permission[4] = 'r';
												
												else
													permission[4] = '-';
												if(S_IWGRP & stt.st_mode)//whether existence group write permission or not
													permission[5] = 'w';
												else
													permission[5] = '-';
												if(S_IXGRP & stt.st_mode)//whether existence group execute permission or not
													permission[6] = 'x';
												else
													permission[6] = '-';

												if(S_IROTH & stt.st_mode)//whether existence other read permission or not
													permission[7] = 'r';
												else
													permission[7] = '-';
												if(S_IWOTH & stt.st_mode)//whether existence other write permission or not
													permission[8] = 'w';
												else
													permission[8] = '-';
												if(S_IXOTH & stt.st_mode)//whether existence other execute permission or not
													permission[9] = 'x';
												else
													permission[9] = '-';
									
												strcat(result_buff, permission);
												strcat(result_buff, " ");
												///////////////////////////////////////////
												memset(buf, 0 , sizeof(buf));
												sprintf(buf, "%d", (int)stt.st_nlink);
												//////////////////////////////////////
											
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												/////////////////////////////////////
												struct passwd* pw;
												struct passwd* group;

												pw = getpwuid(stt.st_uid);
												group = getpwuid(stt.st_gid);
												memset(buf, 0 , sizeof(buf));
												sprintf(buf, "%s %s", pw->pw_name, group->pw_name);
												/////////////////////////////////////////////////////////////
												
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												////////////////////////////////////////////////////
												memset(buf, 0 , sizeof(buf));
												sprintf(buf, "%d", (int)stt.st_size);
												////////////////////////////////////
										
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												////////////////////////////////////
												
												memset(buf, 0 , sizeof(buf));
												struct tm *lt;
											
												lt=localtime(&stt.st_mtime);
											
												memset(buf, 0 , sizeof(buf));
												strftime(buf,100,"%m",lt);
												strcat(buf, "월");
												///////////////////////////
											
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												///////////////////////////
												memset(buf, 0 , sizeof(buf));
												strftime(buf,100,"%d",lt);
												strcat(buf, "일");
												///////////////////////////////
											
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												///////////////////////////////
												memset(buf, 0 , sizeof(buf));
												strftime(buf,100,"%H",lt);
												/////////////////////////////////
										
												strcat(result_buff, buf);
												strcat(result_buff, ":");
												////////////////////////////////
												memset(buf, 0 , sizeof(buf));
												strftime(buf,100,"%M",lt);
												/////////////////////////////
									
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												//////////////////////////
												memset(buf, 0 , sizeof(buf));
												if(permission[0] == '-')
												{
													strcpy(buf, sort[a]);
													////////////////////////////
													strcat(result_buff, buf);
													
													//////////////////////////
												}
												else
												{
													strcpy(buf, sort[a]);
													strcat(buf, "/");
													strcat(result_buff, buf);
													//////////////////////
												}
												strcat(result_buff, "\n");
												
												memset(permission, 0, strlen(permission));
											}
											write(sockfd, result_buff, strlen(result_buff));
											complete_transmission();
											memset(temp, 0, strlen(temp));
											sprintf(temp, "226 %s Complete transmission. | %ld bytes\n", log_copy, strlen(result_buff) * sizeof(char));
											print_log(store_path, &client_addr, temp, 1);
											closedir(dp);	
										}
										else if(strcmp(arr2, "-al") == 0)
										{
											struct stat stt;
											dp = opendir(temp);
											while((dirp = readdir(dp)) != 0)
											{
												strcpy(buf, dirp->d_name);
												
												strcpy(sort[row_count++], buf);//for sort
												count++;
												memset(buf, 0 ,sizeof(buf));
											}
											for(q = 0 ; q <row_count ; q++)
											{
												memset(temp_arr, 0, sizeof(temp_arr));
												temp_count = 0;
												for(a = q ; a <row_count ; a++)
												{
													if(a == q)
													{		

														strcpy(temp_arr, sort[a]);
														temp_count = a;
													}
													else
													{
														if(strcmp(temp_arr, sort[a]) >  0)
														{
															temp_count = a;
															memset(temp_arr, 0, sizeof(temp_arr));
															strcpy(temp_arr, sort[a]);
														}
													}		

												}
												if(q == temp_count)
												{
													continue;
												}
												else
												{
													memset(temp_arr, 0, sizeof(temp_arr));
													strcpy(temp_arr, sort[q]);

													memset(sort[q], 0, sizeof(sort[q]));
													strcpy(sort[q], sort[temp_count]);

													memset(sort[temp_count], 0, sizeof(sort[temp_count]));
													strcpy(sort[temp_count], temp_arr);
												}
											}
											////////////////finist inser and sorting////////////////
											count = 0;
											char permission[10] = {0};
											for(a = 0 ; a<row_count ; a++)
											{
												memset(temp2, 0 , strlen(temp2));
												strcpy(temp2, copy);
												//getcwd(temp2, 100);
												strcat(temp2, "/");
												strcat(temp2, sort[a]);
												lstat(temp2, &stt);
												if(S_ISDIR(stt.st_mode))
													permission[0] = 'd';			
												else
													permission[0] = '-';
												

												if(S_IRUSR & stt.st_mode)
													permission[1] = 'r';
												
												else
													permission[1] = '-';
												if(S_IWUSR & stt.st_mode)
													permission[2] = 'w';
												else
													permission[2] = '-';
												if(S_IXUSR & stt.st_mode)
													permission[3] = 'x';
												else
													permission[3] = '-';

												if(S_IRGRP & stt.st_mode)
													permission[4] = 'r';
												
												else
													permission[4] = '-';
												if(S_IWGRP & stt.st_mode)
													permission[5] = 'w';
												else
													permission[5] = '-';
												if(S_IXGRP & stt.st_mode)
													permission[6] = 'x';
												else
													permission[6] = '-';

												if(S_IROTH & stt.st_mode)
													permission[7] = 'r';
												else
													permission[7] = '-';
												if(S_IWOTH & stt.st_mode)
													permission[8] = 'w';
												else
													permission[8] = '-';
												if(S_IXOTH & stt.st_mode)
													permission[9] = 'x';
												else
													permission[9] = '-';
											
												strcat(result_buff, permission);
												strcat(result_buff, " ");
												///////////////////////////////////////////
												memset(buf, 0 , sizeof(buf));
												sprintf(buf, "%d", (int)stt.st_nlink);
												//////////////////////////////////////
										
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												/////////////////////////////////////
												struct passwd* pw;
												struct passwd* group;

												pw = getpwuid(stt.st_uid);
												group = getpwuid(stt.st_gid);
												memset(buf, 0 , sizeof(buf));
												sprintf(buf, "%s %s", pw->pw_name, group->pw_name);
												/////////////////////////////////////////////////////////////
										
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												////////////////////////////////////////////////////
												memset(buf, 0 , sizeof(buf));
												sprintf(buf, "%d", (int)stt.st_size);
												////////////////////////////////////
									
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												////////////////////////////////////
												
												memset(buf, 0 , sizeof(buf));
												struct tm *lt;
											
												lt=localtime(&stt.st_mtime);
											
												memset(buf, 0 , sizeof(buf));
												strftime(buf,100,"%m",lt);
												strcat(buf, "월");
												///////////////////////////
										
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												///////////////////////////
												memset(buf, 0 , sizeof(buf));
												strftime(buf,100,"%d",lt);
												strcat(buf, "일");
												///////////////////////////////
											
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												///////////////////////////////
												memset(buf, 0 , sizeof(buf));
												strftime(buf,100,"%H",lt);
												/////////////////////////////////
											
												strcat(result_buff, buf);
												strcat(result_buff, ":");
												////////////////////////////////
												memset(buf, 0 , sizeof(buf));
												strftime(buf,100,"%M",lt);
												/////////////////////////////
								
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												//////////////////////////
												memset(buf, 0 , sizeof(buf));
												if(permission[0] == '-')
												{
													strcpy(buf, sort[a]);
													////////////////////////////
						
													strcat(result_buff, buf);
													
													//////////////////////////
												}
												else
												{
													strcpy(buf, sort[a]);
													strcat(buf, "/");
													//////////////////////
										
													strcat(result_buff, buf);
													//////////////////////
												}
												strcat(result_buff, "\n");
										
												memset(permission, 0, strlen(permission));
											}
											write(sockfd, result_buff, strlen(result_buff));
											complete_transmission();
											memset(temp, 0, strlen(temp));
											sprintf(temp, "226 %s Complete transmission. | %ld bytes\n", log_copy, strlen(result_buff) * sizeof(char));
											print_log(store_path, &client_addr, temp, 1);
											closedir(dp);	
										}
										else
										{
											failed_transmission();
											memset(temp, 0, strlen(temp));
											sprintf(temp, "550 %s Failed transmission.\n", log_copy);
											print_log(store_path, &client_addr, temp, 1);
										}
									}
									else// passing file name
									{
										if(arr2 == NULL)
										{
											memset(temp, 0 , strlen(temp));
											sprintf(temp,"%s", arr);
											strcat(result_buff, temp);
											strcat(result_buff, "\n");
											write(sockfd, result_buff, strlen(result_buff));
											complete_transmission();
											memset(temp, 0, strlen(temp));
											sprintf(temp, "226 %s Complete transmission. | %ld bytes\n", log_copy, strlen(result_buff) * sizeof(char));
											print_log(store_path, &client_addr, temp, 1);
										}
										else if(strcmp(arr2, "-l") == 0)
										{
											char pwd[100] = {0};
											memset(temp2, 0, sizeof(temp2));
											char permission[10] = {0};
											//strcpy(temp2, copy);
											getcwd(pwd,100);
											strcpy(temp2, pwd);
											strcat(temp2,"/");
											strcat(temp2, copy);
											//creating absolute path
											if(lstat(temp2, &stt) == 0)
											{
												
												if(S_ISDIR(stt.st_mode))
													permission[0] = 'd';			
												else
													permission[0] = '-';
											

												if(S_IRUSR & stt.st_mode)
													permission[1] = 'r';
												
												else
													permission[1] = '-';
												if(S_IWUSR & stt.st_mode)
													permission[2] = 'w';
												else
													permission[2] = '-';
												if(S_IXUSR & stt.st_mode)
													permission[3] = 'x';
												else
													permission[3] = '-';

												if(S_IRGRP & stt.st_mode)
													permission[4] = 'r';
												
												else
													permission[4] = '-';
												if(S_IWGRP & stt.st_mode)
													permission[5] = 'w';
												else
													permission[5] = '-';
												if(S_IXGRP & stt.st_mode)
													permission[6] = 'x';
												else
													permission[6] = '-';

												if(S_IROTH & stt.st_mode)
													permission[7] = 'r';
												else
													permission[7] = '-';
												if(S_IWOTH & stt.st_mode)
													permission[8] = 'w';
												else
													permission[8] = '-';
												if(S_IXOTH & stt.st_mode)
													permission[9] = 'x';
												else
													permission[9] = '-';
												
												strcat(result_buff, permission);
												strcat(result_buff, " ");
												///////////////////////////////////////////
												memset(buf, 0 , sizeof(buf));
												sprintf(buf, "%d", (int)stt.st_nlink);
												//////////////////////////////////////
											
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												/////////////////////////////////////
												struct passwd* pw;
												struct passwd* group;

												pw = getpwuid(stt.st_uid);
												group = getpwuid(stt.st_gid);
												memset(buf, 0 , sizeof(buf));
												sprintf(buf, "%s %s", pw->pw_name, group->pw_name);
												/////////////////////////////////////////////////////////////
												
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												////////////////////////////////////////////////////
												memset(buf, 0 , sizeof(buf));
												sprintf(buf, "%d", (int)stt.st_size);
												////////////////////////////////////
											
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												////////////////////////////////////
												
												memset(buf, 0 , sizeof(buf));
												struct tm *lt;
											
												lt=localtime(&stt.st_mtime);
											
												memset(buf, 0 , sizeof(buf));
												strftime(buf,100,"%m",lt);
												strcat(buf, "월");
												///////////////////////////
											
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												///////////////////////////
												memset(buf, 0 , sizeof(buf));
												strftime(buf,100,"%d",lt);
												strcat(buf, "일");
												///////////////////////////////
											
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												///////////////////////////////
												memset(buf, 0 , sizeof(buf));
												strftime(buf,100,"%H",lt);
												/////////////////////////////////
										
												strcat(result_buff, buf);
												strcat(result_buff, ":");
												////////////////////////////////
												memset(buf, 0 , sizeof(buf));
												strftime(buf,100,"%M",lt);
												/////////////////////////////
									
												strcat(result_buff, buf);
												strcat(result_buff, " ");
												//////////////////////////
												memset(buf, 0 , sizeof(buf));
												
												strcat(result_buff, copy);
												strcat(result_buff, "\n");
												write(client_fd, result_buff, strlen(result_buff));
												complete_transmission();
												memset(temp, 0, strlen(temp));
												sprintf(temp, "226 %s Complete transmission. | %ld bytes\n", log_copy, strlen(result_buff) * sizeof(char));
												print_log(store_path, &client_addr, temp, 1);
											}
											else// stat error exceoption case
											{
												failed_transmission();
												memset(temp, 0, strlen(temp));
												sprintf(temp, "550 %s Failed transmission.\n", log_copy);
												print_log(store_path, &client_addr, temp, 1);
											}
										}
										else
										{
											memset(temp, 0, strlen(temp));
											sprintf(temp, "550 %s Failed transmission.\n", log_copy);
											print_log(store_path, &client_addr, temp, 1);
											failed_transmission();
										}
									}
								}
							}
							close(sockfd);
				
						}
						else if(strcmp(arr, "LIST") == 0)
						{
							memset(temp, 0 , strlen(temp));
							strcpy(temp, "150 Openning data connection for directory list.\n");
							write(client_fd, temp, strlen(temp));
							sleep(1);
							////////////////////////////////////////////////////
							memset(srv_print, 0, strlen(srv_print));
							strcpy(srv_print, temp);
							write(1, srv_print, strlen(srv_print));
							///////////////////////////////////////////////////
							memset(temp2, 0, strlen(temp2));
							sprintf(temp2, "%s", temp);
							print_log(store_path, &client_addr, temp2, 1);

							// dupliate algorithm with NlST -al
							arr  = strtok(NULL, " ");
							if(arr == NULL)// not exist passing path from client 
							{
								DIR* dp;//
								struct dirent* dirp;
								struct stat stt;
								dp = opendir(".");// open directory curren path
								while((dirp = readdir(dp)) != 0)
								{
									getcwd(temp2, 100);
									strcat(temp2, "/");
									strcat(temp2, dirp->d_name);
									lstat(temp2, &stt);
									if(S_ISDIR(stt.st_mode))
									{
										strcpy(buf, dirp->d_name);
										//strcat(buf, "/");
										strcpy(sort[row_count++], buf);//for sort
										count++;
										memset(buf, 0 ,sizeof(buf));
									}
									else
									{
										strcpy(buf, dirp->d_name);
										//strcat(buf, "\t");
										strcpy(sort[row_count++], buf);//for sort
										count++;
										memset(buf, 0 ,sizeof(buf));	
									}
								}
								for(q = 0 ; q <row_count ; q++)
								{
									memset(temp_arr, 0, sizeof(temp_arr));
									temp_count = 0;
									for(a = q ; a <row_count ; a++)
									{
										if(a == q)
										{		

											strcpy(temp_arr, sort[a]);
											temp_count = a;
										}
										else
										{
											if(strcmp(temp_arr, sort[a]) >  0)
											{
												temp_count = a;
												memset(temp_arr, 0, sizeof(temp_arr));
												strcpy(temp_arr, sort[a]);
											}
										}		

									}
									if(q == temp_count)
									{
										continue;
									}
									else
									{
										memset(temp_arr, 0, sizeof(temp_arr));
										strcpy(temp_arr, sort[q]);

										memset(sort[q], 0, sizeof(sort[q]));
										strcpy(sort[q], sort[temp_count]);

										memset(sort[temp_count], 0, sizeof(sort[temp_count]));
										strcpy(sort[temp_count], temp_arr);
									}
								}
								////////////////finist inser and sorting////////////////
								count = 0;
								char permission[10] = {0};
								for(a = 0 ; a<row_count ; a++)
								{
									getcwd(temp2, 100);
									strcat(temp2, "/");
									strcat(temp2, sort[a]);
									lstat(temp2, &stt);
									if(S_ISDIR(stt.st_mode))
										permission[0] = 'd';			
									else
										permission[0] = '-';
									

									if(S_IRUSR & stt.st_mode)
										permission[1] = 'r';
									
									else
										permission[1] = '-';
									if(S_IWUSR & stt.st_mode)
										permission[2] = 'w';
									else
										permission[2] = '-';
									if(S_IXUSR & stt.st_mode)
										permission[3] = 'x';
									else
										permission[3] = '-';

									if(S_IRGRP & stt.st_mode)
										permission[4] = 'r';
									
									else
										permission[4] = '-';
									if(S_IWGRP & stt.st_mode)
										permission[5] = 'w';
									else
										permission[5] = '-';
									if(S_IXGRP & stt.st_mode)
										permission[6] = 'x';
									else
										permission[6] = '-';

									if(S_IROTH & stt.st_mode)
										permission[7] = 'r';
									else
										permission[7] = '-';
									if(S_IWOTH & stt.st_mode)
										permission[8] = 'w';
									else
										permission[8] = '-';
									if(S_IXOTH & stt.st_mode)
										permission[9] = 'x';
									else
										permission[9] = '-';
									////////////////////////////////////////////////
									//write(1,permission,sizeof(permission));
									//write(1," ",2);
									strcat(result_buff, permission);
									strcat(result_buff, " ");
									///////////////////////////////////////////
									memset(buf, 0 , sizeof(buf));
									sprintf(buf, "%d", (int)stt.st_nlink);
									//////////////////////////////////////
									//write(1, buf, 100);
									//write(1," ",2);
									strcat(result_buff, buf);
									strcat(result_buff, " ");
									/////////////////////////////////////
									struct passwd* pw;
									struct passwd* group;

									pw = getpwuid(stt.st_uid);
									group = getpwuid(stt.st_gid);
									memset(buf, 0 , sizeof(buf));
									sprintf(buf, "%s %s", pw->pw_name, group->pw_name);
									/////////////////////////////////////////////////////////////
									//write(1, buf, 100);
									//write(1," ",2);
									strcat(result_buff, buf);
									strcat(result_buff, " ");
									////////////////////////////////////////////////////
									memset(buf, 0 , sizeof(buf));
									sprintf(buf, "%d", (int)stt.st_size);
									////////////////////////////////////
									//write(1, buf, 100);
									//write(1," ",2);
									strcat(result_buff, buf);
									strcat(result_buff, " ");
									////////////////////////////////////
									
									memset(buf, 0 , sizeof(buf));
									struct tm *lt;
								
									lt=localtime(&stt.st_mtime);
								
									memset(buf, 0 , sizeof(buf));
									strftime(buf,100,"%m",lt);
									strcat(buf, "월");
									///////////////////////////
									//write(1,buf,100);
									//write(1," ",2);
									strcat(result_buff, buf);
									strcat(result_buff, " ");
									///////////////////////////
									memset(buf, 0 , sizeof(buf));
									strftime(buf,100,"%d",lt);
									strcat(buf, "일");
									///////////////////////////////
									//write(1,buf,100);
									//write(1," ",2);
									strcat(result_buff, buf);
									strcat(result_buff, " ");
									///////////////////////////////
									memset(buf, 0 , sizeof(buf));
									strftime(buf,100,"%H",lt);
									/////////////////////////////////
									//write(1,buf,100);
									//write(1,":",2);
									strcat(result_buff, buf);
									strcat(result_buff, " ");
									////////////////////////////////
									memset(buf, 0 , sizeof(buf));
									strftime(buf,100,"%M",lt);
									/////////////////////////////
									//write(1,buf,100);
									//write(1," ",2);
									strcat(result_buff, buf);
									strcat(result_buff, " ");
									//////////////////////////
									memset(buf, 0 , sizeof(buf));
									if(permission[0] == '-')
									{
										strcpy(buf, sort[a]);
										////////////////////////////
										//write(1,buf,100);
										strcat(result_buff, buf);
										
										//////////////////////////
									}
									else
									{
										strcpy(buf, sort[a]);
										strcat(buf, "/");
										//////////////////////
										//write(1,buf,100);
										strcat(result_buff, buf);
										//////////////////////
									}
									strcat(result_buff, "\n");
									//write(1,"\n",2);
									memset(permission, 0, strlen(permission));
								}
								write(sockfd, result_buff, strlen(result_buff));
								memset(temp, 0, strlen(temp));
								sprintf(temp, "226 %s Complete transmission. | %ld bytes\n", log_copy, strlen(result_buff) * sizeof(char));
								print_log(store_path, &client_addr, temp, 1);
								complete_transmission();
								//write(1, result_buff, strlen(result_buff));
								closedir(dp);		
							}
							else if(arr != NULL)// exist passing path from client
							{
								DIR* dp;//
								char temp3[100] = {0};
								char copy[100] = {0};
								struct dirent* dirp;
								struct stat stt;
								memset(temp, 0, strlen(temp));
								strcpy(temp, arr);
								strcpy(copy, arr);
								dp = opendir(temp);
								int value = 0;
								value = lstat(temp, &stt);
								if(value == -1)
								{
									memset(buf, 0 , strlen(buf));
									strcpy(buf,"Directory path Error!\n");
									write(sockfd, buf, strlen(buf));
									failed_transmission();
									memset(temp, 0, strlen(temp));
									sprintf(temp, "550 Failed transmission.\n");
									print_log(store_path, &client_addr, temp, 1);

								 // open directory for using make absolute path
								}
								//temp is passing path from client
								else
								{
									while((dirp = readdir(dp)) != 0)
									{
										strcpy(buf, dirp->d_name);
										//strcat(buf, "/");
										strcpy(sort[row_count++], buf);//for sort
										count++;
										memset(buf, 0 ,sizeof(buf));
									}
									for(q = 0 ; q <row_count ; q++)
									{
										memset(temp_arr, 0, sizeof(temp_arr));
										temp_count = 0;
										for(a = q ; a <row_count ; a++)
										{
											if(a == q)
											{		

												strcpy(temp_arr, sort[a]);
												temp_count = a;
											}
											else
											{
												if(strcmp(temp_arr, sort[a]) >  0)
												{
													temp_count = a;
													memset(temp_arr, 0, sizeof(temp_arr));
													strcpy(temp_arr, sort[a]);
												}
											}		

										}
										if(q == temp_count)
										{
											continue;
										}
										else
										{
											memset(temp_arr, 0, sizeof(temp_arr));
											strcpy(temp_arr, sort[q]);

											memset(sort[q], 0, sizeof(sort[q]));
											strcpy(sort[q], sort[temp_count]);

											memset(sort[temp_count], 0, sizeof(sort[temp_count]));
											strcpy(sort[temp_count], temp_arr);
										}
									}
									////////////////finist inser and sorting////////////////
									count = 0;
									char permission[10] = {0};
									for(a = 0 ; a<row_count ; a++)
									{
										memset(temp2, 0 , strlen(temp2));
										strcpy(temp2, copy);
										strcat(temp2, "/");
										strcat(temp2, sort[a]);
										lstat(temp2, &stt);
										if(S_ISDIR(stt.st_mode))
											permission[0] = 'd';			
										else
											permission[0] = '-';
										

										if(S_IRUSR & stt.st_mode)
											permission[1] = 'r';
										
										else
											permission[1] = '-';
										if(S_IWUSR & stt.st_mode)
											permission[2] = 'w';
										else
											permission[2] = '-';
										if(S_IXUSR & stt.st_mode)
											permission[3] = 'x';
										else
											permission[3] = '-';

										if(S_IRGRP & stt.st_mode)
											permission[4] = 'r';
										
										else
											permission[4] = '-';
										if(S_IWGRP & stt.st_mode)
											permission[5] = 'w';
										else
											permission[5] = '-';
										if(S_IXGRP & stt.st_mode)
											permission[6] = 'x';
										else
											permission[6] = '-';

										if(S_IROTH & stt.st_mode)
											permission[7] = 'r';
										else
											permission[7] = '-';
										if(S_IWOTH & stt.st_mode)
											permission[8] = 'w';
										else
											permission[8] = '-';
										if(S_IXOTH & stt.st_mode)
											permission[9] = 'x';
										else
											permission[9] = '-';
										//write(1,permission,sizeof(permission));
										//write(1," ",2);
										strcat(result_buff, permission);
										strcat(result_buff, " ");
										///////////////////////////////////////////
										memset(buf, 0 , sizeof(buf));
										sprintf(buf, "%d", (int)stt.st_nlink);
										//////////////////////////////////////
										//write(1, buf, 100);
										//write(1," ",2);
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										/////////////////////////////////////
										struct passwd* pw;
										struct passwd* group;

										pw = getpwuid(stt.st_uid);
										group = getpwuid(stt.st_gid);
										memset(buf, 0 , sizeof(buf));
										sprintf(buf, "%s %s", pw->pw_name, group->pw_name);
										/////////////////////////////////////////////////////////////
										//write(1, buf, 100);
										//write(1," ",2);
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										////////////////////////////////////////////////////
										memset(buf, 0 , sizeof(buf));
										sprintf(buf, "%d", (int)stt.st_size);
										////////////////////////////////////
										//write(1, buf, 100);
										//write(1," ",2);
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										////////////////////////////////////
										
										memset(buf, 0 , sizeof(buf));
										struct tm *lt;
									
										lt=localtime(&stt.st_mtime);
									
										memset(buf, 0 , sizeof(buf));
										strftime(buf,100,"%m",lt);
										strcat(buf, "월");
										///////////////////////////
										//write(1,buf,100);
										//write(1," ",2);
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										///////////////////////////
										memset(buf, 0 , sizeof(buf));
										strftime(buf,100,"%d",lt);
										strcat(buf, "일");
										///////////////////////////////
										//write(1,buf,100);
										//write(1," ",2);
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										///////////////////////////////
										memset(buf, 0 , sizeof(buf));
										strftime(buf,100,"%H",lt);
										/////////////////////////////////
										//write(1,buf,100);
										//write(1,":",2);
										strcat(result_buff, buf);
										strcat(result_buff, ":");
										////////////////////////////////
										memset(buf, 0 , sizeof(buf));
										strftime(buf,100,"%M",lt);
										/////////////////////////////
										//write(1,buf,100);
										//write(1," ",2);
										strcat(result_buff, buf);
										strcat(result_buff, " ");
										//////////////////////////
										memset(buf, 0 , sizeof(buf));
										if(permission[0] == '-')
										{
											strcpy(buf, sort[a]);
											////////////////////////////
											//write(1,buf,100);
											strcat(result_buff, buf);
											
											//////////////////////////
										}
										else
										{
											strcpy(buf, sort[a]);
											strcat(buf, "/");
											//////////////////////
											//write(1,buf,100);
											strcat(result_buff, buf);
											//////////////////////
										}
										strcat(result_buff, "\n");
										//write(1,"\n",2);

										memset(permission, 0, strlen(permission));
									}
									write(sockfd, result_buff, strlen(result_buff));
									memset(temp, 0, strlen(temp));
									sprintf(temp, "226 %s Complete transmission. | %ld bytes\n", log_copy, strlen(result_buff) * sizeof(char));
									print_log(store_path, &client_addr, temp, 1);
									complete_transmission();
								}

								//write(1, result_buff, strlen(result_buff));
								closedir(dp);	

							}
							close(sockfd);		
						}
						else if(strcmp(arr, "PWD") == 0)//
						{
							memset(result_buff, 0 , strlen(result_buff));
							memset(buf, 0 , strlen(buf));
							getcwd(buf, 100);// get working directory
							//strcat(buf, "\n");
							//strcpy(result_buff, buf);
							sprintf(result_buff, "257 \"%s\" is current directory.\n", buf);
							write(client_fd, result_buff, 10000);
							//memset(temp, 0, strlen(temp));
							//sprintf(temp, "%s | 250 %s command succeeds\n", u_name, log_copy);
							print_log(store_path, &client_addr, result_buff, 1);
							memset(srv_print, 0, strlen(srv_print));
							strcpy(srv_print, result_buff);
							write(1, srv_print, strlen(srv_print));
							// sen reusult to client
						}
						else if(strcmp(arr, "CWD") == 0)// exception case over
						{
							arr = strtok(NULL," ");
							int value = 0;
							if(arr == NULL)// not exist path, change directory to /home/user
							{
								memset(buf, 0, strlen(buf));
								sprintf(buf,"/home/%s", getpwuid(getuid())->pw_name);
								value = chdir(buf);
							}
							else if(arr != NULL)
							{
								value = chdir(arr);
							}
							if(value >= 0)// if chdir is Successful
							{
								memset(result_buff, 0 , strlen(result_buff));
								//strcpy(result_buff, u_name);
								strcat(result_buff, "250 CWD command succeeds.\n");
								write(client_fd, result_buff, strlen(result_buff));
								////////////////////////////////////////////////////////////
								print_log(store_path, &client_addr, result_buff, 1);
								memset(srv_print, 0, strlen(srv_print));
								strcpy(srv_print, result_buff);
								write(1, srv_print, strlen(srv_print));
								////////////////////////////////////////////////////////////
								// passing current working direcroty to client
							}
							else // if chdir is error
							{
								memset(result_buff, 0, strlen(result_buff));
								sprintf(result_buff, "550 %s: Can't find such file or directory.\n", arr);
								write(client_fd, result_buff, strlen(result_buff));
								////////////////////////////////////////////////////////////
								print_log(store_path, &client_addr, result_buff, 1);
								memset(srv_print, 0, strlen(srv_print));
								strcpy(srv_print, result_buff);
								write(1, srv_print, strlen(srv_print));
								////////////////////////////////////////////////////////////
							}

						}
						//if FTP command is cd ..
						else if(strcmp(arr, "CDUP") == 0)
						{
							int value = 0;
							value = chdir("..");// change directory previous path
							//memset(buf, 0 , strlen(buf));
							//getcwd(buf, 100);
							//strcat(buf, "\n");
							//strcpy(result_buff, buf);
							if(value >= 0)
							{
								memset(result_buff, 0, strlen(result_buff));
								//strcpy(result_buff, u_name);
								strcpy(result_buff, "250 CWD command performed successfully.\n");
								write(client_fd, result_buff, strlen(result_buff));
								////////////////////////////////////////////////////////////
								print_log(store_path, &client_addr, result_buff, 1);
								memset(srv_print, 0, strlen(srv_print));
								strcpy(srv_print, result_buff);
								write(1, srv_print, strlen(srv_print));
								////////////////////////////////////////////////////////////
								//passing current working directory to client
							}
							/*
							else
							{
								memset(result_buff, 0, strlen(result_buff));
								sprintf(result_buff, "550 %s: Can't find such file or directory\n", arr);
								write(client_fd, result_buff, strlen(result_buff));	
							}
							*/
						}
						////////////////////////////////////////////////
						else if(strcmp(arr, "MKD") == 0)
						{
							umask(0);
							memset(result_buff, 0 , strlen(result_buff));
							int value = 0;
							arr = strtok(NULL ," ");
							while(arr != NULL)//because there can be multiple arguments
							{	
								value = mkdir(arr, 0777);		
								if(value<0)//when mkdir is not sucessful
								{
									//strcat(result_buff, "Directory path or File name Error!\n");
									//strcpy(result_buff, u_name);
									char mkd_temp[100] = {0};
									memset(mkd_temp, 0 ,strlen(mkd_temp));
									strcat(mkd_temp, "550 ");
									strcat(mkd_temp, arr);
									strcat(mkd_temp, ": can't create directory.\n");
									strcat(result_buff, "550 ");
									strcat(result_buff, arr);
									strcat(result_buff, ": can't create directory.\n");
									print_log(store_path, &client_addr, mkd_temp, 1);
									////////////////////////////////////////////////////////////
									//print_log(store_path, &client_addr, result_buff, 1);
									//memset(srv_print, 0, strlen(srv_print));
									//strcpy(srv_print, result_buff);
									//write(1, srv_print, strlen(srv_print));
									////////////////////////////////////////////////////////////
								}
								else
								{
									//strcpy(result_buff, u_name);
									char mkd_temp[100] = {0};
									memset(mkd_temp, 0 ,strlen(mkd_temp));
									strcat(mkd_temp, "250 MKD command performed successfully.\n");
									print_log(store_path, &client_addr, mkd_temp, 1);
									strcat(result_buff, "250 MKD command performed successfully.\n");
									////////////////////////////////////////////////////////////
									//print_log(store_path, &client_addr, result_buff, 1);
									//memset(srv_print, 0, strlen(srv_print));
									//strcpy(srv_print, result_buff);
									//write(1, srv_print, strlen(srv_print));
									////////////////////////////////////////////////////////////
									//strcat(result_buff, "SUCCESS\n");
								}
								arr = strtok(NULL, " ");
							}
							write(client_fd, result_buff, strlen(result_buff));
							//print_log(store_path, &client_addr, result_buff, 1);
							memset(srv_print, 0, strlen(srv_print));
							strcpy(srv_print, result_buff);
							write(1, srv_print, strlen(srv_print));
						}
						//if FTP command is delete
						else if(strcmp(arr, "DELE") == 0)
						{
							memset(result_buff, 0 , strlen(result_buff));
							arr = strtok(NULL, " ");
							int value = 0;
							while(arr != NULL)//because there can be multiple arguments
							{
								value = remove(arr);
								char del_temp[100] = {0};
								if(value < 0)//when remove is not succesful
								{
									//sprintf(result_buff, "550 %s: Can't find such file or directory\n");
									//strcat(result_buff, "Directory path or File name Error!\n");// error code
									//strcpy(result_buff, u_name);
									memset(del_temp, 0 , strlen(del_temp));
									strcat(del_temp, "550 ");
									strcat(del_temp, arr);
									strcat(del_temp, ": Can't find such file or directory.\n");
									print_log(store_path, &client_addr, del_temp, 1);
									strcat(result_buff, "550 ");
									strcat(result_buff, arr);
									strcat(result_buff, ": Can't find such file or directory.\n");
									////////////////////////////////////////////////////////////
									//print_log(store_path, &client_addr, result_buff, 1);
									//memset(srv_print, 0, strlen(srv_print));
									//strcpy(srv_print, result_buff);
									//write(1, srv_print, strlen(srv_print));
									////////////////////////////////////////////////////////////
								}
								else
								{
									//strcat(result_buff, "SUCCESS\n");// successful remove
									//strcpy(result_buff, u_name);
									memset(del_temp, 0 , strlen(del_temp));
									strcat(del_temp, "250 DELE command performed successfully.\n");
									print_log(store_path, &client_addr, del_temp, 1);
									strcat(result_buff, "250 DELE command performed successfully.\n");
									////////////////////////////////////////////////////////////
									//print_log(store_path, &client_addr, result_buff, 1);
									//memset(srv_print, 0, strlen(srv_print));
									//strcpy(srv_print, result_buff);
									//write(1, srv_print, strlen(srv_print));
									////////////////////////////////////////////////////////////
								}
								arr = strtok(NULL, " ");
							}	
							write(client_fd, result_buff, strlen(result_buff));
							//print_log(store_path, &client_addr, result_buff, 1);	
							memset(srv_print, 0, strlen(srv_print));
							strcpy(srv_print, result_buff);
							write(1, srv_print, strlen(srv_print));		
						}	
						//if FTP command is rmdir
						else if(strcmp(arr, "RMD") == 0)
						{
							memset(result_buff, 0 , strlen(result_buff));
							arr = strtok(NULL, " ");
							int value = 0;
							char rmd_temp[100] = {0};
							while(arr != NULL)//because there can be multiple arguments
							{
								value = rmdir(arr);
								if(value < 0)//when rmdir is not succesful
								{
									//strcpy(result_buff, u_name);
									memset(rmd_temp, 0 ,strlen(rmd_temp));
									strcat(rmd_temp, "550 ");
									strcat(rmd_temp, arr);
									strcat(rmd_temp, ": can't remove directory.\n");
									print_log(store_path, &client_addr, rmd_temp, 1);
									strcat(result_buff, "550 ");
									strcat(result_buff, arr);
									strcat(result_buff, ": can't remove directory.\n");
									////////////////////////////////////////////////////////////
									//print_log(store_path, &client_addr, result_buff, 1);
									//memset(srv_print, 0, strlen(srv_print));
									//strcpy(srv_print, result_buff);
									//write(1, srv_print, strlen(srv_print));
									////////////////////////////////////////////////////////////
									//strcat(result_buff, "Directory path or File name Error!\n");
								}
								else
								{
									//strcpy(result_buff, u_name);
									memset(rmd_temp, 0 ,strlen(rmd_temp));
									strcat(rmd_temp, "250 RMD command performed successfully.\n");
									print_log(store_path, &client_addr, rmd_temp, 1);
									strcat(result_buff, "250 RMD command performed successfully.\n");
									////////////////////////////////////////////////////////////
									//print_log(store_path, &client_addr, result_buff, 1);
									//memset(srv_print, 0, strlen(srv_print));
									//strcpy(srv_print, result_buff);
									//write(1, srv_print, strlen(srv_print));
									////////////////////////////////////////////////////////////
									//strcat(result_buff, "SUCCESS\n");
								}
								arr = strtok(NULL, " ");
							}	
							write(client_fd, result_buff, strlen(result_buff));
							//print_log(store_path, &client_addr, result_buff, 1);
							memset(srv_print, 0, strlen(srv_print));
							strcpy(srv_print, result_buff);
							write(1, srv_print, strlen(srv_print));		
						}	
						else if(strcmp(arr, "RNFR") == 0)// rename
						{
							//RNFR A RNTO B
							int q = 0;
							memset(result_buff, 0 , strlen(result_buff));
							char* arr2 = NULL;
							arr = strtok(NULL, " ");//A
							
							arr2 = strtok(NULL, " ");
							arr2 = strtok(NULL, " ");//B
							char ren_temp[100] = {0};
							////////////////////////////////
							struct stat stt;
							memset(temp2, 0, strlen(temp2));
							getcwd(temp2, 100);
							strcat(temp2, "/");
							strcat(temp2, arr);
							//process of importing the current path to create an absolute path
							q = lstat(temp2, &stt);
							if(q == 0)
							{
								memset(result_buff, 0 , strlen(result_buff));
								memset(ren_temp, 0 , strlen(ren_temp));
								strcat(ren_temp, "350 File exists, ready to rename.\n");
								print_log(store_path, &client_addr, ren_temp, 1);
								//strcpy(result_buff, u_name);
								strcat(result_buff, "350 File exists, ready to rename.\n");
								////////////////////////////////////////////////////////////
								//print_log(store_path, &client_addr, result_buff, 1);
								memset(srv_print, 0, strlen(srv_print));
								strcat(srv_print, result_buff);
								//write(1, srv_print, strlen(srv_print));
								////////////////////////////////////////////////////////////
								//write(client_fd, result_buff, strlen(result_buff));
								int value = 0;
								value = rename(arr, arr2);
								if(value < 0)
								{
									//strcpy(result_buff, u_name);
									memset(ren_temp, 0 , strlen(ren_temp));
									strcat(ren_temp, "550 ");
									strcat(ren_temp, arr2);
									strcat(ren_temp, ": can't be renamed.\n");
									print_log(store_path, &client_addr, ren_temp, 1);
									strcat(result_buff, "550 ");
									strcat(result_buff, arr2);
									strcat(result_buff, ": can't be renamed.\n");
									write(client_fd, result_buff, strlen(result_buff));
									////////////////////////////////////////////////////////////
									//print_log(store_path, &client_addr, result_buff, 1);
									//memset(srv_print, 0, strlen(srv_print));
									strcat(srv_print, result_buff);
									write(1, srv_print, strlen(srv_print));
									////////////////////////////////////////////////////////////
								}
								else
								{
									//strcpy(result_buff, u_name);
									memset(ren_temp, 0 , strlen(ren_temp));
									strcat(ren_temp, "250 RNTO command succeeds.\n");
									print_log(store_path, &client_addr, ren_temp, 1);
									strcat(result_buff, "250 RNTO command succeeds.\n");
									write(client_fd, result_buff, strlen(result_buff));
									////////////////////////////////////////////////////////////
									//print_log(store_path, &client_addr, result_buff, 1);
									//memset(srv_print, 0, strlen(srv_print));
									strcat(srv_print, result_buff);
									write(1, srv_print, strlen(srv_print));
									////////////////////////////////////////////////////////////
								}
							}
							else
							{
								memset(ren_temp, 0 , strlen(ren_temp));
								memset(result_buff, 0 , strlen(result_buff));
								sprintf(ren_temp, "550 %s: Can't find such file or directory.\n", arr);
								print_log(store_path, &client_addr, ren_temp, 1);
								sprintf(result_buff, "550 %s: Can't find such file or directory.\n", arr);
								write(client_fd, result_buff, strlen(result_buff));
								////////////////////////////////////////////////////////////
								//print_log(store_path, &client_addr, result_buff, 1);
								memset(srv_print, 0, strlen(srv_print));
								strcpy(srv_print, result_buff);
								write(1, srv_print, strlen(srv_print));
								////////////////////////////////////////////////////////////
							}
						}
						else if(strcmp(arr, "QUIT") == 0)
						{
							memset(temp, 0, strlen(temp));
							sprintf(temp, "Client(%d)'s Release\n", getpid());
							write(1, temp, strlen(temp));

							
							/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
							memset(temp, 0, strlen(temp));
							//strcpy(temp, u_name);
							strcat(temp, "221 Goodbye.\n");
							write(client_fd, temp, strlen(temp));
							////////////////////////////////////////////////////////////
							print_log(store_path, &client_addr, temp, 1);
							memset(temp, 0 , strlen(temp));
							time_t newtime;
							time(&newtime);
							///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
							//char iii[1] = {0};
							//read(fd[0], iii, 100);
							//put(iii);
							sprintf(temp, "LOG_OUT\n[ total service time : %ld sec ]\n", newtime - cli_oldtime);
							print_log(store_path, &client_addr, temp, 1);
							memset(srv_print, 0, strlen(srv_print));
							strcpy(srv_print, result_buff);
							write(1, srv_print, strlen(srv_print));
							////////////////////////////////////////////////////////////
							exit(1);//child processor over
						}
						else if(strcmp(arr, "PORT") == 0)
						{
							///////////////////////////////////////////////////////////////////////////////////////////////////
							int value_control = 0;
							//read(client_fd, temp , 25);// PORT 127,0,0,1,xx,xx
							//temp => PORT 127,0,0,1,xx,xx
							//memset(command, 0 ,strlen(command));
							memset(temp, 0 , 100);
							strcpy(temp, buf_temp);
							//write(1, temp, strlen(temp));
							//write(1, "\n", 2);
							char temp2[100] = {0};
							/////////////////////////////
							memset(temp2, 0 , 100);
							int q, w, z;
							char* arr = NULL;
							
							struct sockaddr_in temp_server;
							arr = strtok(temp, " ,");//PORT
							arr = strtok(NULL, " ,");//127
							strcat(temp2, arr);
							strcat(temp2, ".");
							arr = strtok(NULL, " ,");//0
							strcat(temp2, arr);
							strcat(temp2, ".");
							arr = strtok(NULL, " ,");//0
							strcat(temp2, arr);
							strcat(temp2, ".");
							arr = strtok(NULL, " ,");//1
							strcat(temp2, arr);
							arr = strtok(NULL, " ,");//a

							q = atoi(arr);
							arr = strtok(NULL, " ,");//b
							w = atoi(arr);
							z = q * 256  + w; // new port number 10001 ~ 30000

							///////////////////data connection/////////////////////////////////
							////////////////////////////server => client///////////////////////
							sockfd = socket(PF_INET, SOCK_STREAM, 0);
							memset(&temp_server, 0 ,sizeof(temp_server));
							temp_server.sin_family = AF_INET;
							temp_server.sin_addr.s_addr = inet_addr(temp2);
							temp_server.sin_port = htons(z);

							value_control = connect(sockfd, (struct sockaddr*)&temp_server, sizeof(temp_server));

							if(value_control != 0)// Failed to access data connection
							{
								memset(temp2, 0 , strlen(temp));
								strcpy(temp2, "550 Failed to access.\n");// send to client control message
								write(client_fd, temp2, strlen(temp2));
								sleep(1);
								memset(temp, 0, strlen(temp));
								sprintf(temp, "%s", temp2);
								print_log(store_path, &client_addr, temp, 1);

								memset(srv_print, 0, strlen(srv_print));
								strcpy(srv_print, temp2);
								write(1, srv_print, strlen(srv_print));
								//write(1,"550 Failed to access\n", 22);
								//exit(1);
							}
							else// success to access data connection
							{
								memset(temp2, 0,  100);
								strcpy(temp2, "200 PORT command performed successfully.\n");// send to client control message
								write(client_fd, temp2, strlen(temp2));
								sleep(1);
								memset(temp, 0, strlen(temp));
								sprintf(temp, "%s", temp2);
								print_log(store_path, &client_addr, temp, 1);

								memset(srv_print, 0, strlen(srv_print));
								strcpy(srv_print, temp2);
								write(1, srv_print, strlen(srv_print));
								//sleep(1);
							}
							///////////////////////////////////////////////////////////////////////////////////////////////////

						}
						//////////////////////////////////////////////////
						else if(strcmp(arr, "TYPE") == 0)
						{
							arr = strtok(NULL, " ");
							if(strcmp(arr, "binary") == 0 || strcmp(arr, "I") == 0)// if Type binary
							{
								memset(MODE, 0 , strlen(MODE));
								strcpy(MODE, "BINARY");// BINARY MODE set
								memset(temp, 0 , strlen(temp));
								//strcpy(temp, u_name);
								strcat(temp, "201 Type set to I.\n");// send to client control message
								write(client_fd, temp, strlen(temp));
								////////////////////////////////////////////////////////////
								print_log(store_path, &client_addr, temp, 1);
								memset(srv_print, 0, strlen(srv_print));
								strcpy(srv_print, temp);
								write(1, srv_print, strlen(srv_print));
								////////////////////////////////////////////////////////////
							}
							else if(strcmp(arr, "ascii") == 0 || strcmp(arr, "A") == 0)// if Type ascii
							{
								memset(MODE, 0 , strlen(MODE));
								strcpy(MODE, "ASCII");// ASCII MODE set
								memset(temp, 0, strlen(temp));
								//strcpy(temp, u_name);
								strcat(temp, "201 Type set to A.\n");// send to client control message
								write(client_fd, temp, strlen(temp));
								////////////////////////////////////////////////////////////
								print_log(store_path, &client_addr, temp, 1);
								memset(srv_print, 0, strlen(srv_print));
								strcpy(srv_print, temp);
								write(1, srv_print, strlen(srv_print));
								////////////////////////////////////////////////////////////
							}
							else
							{
								memset(temp, 0 , strlen(temp));
								//strcpy(temp, u_name);
								strcat(temp, "502 Type doesn't set.\n");// send to client control message
								write(client_fd, temp, strlen(temp));
								////////////////////////////////////////////////////////////
								print_log(store_path, &client_addr, temp, 1);
								memset(srv_print, 0, strlen(srv_print));
								strcpy(srv_print, temp);
								write(1, srv_print, strlen(srv_print));
								////////////////////////////////////////////////////////////
							}
						}	
						else if(strcmp(arr, "RETR") == 0)
						{
							arr = strtok(NULL, " ");// arr => filename 
							memset(temp, 0 , strlen(temp));
							sprintf(temp, "150 Openning %s mode data connection for %s.\n", MODE, arr);// send to client control message
							write(client_fd, temp, strlen(temp));
							memset(srv_print, 0, strlen(srv_print));
							strcpy(srv_print, temp);
							write(1, srv_print, strlen(srv_print));
							long int total = 0;// for using total data bytes 
							////////////////////////////////////////////////////////////
							print_log(store_path, &client_addr, temp, 1);
							////////////////////////////////////////////////////////////
							if(strcmp(MODE, "BINARY") == 0)//if BINARY MODE get
							{
								char array[300] = {0};
								memset(array, 0 , strlen(array));
								int read_count = 0;
								int f = 0;
								f = open(arr, O_RDONLY, BIN_MODE);// file open
								if(f == -1)// if file not exist
								{
									memset(array, 0 , strlen(array));
									//strcpy(array, u_name);
									strcat(array, "550 Failed transmission.\n");//send to client control message
									write(client_fd, array, strlen(array));
									////////////////////////////////////////////////////////////
									print_log(store_path, &client_addr, array, 1);
									memset(srv_print, 0, strlen(srv_print));
									strcpy(srv_print, array);
									write(1, srv_print, strlen(srv_print));
									////////////////////////////////////////////////////////////
								}
								else// if file exist
								{
									while(1)
									{
										memset(array, 0 , strlen(array));
										//puts("!!!!!!!!!!!!!!!!!!!!!!!!!!!");
										read_count = read(f, array, 300);// data read
										//puts("@@@@@@@@@@@@@@@@@@@@@@@@@");
										if(read_count == 0)
										{
											break;
										}
										write(sockfd, array, strlen(array));// send to data using data connection
										total += strlen(array) * sizeof(char);//
										//printf("%s", array);
									}
									memset(array, 0 , strlen(array));
									//strcpy(array, u_name);
									strcat(array, "226 Complete transmission.\n");//send to client control message
									write(client_fd, array, strlen(array));
									memset(srv_print, 0, strlen(srv_print));
									strcpy(srv_print, array);
									write(1, srv_print, strlen(srv_print));
									////////////////////////////////////////////////////////////
									memset(array, 0, strlen(array));
									sprintf(array, "226 Complete transmission. | %ld bytes\n", total);//send to client control message
									print_log(store_path, &client_addr, array, 1);
									////////////////////////////////////////////////////////////
								}
								close(f);
								close(sockfd);			

							}
							else if(strcmp(MODE, "ASCII") == 0)// if ASCII MODE get
							{
								char array[300] = {0};
								char array2[300] = {0};
								char copy_array[300] = {0};
								memset(array, 0 , strlen(array));
								int read_count = 0;
								int f = 0;
								f = open(arr, O_RDONLY, ASCII_MODE);
								if(f == -1)// if file not eixst
								{
									memset(array, 0 , strlen(array));
									//strcpy(array, u_name);
									strcat(array, "550 Failed transmission.\n");//send to client control message
									write(client_fd, array, strlen(array));
									////////////////////////////////////////////////////////////
									print_log(store_path, &client_addr, array, 1);
									memset(srv_print, 0, strlen(srv_print));
									strcpy(srv_print, array);
									write(1, srv_print, strlen(srv_print));
									////////////////////////////////////////////////////////////
								}
								else// if file exist
								{
									while(1)
									{
										memset(array, 0 , strlen(array));
										memset(copy_array, 0 , strlen(copy_array));
										read_count = read(f, array, 300);// read data
										if(read_count == 0)
										{
											break;
										}
										int z,x,q = 0;
										for(z = 0 ; z + 1 < strlen(array) ; z++)
										{
											if(array[z] == '\n')
											{
												if(array[z+1] == '\r')
												{
													
													array[z] = ' ';
													array[z + 1] = '\n';
												}
											}
											else if(array[z] == '\r')
											{
												if(array[z+1] == '\n')
												{
													array[z] = ' ';
													array[z + 1] = '\n';	
												}
											}
										}// \n\r -> \n, \r\n -> \n, becasue mode is ascii
										write(sockfd, array, strlen(array));// send data to client using data connection
										total += strlen(array) * sizeof(char);
									}
									memset(array, 0 , strlen(array));
									//strcpy(array, u_name);
									strcat(array, "226 Complete transmission.\n");//send to client control message
									write(client_fd, array, strlen(array));
									memset(srv_print, 0, strlen(srv_print));
									strcpy(srv_print, array);
									write(1, srv_print, strlen(srv_print));
									////////////////////////////////////////////////////////////
									memset(array, 0, strlen(array));
									sprintf(array, "226 Complete transmission. | %ld bytes\n", total);//send to client control message
									print_log(store_path, &client_addr, array, 1);
									//print_log(store_path, &client_addr, array, 1);
									////////////////////////////////////////////////////////////
								}
								close(f);
								close(sockfd);
							}
						}
						else if(strcmp(arr, "STOR") == 0)
						{
							arr = strtok(NULL, " ");
							long int total = 0;
							memset(temp, 0 , strlen(temp));
							sprintf(temp, "150 Openning %s mode data connection for %s.\n", MODE, arr);//send to client control message
							write(client_fd, temp, strlen(temp));
							////////////////////////////////////////////////////////////
							print_log(store_path, &client_addr, temp, 1);
							memset(srv_print, 0, strlen(srv_print));
							strcpy(srv_print, temp);
							write(1, srv_print, strlen(srv_print));
							////////////////////////////////////////////////////////////
							if(strcmp(MODE, "BINARY") == 0 || strcmp(MODE, "ASCII") == 0)// BINARY or ASCII MODE put
							{
								char array[500] = {0};
								memset(array, 0 , strlen(array));
								int read_count = 0;
								int f = 0;
								f = open(arr, O_WRONLY | O_CREAT, 00777);//file open or create file
								while(1)
								{
									memset(array, 0 , strlen(array));
									//puts("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
									read_count = read(sockfd, array, 500);// read data from client using data connection
									//printf("%s%d\n",array, read_count);
									//puts("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@2");
									if(read_count == 0)
									{
										break;
									}
									
									if(strcmp(MODE, "BINARY") == 0)// if MODE is BINARY
									{
										write(f, array, strlen(array));
										total += strlen(array) * sizeof(char);
									}
									else//if MODE is ASCII
									{
										
										int z,x,q = 0;
										for(z = 0 ; z + 1 < strlen(array) ; z++)
										{
											if(array[z] == '\n')
											{
												if(array[z+1] == '\r')
												{
													
													array[z] = ' ';
													array[z + 1] = '\n';
												}
											}
											else if(array[z] == '\r')
											{
												if(array[z+1] == '\n')
												{
													array[z] = ' ';
													array[z + 1] = '\n';	
												}
											}
										}
										//\n\r -> \n, \r\n-> \n
										write(f, array, strlen(array));
										total += strlen(array) * sizeof(char);
									}
								}
								memset(array, 0 , strlen(array));
								//strcpy(array, u_name);
								strcat(array, "226 Complete transmission.\n");
								write(client_fd, array, strlen(array));
								memset(srv_print, 0, strlen(srv_print));
								strcpy(srv_print, array);
								write(1, srv_print, strlen(srv_print));
								////////////////////////////////////////////////////////////
								memset(array, 0, strlen(array));
								sprintf(array, "226 Complete transmission. | %ld bytes\n", total);
								print_log(store_path, &client_addr, array, 1);
								//print_log(store_path, &client_addr, array, 1);
								////////////////////////////////////////////////////////////

								close(f);
								close(sockfd);	
							}
						}
						//////////////////////////////////////////////////
						else// if client passing to server, not invalid command
						{
							memset(temp, 0, strlen(temp));
							//strcpy(temp, u_name);
							strcat(temp, "Command Error!\n");
							write(client_fd, temp, strlen(temp));
							////////////////////////////////////////////////////////////
							print_log(store_path, &client_addr, temp, 1);
							////////////////////////////////////////////////////////////
						}
					}
				}
			}
			else if(pid > 0)//behavior of the parent process
			{
				//client_info(&client_addr);//print clinet information
				/////////////////////////////////////////////////////////////////
				//char user_temp[100] = {0};
				//memset(user_temp, 0 , strlen(user_temp));
				//read(fd[0], user_temp, 100);
				////////////////////////////////////////////////////////////////
				time(&oldtime);
				//sprintf(temp, "Child Process ID : %d", pid);
				//print process ID
				//////use global structures to store information 
				//////  about child procssess
				information[num-1].pid = pid;
				information[num-1].port = client_addr.sin_port;
				information[num-1].oldtime = oldtime;
				//print();// call print function
			}
			else//error fork exception case
			{
				memset(buf, 0 , strlen(buf));
				strcpy(buf,"fork_error!\n");
				strcpy(result_buff, buf);
				write(client_fd, result_buff, strlen(result_buff));
				write(1, result_buff, strlen(result_buff));
				exit(1);
			}
			close(client_fd);//communication over
		}
	}
	return 0;
}
void sh_chld(int signum)// if signal is SIGCHLD handler function
{
	int pid;
	pid = wait(NULL);// for get pid(child processor)
	int a;
	//nt index;
	for(a = 0 ; a < num ; a++)
	{
		if(pid == information[a].pid)
		{
			f_index = a;
		}
	}
	//char ppip[1] = "1";
	//write(fd[1],ppip, strlen(ppip));
	//pull th value forward one space at a time
	///pulling algorithm
	char temp[100] = {0};
	

	for(a = f_index + 1 ; a < num ; a++)
	{
		information[a - 1].pid = information[a].pid;
		information[a - 1].port = information[a].port;
		information[a - 1].time = information[a].time;
		information[a - 1].oldtime = information[a].oldtime; 
	}
	num--;//number of child process --
	//print();//call print function

	////////////////////////////////////////////////
	//print_log(stor_path, &client_addr, temp, 1);



}
void sh_int(int signum)
{
	int a;
	for(a = 0 ; a < num ; a++)
	{
		kill(information[a].pid, SIGTERM);	
		//terminate all child processors in the server	
	}
	char temp[100] = {0};
	memset(temp, 0, strlen(temp));
	sprintf(temp, "Server is terminated\n");
	print_log(store_path, &client_addr, temp, 0);
	exit(0);
}
int log_auth(int connfd, char* username_temp, struct sockaddr_in* cli)
{
	int control = 0;
	char user[100], passwd[MAX_BUF];
	int n, count=1;
	char temp[100] = {0};
	char copy[100] = {0};
	char username[100] = {0};
	char* arr = NULL;
	char srv_print[100] = {0};
	//puts(inet_ntoa(client_addr.sin_addr));
	while(1) 
	{
		memset(temp, 0, strlen(temp));
		sprintf(temp, "** User is trying to log-in (%d/3) **\n", count);
		// log_in count
		write(1, temp, strlen(temp));

		memset(user, 0 , 100);

		read(connfd, user, 100);// read username from client
		strcpy(copy, user);
		arr = NULL;
		arr = strtok(copy, " ");
		arr = strtok(NULL, " ");// arr =>  userID
		/////////////////////////////////
		strcpy(username_temp, arr);
		////////////////////////////////
		memset(username, 0, strlen(username));
		strcpy(username, arr);
		if((n = user_match(arr)) == 1)// if ID is allowed ID
		{
			memset(temp, 0 , strlen(temp));
			strcpy(temp, "331 Password is required for ");
			strcat(temp, arr);
			strcat(temp, ".");
			write(connfd, temp, strlen(temp));
			/////////////////////////////////////////
			strcat(temp, "\n");
			print_log(store_path, cli, temp, 1);
			memset(srv_print, 0, strlen(srv_print));
			strcpy(srv_print, temp);
			write(1, srv_print, strlen(srv_print));
			/////////////////////////////////////////
			//sleep(1);
			//write(1, temp, strlen(temp));
			//write(1, "\n", 2);
			break;
		}
		else if(n == 0)//log_in fail
		{
			if(count >= 3) //three time more fail
			{
				memset(temp, 0, strlen(temp));
				strcpy(temp, "530 Failed to log-in.");//DISCONNECTION
				write(connfd, temp, strlen(temp));
				/////////////////////////////////////////
				strcat(temp, "\n");
				print_log(store_path, cli, temp, 1);
				memset(srv_print, 0, strlen(srv_print));
				strcpy(srv_print, temp);
				write(1, srv_print, strlen(srv_print));
				/////////////////////////////////////////
				//write(1, temp, strlen(temp));
				//write(1, "\n", 2);
				// connection over
				return 0;
			}
			memset(temp, 0 , strlen(temp));
			strcpy(temp, "430 Invalid username or password.");// if ID is not allowd id
			write(connfd, temp, strlen(temp));
			/////////////////////////////////////////
			strcat(temp, "\n");
			print_log(store_path, cli, temp, 1);
			memset(srv_print, 0, strlen(srv_print));
			strcpy(srv_print, temp);
			write(1, srv_print, strlen(srv_print));
			/////////////////////////////////////////
			//sleep(1);
			//write(1, temp, strlen(temp));
			//write(1, "\n", 2);
			count++;//log_in fail count
		}
		arr = NULL;
	}
	// user_match function is check that the passwd corresponding to 
	// username is correct
	// user_match = 1 is log_in!
	// user_match = 0 is log_in fail!
	while(1)
	{			
		memset(temp, 0, 100);
		sprintf(temp, "** User is trying to log-in (%d/3) **\n", count);
		//control++;
		write(1, temp, strlen(temp));

		read(connfd, passwd, MAX_BUF);// read passwd from client

		memset(copy, 0, 100);
		strcpy(copy, passwd);
		arr = strtok(copy, " ");
		arr = strtok(NULL, " ");

		if((n = user_match2(username, arr)) == 1)// if password is allowed
		{
			memset(temp, 0 , strlen(temp));
			strcpy(temp, "230 User ");
			strcat(temp, username);
			strcat(temp, " logged in.");
			write(connfd, temp, strlen(temp));//log_in!
			/////////////////////////////////////////
			strcat(temp, "\n");
			print_log(store_path, cli, temp, 1);
			memset(srv_print, 0, strlen(srv_print));
			strcpy(srv_print, temp);
			write(1, srv_print, strlen(srv_print));
			/////////////////////////////////////////
			//sleep(1);
			//write(1, temp, strlen(temp));
			//write(1, "\n", 2);
			break;
		}
		else if(n == 0)//log_in fail
		{
			if(count >= 3) //three time more fail
			{
				memset(temp, 0, 100);
				strcpy(temp, "530 Failed to log-in.");// DISCONNECTION
				write(connfd, temp, strlen(temp));
				/////////////////////////////////////////
				strcat(temp, "\n");
				print_log(store_path, cli, temp, 1);
				memset(srv_print, 0, strlen(srv_print));
				strcpy(srv_print, temp);
				write(1, srv_print, strlen(srv_print));
				/////////////////////////////////////////
				//sleep(1);
				//write(1, temp, strlen(temp));
				//write(1, "\n", 2);
				// connection over
				return 0;
			}
			memset(temp, 0, 100);
			strcpy(temp, "430 Invalid username or password.");//if password is not allowed
			write(connfd, temp, strlen(temp));
			/////////////////////////////////////////
			strcat(temp, "\n");
			print_log(store_path, cli, temp, 1);
			memset(srv_print, 0, strlen(srv_print));
			strcpy(srv_print, temp);
			write(1, srv_print, strlen(srv_print));
			/////////////////////////////////////////
			//sleep(1);
			//write(1, temp, strlen(temp));
			//write(1, "\n", 2);
			count++;//log_in fail count
		}
		arr = NULL;
	}
	return 1;// log_in!!
}
///////////////////////////////////////////////////////////////////////
// log_auth function
// ================================================================= //
// user_match function is check that the passwd corresponding to 
// username is correct
// user_match = 1 is log_in!
// user_match = 0 is log_in fail!
// ================================================================= //
///////////////////////////////////////////////////////////////////////
int user_match(char *user)
{
	char* arr = NULL;
	char* arr2 = NULL;
	arr = strtok(user, "\n");

	int result = 0;
	FILE *fp;
	struct passwd *pw;
	fp = fopen("passwd", "r");//file open "passwd" read only
	// save the content of fd as structure in pw
	while((pw = fgetpwent(fp)) != NULL)// repeatly confirm
	{
		if(strcmp(pw->pw_name, arr) == 0) 
		{
			result++;// if the passwd corresponding to username is correct
			break;
		}
	}
	// return the corresponding result value
	if(result != 0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int user_match2(char *user, char *passwd)
{
	char* arr = NULL;
	char* arr2 = NULL;
	arr = strtok(user, "\n");
	arr2 = strtok(passwd, "\n");
	int result = 0;
	FILE *fp;
	struct passwd *pw;
	fp = fopen("passwd", "r");//file open "passwd" read only
	// save the content of fd as structure in pw
	while((pw = fgetpwent(fp)) != NULL)// repeatly confirm
	{
		if(strcmp(pw->pw_name, arr) == 0 && strcmp(pw->pw_passwd, arr2) == 0)
		{
			result++;// if the passwd corresponding to username is correct
			break;
		}
	}
	// return the corresponding result value
	if(result != 0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

void complete_transmission()// send to client controlmessage
{
	char srv_print[100] = {0};
	char temp[100] = {0};
	//strcpy(temp, u_name);
	strcat(temp, "226 Complete transmission.\n");
	write(client_fd, temp, strlen(temp));
	memset(srv_print, 0, strlen(srv_print));
	strcpy(srv_print, temp);
	write(1, srv_print, strlen(srv_print));
	//sleep(10);
	//sleep(1);
}

void failed_transmission()// send to client controlmessage
{
	char srv_print[100] = {0};
	char temp[100] = {0};
	//strcpy(temp, u_name);
	strcat(temp, "550 Failed transmission.\n");
	write(client_fd, temp, strlen(temp));
	memset(srv_print, 0, strlen(srv_print));
	strcpy(srv_print, temp);
	write(1, srv_print, strlen(srv_print));
}
void print_log(char* path, struct sockaddr_in* client, char* buf, int mode)//function for using log message 
{
	FILE* log;
	char file_path[100] = {0};
	char temp[100] = {0};
	char message[200] = {0};
	memset(temp, 0, strlen(temp));
	memset(message, 0, strlen(message));
	time_t t;
	struct tm* lt;
	time(&t);
	lt = localtime(&t);
	strftime(temp, 100, "%c", lt);
	strcpy(file_path, path);
	strcat(file_path, "/logfile");
	// append a log message to buf and print to file(logfile;
	if(mode == 0)// server started ofr server terminated message
	{
		sprintf(message, "%s", temp);
		strcat(message, " ");
	}
	else if(mode == 1)
	{
		sprintf(message, "%s [%s:%d] %s ", temp, inet_ntoa(client->sin_addr), client->sin_port, u_name);
	}
	strcat(message, buf);

	log = fopen(file_path, "a");//logfile open or create
	fputs(message, log);//print to logfile
	fclose(log);
	return;
	//printf("%s\n", message);
	//log = fopen()
}
