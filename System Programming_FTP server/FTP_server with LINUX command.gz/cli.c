
///////////////////////////////////////////////////////////////////////
// File Name : Assignment#3(cli.c)//
// Date : 2017/06/07 //
// Os : Ubuntu 12.04 LTS 64bits //
// Author : kim tae seok//
// Student ID : 2013722082 //
// ----------------------------------------------------------------- //
// Title : System Programming Assignment #3 ( ftp server_client ) //
///////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/wait.h>
#include <signal.h>
#include <time.h>
#include <fcntl.h>
#define FLAGS (O_RDWR | O_CREAT | O_TRUNC)
#define ASCII_MODE (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)
#define BIN_MODE (S_IXUSR | S_IXGRP | S_IXOTH)
#define MAX_BUF 256
int sockfd;// global variable -> server desvcriptor
char MODE[100] = "BIN_MODE";
void process_result(char* buff);// print result value from server 
void sg_int();// signal handler function
int log_in(int sockfd);
int main(int argc, char** argv)
{
	int important_control = 0;
	int login = 0;
	char rcv_buff[10000] = {0};
	struct sockaddr_in serv_addr;
	char temp[100] = {0};
	char buff[100] = {0};
	int aflag = 0;
	int lflag = 0;
	int error = 0;
	int t_argc = 0;
	char** t_argv = NULL;
	int c = 0 ;
	int index;
	signal(SIGINT, sg_int);
	memset(buff,0, 100);
	char* arr = NULL;
	char buf2[100] = {0};
	////////////////////////////////
	t_argv = (char**)malloc(sizeof(int*)*10);
	int a;
	for(a = 0 ; a< 10 ; a++)
	{
		t_argv[a] = (char*)malloc(sizeof(int)*10);
	}	
	////////////////////////////////////
	
	
	/////////socket commnunication//////////////
	if(argv[1] == NULL || argv[2] == NULL)// portnumber or IP address exception case
	{
		write(1,"error_portnumber or IP address", 31);
		write(1,"\n",2);
		exit(1);
	}
	if((sockfd = socket(AF_INET, SOCK_STREAM,0)) == -1)// socket error exception case
	{
		write(1, "error_socket", 13);
		write(1,"\n",2);
		exit(1);
	}
	// store information about the server to connection
	memset(&serv_addr,0 , sizeof(serv_addr));
	serv_addr.sin_family=AF_INET;
	serv_addr.sin_addr.s_addr=inet_addr(argv[1]);
	serv_addr.sin_port=htons(atoi(argv[2]));

	if(connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)))
	// connection error exception case
	{
		write(1, "error_connect", 14);
		write(1,"\n",2);
		exit(1);
	}
	///////////////////////////////////////////////////////////////////
	memset(temp, 0 , strlen(temp));
	
	read(sockfd, temp,300);///////////REJECTION or OK

	if(strcmp(temp, "431 This client can't access. Close the session.") == 0)// not exist IP in access.txt
	{
		write(1, temp, strlen(temp));
		write(1, "\n", 2);
		close(sockfd);
		exit(0);
	}
	else// exist IP in access.txt
	{
		//memset(buff, 0 , strlen(buff));
		//strcpy(buff, "Connected to sswlab.kw.ac.kr.\n");
		//write(1, buff, strlen(buff));
		write(1, temp, strlen(temp));// welcom message
		write(1, "\n", 2);
	}
	
	////log_in function start//////////
	login = log_in(sockfd);
	if(login == 0)// DISCONNECTION
	{
		close(sockfd);
		exit(0);
	}
	
	///////////////////////////////////////////////////////////////////
	while(1)
	{
		important_control = 0;
		memset(buff,0, 100);
		memset(buf2, 0, 100);
		// initializing opt value //
		optind = 0;// very important expression
		aflag = 0 ;
		lflag = 0;
		error = 0;
		t_argc = 0;
		c = 0;
		arr = NULL;
		write(1,"ftp> ", 6);
		read(0, buff, 100);
		for(a = 0 ; a< 10 ; a++)
		{
			memset(t_argv[a], 0 , 10);
		}		
		arr = strtok(buff, " \n");
		// 2dimension array initializing for using getopt
		while(1)// user command -> t_argv[][]
		{
			if(arr == NULL)
			{
				break;
			}
			else
			{
				//puts(arr);
				strcpy(t_argv[t_argc++], arr);
			}
			arr = strtok(NULL, " \n");
		}
		// using getopt function //
		strcpy(buf2, t_argv[0]);// copy command
		///////////////////////////////////////////////////////////////////////
		// Use getopt()
		// ================================================================= //
		// t_argc => counts the number of options that have been entered
		// t_argv => store the arguments in a two-dimensional array
		// optind => the position of the beginning of non-option characters in 	t_argv[][]
		// ================================================================= //
		// Reapeat c is not -1(if c == -1 => all command line have been parsed)
		// Switch(c) 
		// c = 'a' => aflag = 1
	  	// c = 'b' => bflag = 1
		///////////////////////////////////////////////////////////////////////
		while ((c = getopt (t_argc, t_argv, "al")) != -1)
		{
			switch (c)// switch case input c
			{
				case 'a'://if option c
					aflag = 1;
					break;
				case 'l'://if option b
					lflag = 1;
					break;
				case '?'://if not option input
					error = 1;
					break;
			}
		}
		///////////////////////////////////////////////////////////////////////
		index = optind;
		// index =  not argument index (t_argv)
		///////////////////////////////////////////////////////////////////////
		// command convert function
		// ================================================================= //
		// t_argv => user-entered string(command and path)
		// /////////////////////////////command///////////////////////////////
		// ls -> NLST(include option, path or not)
		// dir -> LIST(include path or not)
		// pwd -> PWD
		// cd -> CWD
		// cd .. -> CDUP
		// mkdir -> MKD
		// delete -> DELE
		// rmdir -> RMD
		// rename -> RNFR&RNTO
		// quit -> QUIT
		// Ctrl + C -> QUIT
		// bin -> TYPE I
		// ascii -> TYPE A
		// TYPE input -> TYPE input
		// get -> RETR
		// put -> STOR
		// ================================================================= //
		///////////////////////////////////////////////////////////////////////
		if(strcmp(buf2,"ls") == 0)// if command is ls 
		{
			important_control++;
			//////////////////////////data connection////////////////////////////////////////
			char* addr;
			srand((unsigned)time(NULL));
			int port_num = 0;
			int b = 0;
			char temp1[100] = {0};
			char temp2[100] = {0};
			memset(temp1, 0 , strlen(temp1));
			memset(temp2, 0 , strlen(temp2));
			//////////////////////Make PORT command///////////////////
			sprintf(temp1,"PORT %s,", inet_ntoa(serv_addr.sin_addr));
			int a;
			for(a = 0 ; a < strlen(temp1) ; a++)
			{
				if(temp1[a] == '.')
				{
					temp1[a] = ',';
				}
			}
			a = 0;
			port_num = rand()%50000+10001;// Port 10001 ~ 60000
			a = port_num / 256;
			b = port_num % 256;
			sprintf(temp2, "%d,%d", a, b);
			strcat(temp1, temp2);
			addr = temp1;// addr => PORT 127,0,0,1,a,b;
			//////////////////////////////////////////////////////////////
			write(sockfd, addr, strlen(addr));
			//puts(addr);
			//sleep(1);
			///////////////////data connection/////////////////////
			////////////////////client => server///////////////////
			struct sockaddr_in temp_server, temp_client;
			int temp_clilen = sizeof(temp_client);
			int server_fd, client_fd;

			server_fd = socket(AF_INET, SOCK_STREAM, 0);
			memset(&temp_server, 0, sizeof(temp_server));
			temp_server.sin_family = AF_INET;
			temp_server.sin_addr.s_addr = htonl(INADDR_ANY);
			temp_server.sin_port = htons(port_num);
			
			bind(server_fd, (struct sockaddr*)&temp_server, sizeof(temp_server));
			listen(server_fd, 5);
			
			if((client_fd = accept(server_fd, (struct sockaddr*)&temp_client, &temp_clilen)) == -1)
			{
				write(1, "error_accept", 13);
				write(1,"\n",2);
				exit(1);
			}
			
			char d_copy[100] = {0};
			memset(temp, 0 , 100);
			memset(d_copy, 0 , strlen(d_copy));
			
			read(sockfd, temp, 100);

			strcpy(d_copy, temp);
			arr = strtok(d_copy, " ");
			
			if(strcmp(arr, "550") == 0)
			{
				write(1, temp, strlen(temp));
				continue;
			}
			else
			{
				write(1, temp, strlen(temp));
				if(error == 1)
				{
					write(1,"not_invalid_option\n",19);
				}
				else if(t_argv[optind] == NULL || index >= t_argc)// not error command and not exist not option arument
				{
					if(aflag == 0 && lflag == 0)// NLST
					{
						char buf[100] = {0};
						memset(buf, 0 , 100);
						strcpy(buf, "NLST");
						write(sockfd,buf,strlen(buf));

						//sleep(1);	
						// pasing to server 
					}
					else if(aflag == 1 && lflag == 0)// NLST -a
					{
						char buf[100] = {0};
						memset(buf, 0 , sizeof(buf));
						strcpy(buf, "NLST ");
						strcat(buf,"-a");
						write(sockfd,buf,strlen(buf));	
					}
					else if(aflag == 0 && lflag == 1)// NLST -l
					{
						char buf[100] = {0};
						memset(buf, 0 , sizeof(buf));
						strcpy(buf, "NLST ");
						strcat(buf,"-l");
						write(sockfd,buf,strlen(buf));	
					}
					else if(aflag == 1 && lflag == 1)// NLST -al || NLST -la
					{
						char buf[100] = {0};
						memset(buf, 0 , sizeof(buf));
						strcpy(buf, "NLST ");
						strcat(buf,"-al");
						write(sockfd,buf,strlen(buf));	
					}
				}
				else if(t_argv[optind] != NULL)// include not option argument 
				{
					strcpy(temp, t_argv[optind]);// temp is directory path or file name
					if(aflag == 0 && lflag == 0)// NLST path
					{
							char buf[100] = {0};
						memset(buf, 0 , sizeof(buf));
						strcpy(buf, "NLST ");
						strcat(buf, temp);
						write(sockfd,buf,strlen(buf));
							
					}
					else if(aflag == 1 && lflag == 0)// NLST path -a
					{
						char buf[100] = {0};
						memset(buf, 0 , sizeof(buf));
						strcpy(buf, "NLST ");
						strcat(buf, temp);
						strcat(buf," ");
						strcat(buf,"-a");
						
						
						write(sockfd,buf,strlen(buf));	
					}
					else if(aflag == 0 && lflag == 1)// NLST path -l
					{
						char buf[100] = {0};
						memset(buf, 0 , sizeof(buf));
						strcpy(buf, "NLST ");
						strcat(buf, temp);
						strcat(buf, " ");
						strcat(buf,"-l");
						
						
						write(sockfd,buf,strlen(buf));	
					}
					else if(aflag == 1 && lflag == 1)// NLST path -al || NLST path -la
					{
						char buf[100] = {0};
						memset(buf, 0 , sizeof(buf));
						strcpy(buf, "NLST ");
						strcat(buf, temp);
						strcat(buf, " ");
						strcat(buf,"-al");

						
						write(sockfd,buf,strlen(buf));// passing to server	
					}
				}
				if(error != 1)
				{
					//sleep(1);
					memset(temp, 0 , strlen(temp));
					read(sockfd, temp, 100);//150
					//puts("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
					write(1, temp, strlen(temp));
					////////////////////////////////////
					//sleep(1);
					memset(rcv_buff, 0 , strlen(rcv_buff));
					read(client_fd, rcv_buff, 10000);// complete transmission or Failed transmission
					//puts("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
					write(1, rcv_buff, strlen(rcv_buff));
					//sleep(1);
					memset(temp, 0 ,strlen(temp));
					read(sockfd, temp, 100);// 226 or 550
					//puts("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
					write(1, temp, strlen(temp));
					//fflush(stdout);
					memset(temp, 0, strlen(temp));
					sprintf(temp, "OK, %ld bytes is received.", strlen(rcv_buff)*sizeof(char));
					write(1, temp, strlen(temp));
					write(1, "\n", 2);

					close(client_fd);
				}
				////////////////////////////////////
			}

			///////////////////////////////////////////////////////////////////////////////////////////////////////////
		}
		else if(strcmp(buf2, "dir") == 0)// if command is dir
		{
			important_control++;
			//////////////////////////data connection////////////////////////////////////////
			char* addr;
			srand((unsigned)time(NULL));
			int port_num = 0;
			int b = 0;
			char temp1[100] = {0};
			char temp2[100] = {0};
			memset(temp1, 0 , strlen(temp1));
			memset(temp2, 0 , strlen(temp2));
			//////////////////////Make PORT command///////////////////
			sprintf(temp1,"PORT %s,", inet_ntoa(serv_addr.sin_addr));
			int a;
			for(a = 0 ; a < strlen(temp1) ; a++)
			{
				if(temp1[a] == '.')
				{
					temp1[a] = ',';
				}
			}
			a = 0;
			port_num = rand()%50000+10001;// Port 10001 ~ 30000
			a = port_num / 256;
			b = port_num % 256;
			sprintf(temp2, "%d,%d", a, b);
			strcat(temp1, temp2);
			addr = temp1;// addr => PORT 127,0,0,1,a,b
			//////////////////////////////////////////////////////////////
			write(sockfd, addr, strlen(addr));
			
			///////////////////data connection/////////////////////
			////////////////////client => server///////////////////
			struct sockaddr_in temp_server, temp_client;
			int temp_clilen = sizeof(temp_client);
			int server_fd, client_fd;

			server_fd = socket(AF_INET, SOCK_STREAM, 0);
			memset(&temp_server, 0, sizeof(temp_server));
			temp_server.sin_family = AF_INET;
			temp_server.sin_addr.s_addr = htonl(INADDR_ANY);
			temp_server.sin_port = htons(port_num);
			
			bind(server_fd, (struct sockaddr*)&temp_server, sizeof(temp_server));
			listen(server_fd, 5);
			
			if((client_fd = accept(server_fd, (struct sockaddr*)&temp_client, &temp_clilen)) == -1)
			{
				write(1, "error_accept", 13);
				write(1,"\n",2);
				exit(1);
			}
			
			char d_copy[100] = {0};
			memset(temp, 0 , strlen(temp));
			memset(d_copy, 0 , strlen(d_copy));
			
			read(sockfd, temp, 100);

			strcpy(d_copy, temp);
			arr = strtok(d_copy, " ");
			
			if(strcmp(arr, "550") == 0)
			{
				write(1, temp, strlen(temp));
				continue;
			}
			else
			{
				write(1, temp, strlen(temp));
				if(t_argc == 1)// command only dir
				{
					char buf[100] = {0};
					strcpy(buf, "LIST");//convert
					write(sockfd,buf,strlen(buf));
				}
				else if(t_argc == 2)// command include path
				{
					char buf[100] = {0};
					strcpy(buf, "LIST ");//convert
					strcat(buf, t_argv[1]);//include path
					write(sockfd,buf,strlen(buf));
					//passing to server 
				}	
				else//exception case
				{
					char buf[] = "invalid option or command";
					write(1,buf,sizeof(buf));
				}
				memset(temp, 0 , strlen(temp));
				read(sockfd, temp, 100);//150
				write(1, temp, strlen(temp));
				////////////////////////////////////
				memset(rcv_buff, 0 , strlen(rcv_buff));
				read(client_fd, rcv_buff, 10000);// complete transmission or Failed transmission
				write(1, rcv_buff, strlen(rcv_buff));

				memset(temp, 0 ,strlen(temp));
				read(sockfd, temp, 100);// 226 or 550
				write(1, temp, strlen(temp));

				memset(temp, 0, strlen(temp));
				sprintf(temp, "OK, %ld bytes is received.", strlen(rcv_buff)*sizeof(char));
				write(1, temp, strlen(temp));
				write(1, "\n", 2);
				close(client_fd);
			}
		}		

		else if(strcmp(buf2, "pwd") == 0)// if command is pwd
		{
			if(t_argc == 1)// command only pwd
			{
				char buf[] = "PWD";
				write(sockfd,buf,4);
			}
			else//exception case
			{
				char buf[] = "invalid option or command";
				write(1,buf,sizeof(buf));
			}	
		}

		else if(strcmp(buf2, "cd") == 0)// if command is cd
		{
			if(t_argc == 1)
			{
				char buf[100] = {0};
				strcpy(buf, "CWD");
				write(sockfd, buf, strlen(buf));
			}
			else if(t_argc == 2 && strcmp(t_argv[1], "..") != 0)// when command is cd, convert CWD 
			{
				char buf[100] = {0};
				sprintf(buf,"CWD %s", t_argv[1]);
				write(sockfd, buf, 100);
			}
			else if(t_argc ==2 && strcmp(t_argv[1], "..") == 0)//when command is cd .., conver CDUP
			{
				char buf[100] = {0};
				sprintf(buf,"CDUP");
				write(sockfd, buf, 100);
			}
			else//exception case
			{
				char buf[] = "invalid option or command";
				write(1,buf,sizeof(buf));
			}
		}
		else if(strcmp(buf2, "mkdir") == 0)//if command is mkdir
		{
			if(t_argc >= 2)//when there are multiple arguments
			{
				int count  = 2;
				char buf[100] = {0};
				sprintf(buf, "MKD ");
				while(count <= t_argc)//pass the all arguments.
				{
					strcat(buf, t_argv[count-1]);
					strcat(buf, " ");
					count++;
				}
				write(sockfd,buf,100);
			}
			else//exception case
			{
				char buf[] = "invalid option or command";
				write(1,buf,sizeof(buf));
			}
		}	
		else if(strcmp(buf2, "delete") == 0)// if command is delete
		{
			if(t_argc >= 2)//when there are multiple arguments
			{
				char buf[100] = {0};
				sprintf(buf, "DELE ");
				int count = 2;
				while(count <= t_argc)//pass the all arguments.
					{
					strcat(buf, t_argv[count-1]);
					strcat(buf, " ");
					count++;
				}
				write(sockfd,buf,100);
			}
			else//exception case
			{
				char buf[] = "invalid option or command";
				write(1,buf,sizeof(buf));
			}		
		}
		else if(strcmp(buf2, "rmdir") == 0)// if command is rmdir
		{
			if(t_argc >= 2)//when there are multiple arguments
			{
				char buf[100] = {0};
				sprintf(buf,"RMD ");
				int count = 2;
				while(count <= t_argc)//pass the all arguments.
				{
					strcat(buf, t_argv[count-1]);
					strcat(buf, " ");
					count++;
				}
				write(sockfd,buf,100);
			}
			else//exception case
			{
				char buf[] = "invalid option or command";
				write(1,buf,sizeof(buf));
			}		
		}

		else if(strcmp(buf2, "rename") == 0)// if command is rename
		{
			if(t_argc == 3)//when have the right arguments
			{
				char c_copy[100] = {0};
				char buf[100] = {0};
				sprintf(buf,"RNFR %s RNTO %s", t_argv[1], t_argv[2]);
				write(sockfd,buf, strlen(buf));
			}
			else//exception case
			{
				char buf[] = "invalid option or command";
				write(1,buf,sizeof(buf));
			}
		}	
		else if(strcmp(buf2, "quit") == 0)//if command is quit
		{
			if(t_argc == 1)//when have the right arguments
			{
				char buf[] = "QUIT";
				write(sockfd,buf,5);
				memset(temp, 0, strlen(temp));
				read(sockfd, temp, 100);
				write(1, temp, strlen(temp));
				break;
			}
			else//exception case
			{
				char buf[] = "invalid option or command";
				write(1,buf,sizeof(buf));
			}		
		}
		///////////////////////////////////////////////////////////////////
		else if(strcmp(buf2, "bin") == 0)
		{
			if(t_argc == 1)//when have the right arguments
			{
				char buf[] = "TYPE I";
				write(sockfd,buf,strlen(buf));
				strcpy(MODE, "BIN_MODE");
			}
			else//exception case
			{
				char buf[] = "invalid option or command";
				write(1,buf, strlen(buf));
			}	

		}
		else if(strcmp(buf2, "ascii") == 0)
		{
			if(t_argc == 1)//when have the right arguments
			{
				char buf[] = "TYPE A";
				write(sockfd,buf,strlen(buf));
				strcpy(MODE, "ASCII_MODE");
			}
			else//exception case
			{
				char buf[] = "invalid option or command";
				write(1,buf, strlen(buf));
			}	
		}
		else if(strcmp(buf2, "type") == 0)
		{
			if(t_argc == 2)//when have the right arguments
			{
				if(strcmp(t_argv[1] ,"binary") == 0)
				{
					char buf[100] = {0};
					sprintf(buf, "TYPE I");
					write(sockfd, buf, strlen(buf));
					strcpy(MODE, "BIN_MODE");
				}
				else if(strcmp(t_argv[1], "ascii") == 0)
				{
					char buf[100] = {0};
					sprintf(buf, "TYPE A");
					write(sockfd, buf, strlen(buf));
					strcpy(MODE, "ASCII_MODE");
				}
				else
				{
					char buf[100] = {0};
					sprintf(buf, "TYPE %s", t_argv[1]);
					write(sockfd, buf, strlen(buf));
				}
			}
			else//exception case
			{
				char buf[] = "invalid option or command";
				write(1,buf, strlen(buf));
			}	
		}
		else if(strcmp(buf2, "get") == 0)
		{
			important_control++;
			//////////////////////////data connection////////////////////////////////////////
			char* addr;
			srand((unsigned)time(NULL));
			int port_num = 0;
			int b = 0;
			char temp1[100] = {0};
			char temp2[100] = {0};
			memset(temp1, 0 , strlen(temp1));
			memset(temp2, 0 , strlen(temp2));
			//////////////////////Make PORT command///////////////////
			sprintf(temp1,"PORT %s,", inet_ntoa(serv_addr.sin_addr));
			int a;
			for(a = 0 ; a < strlen(temp1) ; a++)
			{
				if(temp1[a] == '.')
				{
					temp1[a] = ',';
				}
			}
			a = 0;
			port_num = rand()%50000+10001;// Port 10001 ~ 30000
			a = port_num / 256;
			b = port_num % 256;
			sprintf(temp2, "%d,%d", a, b);
			strcat(temp1, temp2);
			addr = temp1;// addr => PORT 127,0,0,1,a,b
			//////////////////////////////////////////////////////////////
			write(sockfd, addr, strlen(addr));
			
			///////////////////data connection/////////////////////
			////////////////////client => server///////////////////
			struct sockaddr_in temp_server, temp_client;
			int temp_clilen = sizeof(temp_client);
			int server_fd, client_fd;

			server_fd = socket(AF_INET, SOCK_STREAM, 0);
			memset(&temp_server, 0, sizeof(temp_server));
			temp_server.sin_family = AF_INET;
			temp_server.sin_addr.s_addr = htonl(INADDR_ANY);
			temp_server.sin_port = htons(port_num);
			
			bind(server_fd, (struct sockaddr*)&temp_server, sizeof(temp_server));
			listen(server_fd, 5);
			// new data connection accept
			if((client_fd = accept(server_fd, (struct sockaddr*)&temp_client, &temp_clilen)) == -1)
			{
				write(1, "error_accept", 13);
				write(1,"\n",2);
				exit(1);
			}
			
			char d_copy[100] = {0};
			memset(temp, 0 , strlen(temp));
			memset(d_copy, 0 , strlen(d_copy));
			
			read(sockfd, temp, 100);// read control message from server

			strcpy(d_copy, temp);
			arr = strtok(d_copy, " ");
			
			if(strcmp(arr, "550") == 0)
			{
				write(1, temp, strlen(temp));
				continue;
			}
			else
			{
				write(1, temp, strlen(temp));
				if(t_argc == 2)//when have the right arguments
				{
					char buf[100] = {0};
					sprintf(buf, "RETR %s", t_argv[1]);// get filename => RETR filename
					write(sockfd, buf, strlen(buf));
				}
				else//exception case
				{
					char buf[] = "invalid option or command";
					write(1, buf, strlen(buf));
				}	
			}
			int f = 0;
			memset(temp, 0 , strlen(temp));
			read(sockfd, temp, 100);// read control message from server
			write(1, temp, strlen(temp));
			long int total = 0;
			//////////////////////////////////////
			char array[500] = {0};
			int read_count = 0;
			f = open(t_argv[1], O_WRONLY | O_CREAT, 00777); // file open exist file or create file for writing 
			while(1)
			{
				memset(array, 0, strlen(array));
				read_count = read(client_fd, array, 500);// read from server file data
				if(read_count == 0)
				{
					break;
				}
				write(f, array, strlen(array));
				total += strlen(array) * sizeof(char);// calculating data bytes
			}
			//////////////////////////////////////
			memset(temp, 0 , strlen(temp));
			read(sockfd, temp, 100);// read control message from server
			write(1, temp, strlen(temp));
			memset(temp, 0, strlen(temp));
			sprintf(temp, "OK. %ld bytes is received.\n", total);
			write(1, temp, strlen(temp));
			close(f);
			close(client_fd);
		}

		else if(strcmp(buf2, "put") == 0)
		{
			important_control++;
			//////////////////////////data connection////////////////////////////////////////
			char* addr;
			srand((unsigned)time(NULL));
			int port_num = 0;
			int b = 0;
			char temp1[100] = {0};
			char temp2[100] = {0};
			memset(temp1, 0 , strlen(temp1));
			memset(temp2, 0 , strlen(temp2));
			//////////////////////Make PORT command///////////////////
			sprintf(temp1,"PORT %s,", inet_ntoa(serv_addr.sin_addr));
			int a;
			for(a = 0 ; a < strlen(temp1) ; a++)
			{
				if(temp1[a] == '.')
				{
					temp1[a] = ',';
				}
			}
			a = 0;
			port_num = rand()%50000+10001;// Port 10001 ~ 30000
			a = port_num / 256;
			b = port_num % 256;
			sprintf(temp2, "%d,%d", a, b);
			strcat(temp1, temp2);
			addr = temp1;// addr => PORT 127,0,0,1,a,b
			//////////////////////////////////////////////////////////////
			write(sockfd, addr, strlen(addr));
			
			///////////////////data connection/////////////////////
			////////////////////client => server///////////////////
			struct sockaddr_in temp_server, temp_client;
			int temp_clilen = sizeof(temp_client);
			int server_fd, client_fd;

			server_fd = socket(AF_INET, SOCK_STREAM, 0);
			memset(&temp_server, 0, sizeof(temp_server));
			temp_server.sin_family = AF_INET;
			temp_server.sin_addr.s_addr = htonl(INADDR_ANY);
			temp_server.sin_port = htons(port_num);
			
			bind(server_fd, (struct sockaddr*)&temp_server, sizeof(temp_server));
			listen(server_fd, 5);
			// new data connection accept
			if((client_fd = accept(server_fd, (struct sockaddr*)&temp_client, &temp_clilen)) == -1)
			{
				write(1, "error_accept", 13);
				write(1,"\n",2);
				exit(1);
			}
			
			char d_copy[100] = {0};
			memset(temp, 0 , strlen(temp));
			memset(d_copy, 0 , strlen(d_copy));
			
			read(sockfd, temp, 100);// read control message from server

			strcpy(d_copy, temp);
			arr = strtok(d_copy, " ");
			
			if(strcmp(arr, "550") == 0)
			{
				write(1, temp, strlen(temp));
				continue;
			}
			else
			{
				write(1, temp, strlen(temp));
				if(t_argc == 2)//when have the right arguments
				{
					char buf[100] = {0};
					sprintf(buf, "STOR %s", t_argv[1]);
					write(sockfd, buf, strlen(buf));
				}
				else//exception case
				{
					char buf[] = "invalid option or command";
					write(1, buf, strlen(buf));
				}
				int f = 0;
				memset(temp, 0 , strlen(temp));
				read(sockfd, temp, 100);//150
				write(1, temp, strlen(temp));
				//////////////////////////////////////
				char array[500] = {0};
				memset(array, 0, strlen(array));
				int read_count = 0;
				long int total = 0;
				f = open(t_argv[1], O_RDONLY, MODE);// open exist file
				//puts(MODE);
				while(1)
				{
					memset(array, 0, strlen(array));
					read_count = read(f, array, 500);//read from exist file data
					if(read_count == 0)
					{
						close(client_fd);
						break;
					}
					write(client_fd, array, strlen(array));// write to server (file data)
					total += strlen(array) * sizeof(char);// calculating total data bytes
				}
				memset(temp, 0, strlen(temp));
				read(sockfd, temp, 100);
				write(1, temp, strlen(temp));
				memset(temp, 0, strlen(temp));
				sprintf(temp, "OK. %ld bytes is sent\n", total);
				write(1, temp, strlen(temp));
				close(f);

			}
		}
		
		///////////////////////////////////////////////////////////////////
		else//if command id invalid
		{
			char buf[] = "Command_Error!";
			write(sockfd,buf,strlen(buf));
		}		
		/////////////////////////////////////////////////
		if(important_control == 0)
		{
			memset(rcv_buff, 0, strlen(rcv_buff));
			read(sockfd, rcv_buff, 10000);// receive result value from server  
			/////////////////////////////////////////////////
			process_result(rcv_buff);// print result value
			memset(rcv_buff, 0 , strlen(rcv_buff));// initializing rcv_buff 
		}
		//process_result(rcv_buff);

	}
	close(sockfd);// communication over
	for(a = 0 ; a < 10 ; a++)// dynamic deallocation 
	{

		free(t_argv[a]);
	}
	free(t_argv);// dynamic deallocation 
	return 0;
}
void sg_int()//SIGINT handler function 
{
	// passing 'QUIT' message to server
	// process over
	char buf[] = "QUIT";
	write(sockfd,buf,5);
	close(sockfd);
	exit(0);// process over
}
void process_result(char* rcv_buff)//result writing function
{
	write(1, rcv_buff, strlen(rcv_buff));
	return;
}
int log_in(int sockfd)
{
	int n;
	char username[100] = {0};
	char copy[100] = {0};
	char* arr = NULL;
	char* arr2 = NULL;
	char temp[100] = {0};
	char user[MAX_BUF], *passwd, buf[100];
	char temp2[100] = {0};
	for(;;)
	{
		memset(temp, 0, strlen(temp));
		sprintf(temp, "Input ID : ");
		write(1, temp, strlen(temp));
		memset(temp, 0, strlen(temp));

		read(0, temp, 300);// wait user input username==

		memset(user, 0 ,strlen(user));
		strcpy(user, temp);

		arr = strtok(user, "\n");
		memset(temp2, 0, strlen(temp2));

		strcpy(temp2, "USER ");
		strcat(temp2, arr);//USER username

		memset(username, 0 , strlen(username));
		strcpy(username, arr);

		write(sockfd, temp2, strlen(temp2));// send to server, username information ==

		memset(buf, 0 , 100);
		n = read(sockfd, buf, 100);// wait to OK signal from server
		
		strcpy(copy, buf);
		arr2 = strtok(copy, " ");
		
		if(!strcmp(arr2, "331"))
		{
			write(1, buf, strlen(buf));
			write(1, "\n", 2);
			while(1)
			{
				memset(temp, 0, strlen(temp));
				passwd = getpass("Input Password : ");
				strcat(temp, passwd);
				///////////////////////////////////////////////////
				memset(temp2, 0 ,strlen(temp2));
				strcpy(temp2, "PASS ");
				strcat(temp2, temp);//PASS password
				arr = strtok(temp2, "\n");
				///////////////////////////////////////////////////
				write(sockfd, arr, strlen(arr));// send to server, passwd information

				memset(buf, 0 ,strlen(buf));
				n = read(sockfd, buf, 100);// wait signal OK, FAIL or DISCONNECTION
				memset(copy, 0 , strlen(copy));
				strcpy(copy, buf);

				arr2 = strtok(copy, " ");
				
				if(!strcmp(arr2, "230")) //Log_in is complete
				{
					write(1, buf, strlen(buf));
					write(1, "\n", 2);
					memset(temp, 0 ,strlen(temp));
					sprintf(temp, "** User %s logged in **\n", username);
					write(1, temp, strlen(temp));
					return 1;
					//print log_in user name
					break;	
				}
				else if(!strcmp(arr2, "430"))// Log_in is failed
				{
					write(1, buf, strlen(buf));
					write(1, "\n", 2);
					memset(temp, 0 ,strlen(temp));
					strcpy(temp, "** Log-in failed **\n");
					write(1, temp, strlen(temp));
					// login fail
				}
				else// buf is DISCONNECTION
				{ 
					write(1, buf, strlen(buf));
					write(1, "\n", 2);
					return 0;
					break;
					//connection over
				}
			}
		}
		else if(!strcmp(arr2, "430"))// Log_in is failed
		{
			write(1, buf, strlen(buf));
			write(1, "\n", 2);
			memset(temp, 0 ,strlen(temp));
			strcpy(temp, "** Log-in failed **\n");
			write(1, temp, strlen(temp));
			// login fail
		}
		else// buf is DISCONNECTION
		{ 
			write(1, buf, strlen(buf));
			write(1, "\n", 2);
			return 0;
			break;
			//connection over
		}

	} 
}
